"""
FraudGuard AI — Kafka Consumer (Fixed)
Topic: fraud-detect → POST /predict في main.py
"""
import json, time, os, signal, sys, requests
from datetime import datetime, timezone
from confluent_kafka import Consumer, KafkaError

KAFKA_BROKER   = os.getenv("KAFKA_BROKER", "localhost:9092")
TOPIC          = "fraud-detect"
API_URL        = os.getenv("API_URL", "http://localhost:8000")
CONSUMER_GROUP = "fraudguard-consumer-group"
POLL_INTERVAL  = 120.0
BATCH_SIZE     = 10

_LOCAL_CITIES = {"cairo","alex","giza","mansoura","alexandria","luxor","aswan"}

conf = {
    "bootstrap.servers"    : KAFKA_BROKER,
    "group.id"             : CONSUMER_GROUP,
    "auto.offset.reset"    : "earliest",
    "enable.auto.commit"   : False,
    "max.poll.interval.ms" : "300000",
    "session.timeout.ms"   : "30000",
    "heartbeat.interval.ms": "10000",
}

consumer = Consumer(conf)
running  = True
stats    = {"total": 0, "fraud": 0, "correct": 0, "errors": 0, "mfa": 0}


def _map_kafka_to_predict(raw: dict) -> dict:
    """
    Map KafkaTransaction → /predict request body.
    KEY FIX: Passes V1-V28 features → model يشوف fraud patterns حقيقية.
    """
    # ── Parse timestamp ──────────────────────────────────────
    try:
        ts = datetime.fromisoformat(raw["timestamp"]).timestamp()
    except Exception:
        ts = time.time()

    # ✅ FIX: استخدم datetime.fromtimestamp مش (t//3600)%24
    hour = datetime.fromtimestamp(ts).hour

    loc    = raw.get("location", "")
    device = raw.get("device", "web")

    # Build text_description for LLM flag detection in backend
    desc_parts = []
    if hour <= 5 or hour >= 22:
        desc_parts.append("midnight")
    if loc.lower() not in _LOCAL_CITIES:
        desc_parts.append(f"new country location={loc}")
    else:
        desc_parts.append(f"location={loc}")
    desc_parts.append(f"device={device}")

    payload = {
        "amount"          : float(raw.get("amount", 0)),
        "time"            : ts,
        "card_id"         : f"USER_{raw.get('user_id', 0)}",
        "text_description": " ",
    }

    # ── KEY FIX: Include V-features when present ─────────────
    # Without V-features → model sees all-median values → prob≈0 → ALLOW always
    # New producer sends realistic V-features → fraud detectable
    for i in range(1, 29):
        key = f"v{i}"
        val = raw.get(key)
        if val is not None:
            try:
                payload[key] = float(val)
            except (TypeError, ValueError):
                pass

    return payload


def _predict(payload: dict) -> dict:
    
    try:
        resp = requests.post(
            f"{API_URL}/predict",
            json    = payload,
            timeout = 5.0,
            headers = {
                "Content-Type": "application/json",
                "X-Skip-LLM": "true",        # ← Kafka بيقول للـ backend متكالش Gemini
            },
        )
        if resp.status_code == 200:
            return resp.json()
        return {"decision": "ERROR", "error": resp.status_code}
    except requests.Timeout:
        return {"decision": "ERROR", "error": "timeout"}
    except Exception as e:
        return {"decision": "ERROR", "error": str(e)}


def _log_result(result: dict, raw: dict) -> None:
    dec   = result.get("decision", "ERROR")
    risk  = result.get("total_risk", 0)
    path  = result.get("path", "?")
    prob  = result.get("probability", 0)
    uid   = raw.get("user_id", "?")
    amt   = raw.get("amount", 0)
    loc   = raw.get("location", "?")
    label = raw.get("is_fraud", -1)
    v14   = raw.get("v14")

    ground_truth = "FRAUD 🚨" if label == 1 else "LEGIT  ✅" if label == 0 else "?"

    # Did model agree with ground truth?
    model_fraud = "BLOCK" in dec or "REVIEW" in dec
    correct     = (model_fraud and label == 1) or (not model_fraud and label == 0)
    marker      = "✅" if correct else "❌"

    v14_str = f"V14={v14:+.2f}" if v14 is not None else "V14=N/A "

    print(f"  {marker} user={uid:<4} | "
          f"amount={amt:<8.2f} | "
          f"loc={loc:<12} | "
          f"{v14_str} | "
          f"prob={prob:.4f} | "
          f"decision={dec} | "
          f"risk={risk:.3f} | "
          f"truth={ground_truth}")

    stats["total"] += 1
    if "BLOCK"  in dec: stats["fraud"]  += 1
    if "MFA"    in dec: stats["mfa"]    += 1
    if "ERROR"  in dec: stats["errors"] += 1
    if label in (0, 1) and correct:
        stats["correct"] += 1


def consume_loop() -> None:
    consumer.subscribe([TOPIC])
    print(f"✅ Consumer ready | broker={KAFKA_BROKER} | topic={TOPIC} | api={API_URL}")
    print(f"⏱  Polling every {POLL_INTERVAL/60:.0f} minute(s)...")
    print(f"   V-features: ✅ passed to model\n")

    while running:
        msgs = consumer.consume(num_messages=BATCH_SIZE, timeout=POLL_INTERVAL)

        if not msgs:
            print(f"📭 No messages | stats={stats}")
            continue

        print(f"\n📦 Batch: {len(msgs)} message(s)")

        for msg in msgs:
            if msg.error():
                if msg.error().code() != KafkaError._PARTITION_EOF:
                    print(f"❌ Kafka error: {msg.error()}")
                continue

            try:
                raw     = json.loads(msg.value().decode("utf-8"))
                payload = _map_kafka_to_predict(raw)
                result  = _predict(payload)
                _log_result(result, raw)

            except Exception as e:
                print(f"❌ Processing error: {e}")
                stats["errors"] += 1

        if any(not m.error() for m in msgs):
            consumer.commit(asynchronous=False)

        if stats["total"] > 0 and stats["total"] % 10 == 0:
            labeled = stats["total"] - stats.get("unknown", 0)
            acc     = round(stats["correct"] / max(labeled, 1) * 100, 1)
            print(f"\n📊 Stats | total={stats['total']} | "
                  f"fraud_detected={stats['fraud']} | "
                  f"accuracy={acc}% | "
                  f"mfa={stats['mfa']} | errors={stats['errors']}\n")


def shutdown(sig, frame):
    global running
    labeled = stats["total"]
    acc     = round(stats["correct"] / max(labeled, 1) * 100, 1)
    print(f"\n⏹ Stopped | total={stats['total']} | accuracy={acc}% | fraud={stats['fraud']}")
    running = False
    consumer.close()
    sys.exit(0)

signal.signal(signal.SIGINT,  shutdown)
signal.signal(signal.SIGTERM, shutdown)

if __name__ == "__main__":
    consume_loop()