"""
FraudGuard AI — Kafka Producer (REAL DATA)
يقرأ من creditcard.csv ويبعت V1-V28 + Amount + Time للـ Kafka
الـ backend (build_features) بيحسب log_amount / hour / is_night لوحده
"""

import json, time, os, random, signal, sys
import pandas as pd
from datetime import datetime, timezone
from confluent_kafka import Producer

KAFKA_BROKER  = os.getenv("KAFKA_BROKER",   "localhost:29092")
TOPIC         = "fraud-detect"
CSV_PATH      = os.getenv("CSV_PATH",       "creditcard.csv")
SEND_INTERVAL = float(os.getenv("SEND_INTERVAL", "5"))

producer = Producer({
    "bootstrap.servers": KAFKA_BROKER,
    "client.id"        : "fraudguard-realdata-producer",
})

running    = True
total_sent = 0
stats      = {"fraud": 0, "legit": 0}

LOCATIONS_FRAUD = ["London", "Dubai", "Paris", "New York", "Berlin", "Tokyo"]
LOCATIONS_LEGIT = ["Cairo", "Alex", "Giza", "Mansoura", "Alexandria"]
DEVICES         = ["mobile", "web", "pos", "atm"]


def load_dataset(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        print(f"❌ File not found: {path}")
        print(f"   ضبط CSV_PATH أو حط creditcard.csv في نفس المجلد")
        sys.exit(1)

    print(f"📂 Loading: {path} ...")
    df = pd.read_csv(path)
    fraud_n = int(df["Class"].sum())
    print(f"✅ {len(df):,} rows | Fraud: {fraud_n:,} ({fraud_n/len(df)*100:.2f}%)")
    print(f"   Features: V14 V4 V12 V10 V11 V3 V8 V1 ... (top importance)\n")
    return df.sample(frac=1, random_state=42).reset_index(drop=True)


def row_to_kafka_msg(row: pd.Series, idx: int) -> dict:
    """
    Map CSV row → Kafka message.

    الـ backend في build_features بيحسب تلقائياً:
        log_amount   = log1p(amount)
        hour         = (time // 3600) % 24
        is_night     = 1 if hour <= 6 else 0
        amount_bucket

    فبنبعت بس: amount + time + v1..v28
    """
    is_fraud = int(row["Class"])
    amount   = round(float(row["Amount"]), 2)
    raw_time = float(row["Time"])          # ثواني من أول التسجيل

    # حوّل Time → hour حقيقي للـ timestamp
    hour_from_csv = int((raw_time // 3600) % 24)
    now = datetime.now(timezone.utc).replace(
        hour=hour_from_csv, minute=random.randint(0, 59),
        second=0, microsecond=0
    )

    msg = {
        "transaction_id": idx,
        "user_id"       : random.randint(1, 10000),
        "amount"        : amount,
        "time"          : raw_time,
        "currency"      : "EGP",
        "location"      : random.choice(LOCATIONS_FRAUD if is_fraud else LOCATIONS_LEGIT),
        "device"        : random.choice(DEVICES),
        "timestamp"     : now.isoformat(),
        "is_fraud"      : is_fraud,
    }

    # ── V1-V28 من الـ CSV كما هي — الأهم للموديل ──
    for i in range(1, 29):
        msg[f"v{i}"] = round(float(row[f"V{i}"]), 6)

    return msg


def delivery_report(err, msg):
    if err:
        print(f"   ❌ Delivery failed: {err}")


def send_one(row: pd.Series, idx: int):
    global total_sent

    msg = row_to_kafka_msg(row, idx)
    producer.produce(
        topic    = TOPIC,
        value    = json.dumps(msg).encode("utf-8"),
        key      = f"USER_{msg['user_id']}".encode("utf-8"),
        callback = delivery_report,
    )
    producer.flush()
    total_sent += 1
    stats["fraud" if msg["is_fraud"] else "legit"] += 1

    label = "FRAUD 🚨" if msg["is_fraud"] else "LEGIT  ✅"
    print(
        f"📤 #{idx:<6} | amt={msg['amount']:<9.2f} | "
        f"V14={msg['v14']:+.3f} | V4={msg['v4']:+.3f} | "
        f"loc={msg['location']:<12} | {label} | total={total_sent}"
    )

    if total_sent % 20 == 0:
        pct = stats["fraud"] / max(total_sent, 1) * 100
        print(f"\n📊 sent={total_sent} | fraud={stats['fraud']} ({pct:.1f}%) | legit={stats['legit']}\n")


def shutdown(sig, frame):
    pct = stats["fraud"] / max(total_sent, 1) * 100
    print(f"\n⏹ Stopped | sent={total_sent} | fraud={stats['fraud']} ({pct:.1f}%)")
    producer.flush()
    sys.exit(0)


signal.signal(signal.SIGINT,  shutdown)
signal.signal(signal.SIGTERM, shutdown)


if __name__ == "__main__":
    print("=" * 60)
    print("🚀 FraudGuard Producer — REAL DATA MODE")
    print(f"   Broker  : {KAFKA_BROKER}")
    print(f"   Topic   : {TOPIC}")
    print(f"   CSV     : {CSV_PATH}")
    print(f"   Interval: {SEND_INTERVAL}s/tx")
    print("=" * 60 + "\n")

    df         = load_dataset(CSV_PATH)
    total_rows = len(df)
    idx        = 0

    while running:
        send_one(df.iloc[idx % total_rows], idx)
        idx += 1

        if idx > 0 and idx % total_rows == 0:
            print(f"\n🔄 Full pass done — reshuffling {total_rows:,} rows...\n")
            df = df.sample(frac=1).reset_index(drop=True)

        time.sleep(SEND_INTERVAL)