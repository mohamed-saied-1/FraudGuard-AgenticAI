"""
FraudGuard AI — Production Email + MFA Module
email_mfa.py

Features:
  EmailService  — dedup · retry · rate-limit · audit trail · async queue
  MFAService    — crypto-secure OTP · attempt limiting · auto-email · cleanup · status
  should_send_alert — smart alert trigger (no spam)

Place this file next to main.py.
"""

import os
import json
import time
import secrets
import hashlib
import logging
import smtplib
import threading
import collections
from datetime import datetime
from typing import Optional, Dict, List, Tuple

from email.mime.multipart import MIMEMultipart
from email.mime.text      import MIMEText

logger = logging.getLogger("fraudguard.email_mfa")

# ── Credentials (env-first) ──────────────────────────────────────────────────
EMAIL_SENDER   = os.getenv("EMAIL_SENDER",   "thelastking398@gmail.com")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD", "pfsv zgmz bjiv flgn")
EMAIL_RECEIVER = os.getenv("EMAIL_RECEIVER", "mohamed80598@gmail.com")
SMTP_HOST      = "smtp.gmail.com"
SMTP_PORT      = 465

# ════════════════════════════════════════════════════════════════════════════
# EMAIL SERVICE
# ════════════════════════════════════════════════════════════════════════════

class EmailService:
    """
    Production email service with:
      • Deduplication  — same tx won't double-send within DEDUP_TTL seconds
      • Rate limiting  — max MAX_PER_MINUTE emails per minute
      • Retry          — up to MAX_RETRIES with exponential back-off
      • Audit trail    — full send history (last 500 entries)
      • Thread-safe    — all state protected by RLock
    """

    DEDUP_TTL      = 300      # seconds — same tx_id won't re-send for 5 min
    MAX_PER_MINUTE = 10       # hard cap to avoid Gmail throttle
    MAX_RETRIES    = 3
    HISTORY_MAX    = 500

    def __init__(self) -> None:
        self._lock         = threading.RLock()
        self._dedup:  Dict[str, float]  = {}   # tx_id → last_sent_ts
        self._minute_bucket: collections.deque = collections.deque()
        self._history: collections.deque = collections.deque(maxlen=self.HISTORY_MAX)
        self._stats   = {"sent": 0, "failed": 0, "deduped": 0, "rate_limited": 0}

    # ── public API ───────────────────────────────────────────────────────────

    def send(
        self,
        to:         str,
        subject:    str,
        html:       str,
        email_type: str = "generic",
        tx_id:      str = "",
        force:      bool = False,
    ) -> dict:
        """
        Send email with dedup + rate-limit + retry.
        Returns: {"status": "sent"|"queued"|"deduped"|"rate_limited"|"failed", ...}
        """
        # ── Dedup check ──────────────────────────────────────────────────
        if tx_id and not force:
            with self._lock:
                last = self._dedup.get(tx_id, 0)
                if time.time() - last < self.DEDUP_TTL:
                    self._stats["deduped"] += 1
                    logger.debug(f"Email deduped: tx_id={tx_id}")
                    return {"status": "deduped", "tx_id": tx_id}

        # ── Rate-limit check ─────────────────────────────────────────────
        with self._lock:
            now = time.time()
            # Slide the window — drop entries older than 60 s
            while self._minute_bucket and now - self._minute_bucket[0] > 60:
                self._minute_bucket.popleft()
            if len(self._minute_bucket) >= self.MAX_PER_MINUTE:
                self._stats["rate_limited"] += 1
                logger.warning("Email rate-limited — too many emails per minute")
                return {"status": "rate_limited", "tx_id": tx_id}
            self._minute_bucket.append(now)

        # ── Send with retry ──────────────────────────────────────────────
        last_err = ""
        for attempt in range(1, self.MAX_RETRIES + 1):
            ok, err = self._smtp_send(to=to, subject=subject, html=html)
            if ok:
                with self._lock:
                    if tx_id:
                        self._dedup[tx_id] = time.time()
                    self._stats["sent"] += 1
                    self._history.append({
                        "ts"         : datetime.now().isoformat(),
                        "to"         : to,
                        "subject"    : subject[:80],
                        "email_type" : email_type,
                        "tx_id"      : tx_id,
                        "status"     : "sent",
                        "attempt"    : attempt,
                    })
                logger.info(f"✅ Email sent [{email_type}] to={to} attempt={attempt}")
                return {"status": "sent", "tx_id": tx_id, "to": to}

            last_err = err
            if attempt < self.MAX_RETRIES:
                wait = 1.5 ** attempt
                logger.warning(f"Email attempt {attempt} failed ({err}) — retry in {wait:.1f}s")
                time.sleep(wait)

        # ── All retries failed ───────────────────────────────────────────
        with self._lock:
            self._stats["failed"] += 1
            self._history.append({
                "ts"         : datetime.now().isoformat(),
                "to"         : to,
                "subject"    : subject[:80],
                "email_type" : email_type,
                "tx_id"      : tx_id,
                "status"     : "failed",
                "error"      : last_err,
            })
        logger.error(f"❌ Email failed [{email_type}] to={to}: {last_err}")
        return {"status": "failed", "error": last_err, "tx_id": tx_id}

    def get_stats(self) -> dict:
        with self._lock:
            return dict(self._stats)

    def get_history(self, n: int = 50) -> list:
        with self._lock:
            return list(self._history)[-n:]

    # ── private ──────────────────────────────────────────────────────────────

    def _smtp_send(self, to: str, subject: str, html: str) -> Tuple[bool, str]:
        """Raw SMTP send. Returns (success, error_message)."""
        if not EMAIL_SENDER or not EMAIL_PASSWORD:
            return False, "Email credentials not configured"
        try:
            msg             = MIMEMultipart("alternative")
            msg["From"]     = f"FraudGuard AI <{EMAIL_SENDER}>"
            msg["To"]       = to
            msg["Subject"]  = subject
            msg.attach(MIMEText(html, "html", "utf-8"))
            with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=10) as s:
                s.login(EMAIL_SENDER, EMAIL_PASSWORD)
                s.sendmail(EMAIL_SENDER, to, msg.as_string())
            return True, ""
        except smtplib.SMTPAuthenticationError:
            return False, "SMTP auth failed — check EMAIL_PASSWORD"
        except smtplib.SMTPRecipientsRefused:
            return False, f"Recipient refused: {to}"
        except Exception as e:
            return False, str(e)


# ════════════════════════════════════════════════════════════════════════════
# MFA SERVICE
# ════════════════════════════════════════════════════════════════════════════

class MFAService:
    """
    Production MFA with:
      • secrets.token_hex — cryptographically secure token
      • secrets.randbelow — cryptographically secure 6-digit OTP
      • Attempt limiting  — 3 attempts, then account lock for 10 min
      • Auto-email OTP    — sends email with beautiful HTML
      • Status polling    — frontend can poll remaining time + attempts
      • Resend OTP        — new code, reset attempt counter
      • Cleanup thread    — purges expired sessions every 60 s
      • Audit trail       — every verify attempt logged
    """

    OTP_TTL      = 300    # 5 min
    MAX_ATTEMPTS = 3
    LOCK_TTL     = 600    # 10 min lockout after MAX_ATTEMPTS
    CLEANUP_SECS = 60

    def __init__(self, email_svc: EmailService) -> None:
        self._lock    = threading.RLock()
        self._pending: Dict[str, dict] = {}   # token → session
        self._audit:   collections.deque = collections.deque(maxlen=500)
        self._email   = email_svc

        # Background cleanup
        t = threading.Thread(target=self._cleanup_loop, daemon=True)
        t.start()

    # ── public API ───────────────────────────────────────────────────────────

    def trigger(
        self,
        card_id:        str,
        result:         dict,
        customer_email: str = "",
    ) -> dict:
        """
        Generate MFA session.
        Returns the mfa_info dict to embed in prediction result.
        """
        otp   = self._gen_otp()
        token = self._gen_token(card_id)
        now   = time.time()

        session = {
            "card_id"       : card_id,
            "otp"           : otp,
            "token"         : token,
            "created"       : now,
            "expires"       : now + self.OTP_TTL,
            "attempts"      : 0,
            "locked_until"  : 0.0,
            "verified"      : False,
            "result"        : result,
            "customer_email": customer_email,
        }

        with self._lock:
            self._pending[token] = session

        logger.info(f"MFA triggered — card={card_id} token={token[:8]}…")

        # Send OTP email (non-blocking)
        if customer_email:
            threading.Thread(
                target=self._send_otp_email,
                args=(customer_email, otp, card_id, result),
                daemon=True,
            ).start()

        return {
            "mfa_required"   : True,
            "token"          : token,
            "expires_in"     : self.OTP_TTL,
            "otp_sent_to"    : customer_email or "none",
            "message"        : "A 6-digit OTP has been sent to your registered email.",
        }

    def verify(
        self,
        token: str,
        otp:   str,
        ip:    str = "",
    ) -> Tuple[bool, dict]:
        """
        Verify OTP.
        Returns (success, response_dict).
        Handles: expired / locked / wrong / already verified.
        """
        now = time.time()
        with self._lock:
            session = self._pending.get(token)

        if session is None:
            self._audit_log(token, "TOKEN_NOT_FOUND", ip)
            return False, {"status": "error", "code": "TOKEN_NOT_FOUND",
                           "detail": "Token not found or already used"}

        card_id = session["card_id"]

        if now > session["expires"]:
            self._cleanup_token(token)
            self._audit_log(token, "TOKEN_EXPIRED", ip, card_id)
            return False, {"status": "error", "code": "TOKEN_EXPIRED",
                           "detail": "OTP has expired — request a new one"}

        if session["verified"]:
            self._audit_log(token, "ALREADY_VERIFIED", ip, card_id)
            return True, {"status": "already_verified", "code": "ALREADY_VERIFIED",
                          "original_decision": session["result"].get("decision")}

        if now < session["locked_until"]:
            remaining = int(session["locked_until"] - now)
            self._audit_log(token, "ACCOUNT_LOCKED", ip, card_id)
            return False, {"status": "error", "code": "ACCOUNT_LOCKED",
                           "detail": f"Account locked for {remaining}s after too many attempts"}

        # Check OTP
        with self._lock:
            session["attempts"] += 1
            attempts = session["attempts"]

        if otp.strip() != session["otp"]:
            remaining_attempts = self.MAX_ATTEMPTS - attempts
            if attempts >= self.MAX_ATTEMPTS:
                with self._lock:
                    session["locked_until"] = now + self.LOCK_TTL
                self._audit_log(token, "MAX_ATTEMPTS_EXCEEDED", ip, card_id)
                # Send lockout notification
                if session.get("customer_email"):
                    threading.Thread(
                        target=self._send_locked_email,
                        args=(session["customer_email"], card_id),
                        daemon=True,
                    ).start()
                return False, {"status": "error", "code": "MAX_ATTEMPTS_EXCEEDED",
                               "detail": f"Account locked for {self.LOCK_TTL // 60} minutes"}

            self._audit_log(token, "WRONG_OTP", ip, card_id)
            return False, {
                "status"            : "error",
                "code"              : "WRONG_OTP",
                "detail"            : f"Invalid OTP — {remaining_attempts} attempt(s) left",
                "attempts_remaining": remaining_attempts,
            }

        # ── Correct OTP ──────────────────────────────────────────────────
        with self._lock:
            session["verified"] = True

        self._audit_log(token, "SUCCESS", ip, card_id)

        # Send approval confirmation
        if session.get("customer_email"):
            threading.Thread(
                target=self._send_approved_email,
                args=(session["customer_email"], card_id, session["result"]),
                daemon=True,
            ).start()

        # Clean up after short grace period
        def _deferred_cleanup():
            time.sleep(30)
            self._cleanup_token(token)
        threading.Thread(target=_deferred_cleanup, daemon=True).start()

        return True, {
            "status"           : "verified",
            "code"             : "SUCCESS",
            "message"          : "Identity verified — transaction approved",
            "original_decision": session["result"].get("decision"),
            "card_id"          : card_id,
        }

    def status(self, token: str) -> Optional[dict]:
        """Return session status for frontend polling."""
        now = time.time()
        with self._lock:
            session = self._pending.get(token)
        if session is None:
            return None
        expired  = now > session["expires"]
        locked   = now < session["locked_until"]
        return {
            "token"             : token,
            "card_id"           : session["card_id"],
            "verified"          : session["verified"],
            "expired"           : expired,
            "locked"            : locked,
            "locked_until"      : session["locked_until"],
            "expires_in"        : max(0, int(session["expires"] - now)),
            "attempts"          : session["attempts"],
            "attempts_remaining": max(0, self.MAX_ATTEMPTS - session["attempts"]),
            "otp_sent_to"       : session.get("customer_email", ""),
        }

    def resend(self, token: str) -> dict:
        """Generate a new OTP for an existing session and resend email."""
        now = time.time()
        with self._lock:
            session = self._pending.get(token)

        if session is None:
            return {"status": "error", "code": "TOKEN_NOT_FOUND"}
        if now > session["expires"]:
            return {"status": "error", "code": "TOKEN_EXPIRED"}
        if now < session["locked_until"]:
            return {"status": "error", "code": "ACCOUNT_LOCKED"}
        if not session.get("customer_email"):
            return {"status": "error", "code": "NO_EMAIL",
                    "detail": "No customer email on file"}

        new_otp = self._gen_otp()
        with self._lock:
            session["otp"]      = new_otp
            session["attempts"] = 0
            session["expires"]  = now + self.OTP_TTL

        threading.Thread(
            target=self._send_otp_email,
            args=(session["customer_email"], new_otp,
                  session["card_id"], session["result"]),
            daemon=True,
        ).start()

        return {
            "status"    : "resent",
            "expires_in": self.OTP_TTL,
            "otp_sent_to": session["customer_email"],
        }

    def cancel(self, token: str) -> bool:
        """Cancel a pending session. Returns True if removed."""
        with self._lock:
            removed = self._pending.pop(token, None)
        return removed is not None

    def get_stats(self) -> dict:
        with self._lock:
            total    = len(self._pending)
            verified = sum(1 for s in self._pending.values() if s["verified"])
            locked   = sum(1 for s in self._pending.values()
                           if time.time() < s["locked_until"])
        return {
            "pending_sessions": total,
            "verified"        : verified,
            "locked"          : locked,
            "audit_entries"   : len(self._audit),
        }

    def get_audit(self, n: int = 20) -> list:
        with self._lock:
            return list(self._audit)[-n:]

    # ── private ──────────────────────────────────────────────────────────────

    @staticmethod
    def _gen_otp() -> str:
        """Cryptographically secure 6-digit OTP."""
        return f"{secrets.randbelow(900_000) + 100_000}"

    @staticmethod
    def _gen_token(card_id: str) -> str:
        """Cryptographically secure 32-char hex token."""
        return secrets.token_hex(16) + hashlib.sha256(
            f"{card_id}{time.time()}".encode()
        ).hexdigest()[:8]

    def _cleanup_token(self, token: str) -> None:
        with self._lock:
            self._pending.pop(token, None)

    def _audit_log(self, token: str, event: str,
                   ip: str = "", card_id: str = "") -> None:
        entry = {
            "ts"      : datetime.now().isoformat(),
            "token"   : token[:12] + "…",
            "event"   : event,
            "ip"      : ip or "—",
            "card_id" : card_id,
        }
        with self._lock:
            self._audit.append(entry)
        if event not in ("SUCCESS", "ALREADY_VERIFIED"):
            logger.warning(f"MFA [{event}] card={card_id} token={token[:8]}… ip={ip}")
        else:
            logger.info(f"MFA [{event}] card={card_id}")

    def _cleanup_loop(self) -> None:
        """Background thread — purge expired/old sessions every 60 s."""
        while True:
            time.sleep(self.CLEANUP_SECS)
            try:
                now     = time.time()
                cutoff  = now - (self.OTP_TTL + self.LOCK_TTL + 60)
                with self._lock:
                    dead = [
                        t for t, s in self._pending.items()
                        if s["created"] < cutoff or
                           (s["verified"] and s["created"] < now - 60)
                    ]
                    for t in dead:
                        self._pending.pop(t, None)
                if dead:
                    logger.debug(f"MFA cleanup — removed {len(dead)} expired sessions")
            except Exception as e:
                logger.warning(f"MFA cleanup error: {e}")

    # ── Email templates ───────────────────────────────────────────────────────

    def _send_otp_email(self, to: str, otp: str,
                        card_id: str, result: dict) -> None:
        risk_pct = int(result.get("total_risk", 0) * 100)
        dec      = result.get("decision", "REVIEW ⚠️")
        tx_id    = result.get("row_id", "N/A")

        html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:20px;background:#060610;
             font-family:'Segoe UI',Arial,sans-serif;">
<div style="max-width:480px;margin:auto;">
  <div style="border-radius:16px;overflow:hidden;border:1px solid #1e1e3a;">

    <!-- Header -->
    <div style="background:linear-gradient(135deg,#0d0d1a,#1a0d2e);
                padding:28px 28px 20px;text-align:center;position:relative;">
      <div style="position:absolute;top:0;left:0;right:0;height:3px;
                  background:linear-gradient(90deg,#5e5ce6,#bf5af2);"></div>
      <div style="font-size:40px;margin-bottom:10px;">🔐</div>
      <h1 style="margin:0;color:#d0d0ff;font-size:20px;font-weight:800;
                 letter-spacing:1px;">Identity Verification</h1>
      <p style="margin:4px 0 0;color:#5050a0;font-size:11px;letter-spacing:.5px;">
        FraudGuard AI · Security Challenge</p>
    </div>

    <!-- Risk context -->
    <div style="background:#0f0f1a;padding:14px 24px;border-bottom:1px solid #1e1e3a;
                display:flex;align-items:center;justify-content:space-between;">
      <span style="color:#7070a0;font-size:11px;font-family:monospace;">
        TX #{tx_id}</span>
      <span style="color:#ff9f0a;font-size:12px;font-weight:700;font-family:monospace;">
        {risk_pct}% RISK · VERIFICATION REQUIRED</span>
    </div>

    <!-- OTP -->
    <div style="background:#0d0d1a;padding:30px 24px;text-align:center;
                border-bottom:1px solid #1e1e3a;">
      <p style="margin:0 0 8px;color:#8080c0;font-size:12px;
                text-transform:uppercase;letter-spacing:2px;">Your One-Time Code</p>
      <div style="display:inline-block;background:#1a1a3a;border:2px solid #5e5ce6;
                  border-radius:12px;padding:16px 32px;margin:6px 0;">
        <span style="font-family:'Courier New',monospace;font-size:38px;
                     font-weight:900;color:#ffffff;letter-spacing:14px;">
          {otp}</span>
      </div>
      <p style="margin:10px 0 0;color:#ff9f0a;font-size:11px;
                font-family:monospace;">⏱ Valid for 5 minutes only</p>
    </div>

    <!-- Instructions -->
    <div style="background:#080810;padding:20px 24px;border-bottom:1px solid #1e1e3a;">
      <p style="margin:0 0 10px;color:#c0c0e0;font-size:13px;line-height:1.6;">
        A suspicious transaction was detected on your account.
        Enter the 6-digit code above to approve it, or
        <strong style="color:#ff2d55;">ignore this email</strong> to block it.
      </p>
      <div style="background:#1a0508;border-left:3px solid #ff2d55;
                  border-radius:4px;padding:10px 14px;">
        <p style="margin:0;color:#ff7090;font-size:11px;line-height:1.5;">
          ⚠️ Never share this code with anyone.
          FraudGuard will never ask for your OTP by phone or chat.
        </p>
      </div>
    </div>

    <!-- Footer -->
    <div style="background:#050508;padding:14px 24px;text-align:center;">
      <p style="margin:0;color:#2a2a50;font-size:10px;">
        <span style="color:#4040a0;">FraudGuard AI</span> ·
        Card {card_id} · {datetime.now().strftime("%Y-%m-%d %H:%M")} UTC
      </p>
    </div>

  </div>
</div>
</body>
</html>"""

        email_service.send(
            to         = to,
            subject    = f"🔐 Your FraudGuard Verification Code: {otp}",
            html       = html,
            email_type = "mfa_otp",
            tx_id      = f"mfa:{card_id}:{int(time.time())}",
            force      = True,   # always send OTP regardless of dedup
        )

    def _send_approved_email(self, to: str,
                              card_id: str, result: dict) -> None:
        tx_id    = result.get("row_id", "N/A")
        dec      = result.get("decision", "")
        risk_pct = int(result.get("total_risk", 0) * 100)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:20px;background:#060610;
             font-family:'Segoe UI',Arial,sans-serif;">
<div style="max-width:480px;margin:auto;">
  <div style="border-radius:16px;overflow:hidden;border:1px solid #1e3a1e;">
    <div style="background:linear-gradient(135deg,#0d1a0d,#0d2e0d);
                padding:28px;text-align:center;position:relative;">
      <div style="position:absolute;top:0;left:0;right:0;height:3px;
                  background:linear-gradient(90deg,#30d158,#22c55e);"></div>
      <div style="font-size:42px;margin-bottom:10px;">✅</div>
      <h1 style="margin:0;color:#30d158;font-size:20px;font-weight:800;">
        Identity Verified</h1>
      <p style="margin:4px 0 0;color:#305030;font-size:11px;">
        Transaction #{tx_id} has been approved</p>
    </div>
    <div style="background:#080810;padding:20px 24px;text-align:center;">
      <p style="margin:0;color:#c0c0e0;font-size:13px;line-height:1.6;">
        Your identity has been successfully verified.
        The transaction with {risk_pct}% risk score has been released.
      </p>
    </div>
    <div style="background:#050508;padding:12px;text-align:center;">
      <p style="margin:0;color:#2a2a50;font-size:10px;">
        FraudGuard AI · {datetime.now().strftime("%Y-%m-%d %H:%M")} UTC</p>
    </div>
  </div>
</div>
</body>
</html>"""

        email_service.send(
            to         = to,
            subject    = "✅ Transaction Approved — FraudGuard AI",
            html       = html,
            email_type = "mfa_approved",
            tx_id      = f"mfa_ok:{card_id}:{int(time.time())}",
            force      = True,
        )

    def _send_locked_email(self, to: str, card_id: str) -> None:
        html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:20px;background:#060610;
             font-family:'Segoe UI',Arial,sans-serif;">
<div style="max-width:480px;margin:auto;">
  <div style="border-radius:16px;overflow:hidden;border:1px solid #3a1e1e;">
    <div style="background:linear-gradient(135deg,#1a0d0d,#2e0d0d);
                padding:28px;text-align:center;position:relative;">
      <div style="position:absolute;top:0;left:0;right:0;height:3px;
                  background:linear-gradient(90deg,#ff2d55,#ff453a);"></div>
      <div style="font-size:42px;margin-bottom:10px;">🔒</div>
      <h1 style="margin:0;color:#ff2d55;font-size:20px;font-weight:800;">
        Account Temporarily Locked</h1>
      <p style="margin:4px 0 0;color:#503030;font-size:11px;">
        Too many failed verification attempts</p>
    </div>
    <div style="background:#080810;padding:20px 24px;">
      <p style="margin:0;color:#c0c0e0;font-size:13px;line-height:1.6;">
        Your account has been locked for <strong style="color:#ff9f0a;">10 minutes</strong>
        after {self.MAX_ATTEMPTS} failed verification attempts.
      </p>
      <div style="background:#1a0508;border-left:3px solid #ff2d55;
                  border-radius:4px;padding:10px 14px;margin-top:14px;">
        <p style="margin:0;color:#ff7090;font-size:11px;line-height:1.5;">
          If this wasn't you, please contact your bank immediately.
          Card: {card_id}
        </p>
      </div>
    </div>
    <div style="background:#050508;padding:12px;text-align:center;">
      <p style="margin:0;color:#2a2a50;font-size:10px;">
        FraudGuard AI · {datetime.now().strftime("%Y-%m-%d %H:%M")} UTC</p>
    </div>
  </div>
</div>
</body>
</html>"""

        email_service.send(
            to         = to,
            subject    = "🔒 Security Alert: Account Locked — FraudGuard AI",
            html       = html,
            email_type = "mfa_locked",
            tx_id      = f"mfa_lock:{card_id}:{int(time.time())}",
            force      = True,
        )


# ════════════════════════════════════════════════════════════════════════════
# ALERT TRIGGER LOGIC
# ════════════════════════════════════════════════════════════════════════════

# Track which tx_ids already got an email (dedup across session)
_alert_dedup:  Dict[str, float] = {}
_alert_lock    = threading.Lock()
ALERT_DEDUP_TTL = 300   # 5 min — same tx won't trigger twice

def should_send_alert(result: dict) -> bool:
    """
    Smart alert trigger — send internal fraud alert email when:
      • Decision is BLOCK or REVIEW
      • Confidence band is high or critical
      • Same tx_id hasn't been alerted within ALERT_DEDUP_TTL
    Returns True if alert should be sent.
    """
    dec  = result.get("decision", "")
    band = result.get("confidence_band", "")
    risk = float(result.get("total_risk", 0))

    # Only alert on actionable high-risk decisions
    if "ALLOW" in dec and risk < 0.6:
        return False
    if band not in ("high", "critical"):
        return False
    if "BLOCK" not in dec and "REVIEW" not in dec:
        return False

    # Dedup by tx_id
    tx_id = str(result.get("row_id", result.get("card_id", "")))
    if not tx_id:
        return True   # no ID → always send

    now = time.time()
    with _alert_lock:
        last = _alert_dedup.get(tx_id, 0)
        if now - last < ALERT_DEDUP_TTL:
            return False
        _alert_dedup[tx_id] = now

        # Prune old entries (memory guard)
        if len(_alert_dedup) > 1000:
            cutoff = now - ALERT_DEDUP_TTL
            for k in [k for k, v in _alert_dedup.items() if v < cutoff]:
                _alert_dedup.pop(k, None)

    return True


# ════════════════════════════════════════════════════════════════════════════
# MODULE-LEVEL SINGLETONS — import these in main.py
# ════════════════════════════════════════════════════════════════════════════

email_service = EmailService()
mfa_service   = MFAService(email_service)
