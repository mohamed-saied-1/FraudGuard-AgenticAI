"""
FraudGuard AI — FastAPI Backend
Production-Grade Fraud Detection API
"""
import os
os.environ["SHAP_SERVER_DISABLED"] = "1"
os.environ["PYTHONIOENCODING"]     = "utf-8"
import json
import time
import asyncio
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any

import numpy as np
import pandas as pd
import joblib

from fastapi import FastAPI, HTTPException, UploadFile, File, WebSocket, WebSocketDisconnect, Request
from fastapi.middleware.cors import CORSMiddleware
import fastapi.responses
from pydantic import BaseModel

from agent_layer import (
    FraudOrchestrator,
    AgentMemory,
    build_sarima_visualization,
    _TOOL_REGISTRY,
)
 

import io
import re
import hashlib
import threading
import smtplib
import collections
from typing import Tuple
from logging.handlers import RotatingFileHandler
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# ★ Production Email + MFA — replaces old email/mfa functions
from email_mfa import (
    email_service,
    mfa_service,
    should_send_alert,
)
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware # ← تأكد من إضافة ده
from collections import deque
from google.genai import types

import collections
import pandas as pd
# In-memory Kafka consumer log (last 100 entries)
KAFKA_LOG: deque = deque(maxlen=100)
BATCH_RESULTS_STORE: Dict[str, dict] = {}   # key=str(row_id), value=full result
BATCH_STORE_LOCK = threading.Lock()
LAST_BATCH_META: Dict = {}   # summary of last batch

# ----------------------------------

# ── Logging ──
import sys
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stdout,
    encoding='utf-8'
)
logger = logging.getLogger("fraudguard")

# ── أضف بعد: logger = logging.getLogger("fraudguard") ──

os.makedirs("logs",   exist_ok=True)
os.makedirs("models", exist_ok=True)

# Structured JSON audit trail
_audit = logging.getLogger("fraudguard.audit")
_audit.setLevel(logging.INFO)
_ah    = RotatingFileHandler("logs/fraud_decisions.log",
                              maxBytes=5_000_000, backupCount=5, encoding='utf-8')
_ah.setFormatter(logging.Formatter("%(message)s"))
_audit.addHandler(_ah)
_audit.propagate = False

def log_decision(result: dict) -> None:
    """Full structured audit log — every prediction."""
    entry = {
        "ts"              : result.get("timestamp"),
        "row_id"          : result.get("row_id"),
        "model_version"   : result.get("model_version"),
        "card_id"         : result.get("card_id"),
        "probability"     : result.get("probability"),
        "shap_score"      : result.get("shap_score"),
        "forecast_risk"   : result.get("forecast_risk"),
        "total_risk"      : result.get("total_risk"),
        "decision"        : result.get("decision"),
        "uncertainty"     : result.get("uncertainty"),
        "confidence_band" : result.get("confidence_band"),
        "path"            : result.get("path"),
        "layers_used"     : result.get("layers_used", []),
        "llm_override"    : result.get("llm_override", False),
        "mfa_required"    : result.get("mfa_required", False),
        "top_drivers"     : [d.get("feature") for d in result.get("top_drivers", [])[:3]],
        "risk_components" : result.get("risk_components", {}),
        "explanation"     : result.get("explanation", ""),
    }
    _audit.info(json.dumps(entry, ensure_ascii=False))


# ════════════════════════════════════════════════════════════════
# LIVE SARIMA UPDATE — called after every prediction
# Connects predict / batch / stream / kafka → ARIMA
# ════════════════════════════════════════════════════════════════
_sarima_lock  = threading.Lock()
_sarima_window: "deque" = None   # lazy-init below

def _update_live_sarima(decision: str, transaction_time: float = 0.0) -> None:
    """
    Update ROLLING_FRAUD_RATE and FORECAST_TS from each live prediction.
    Called from log_decision so ALL endpoints (predict/batch/stream/kafka)
    automatically feed the SARIMA model.
    """
    global ROLLING_FRAUD_RATE, FORECAST_TS, HOURLY_PROFILE, MAX_RATE, _sarima_window

    with _sarima_lock:
        # Lazy init rolling window (last 1000 decisions)
        if _sarima_window is None:
            _sarima_window = collections.deque(maxlen=1000)

        is_fraud = 1 if ("BLOCK" in decision or "REVIEW" in decision) else 0
        _sarima_window.append(is_fraud)

        # Recompute rolling fraud rate
        if len(_sarima_window) >= 10:
            ROLLING_FRAUD_RATE = float(sum(_sarima_window) / len(_sarima_window))

        # Update hourly profile
        hour = int((transaction_time // 3600) % 24)
        if hour in HOURLY_PROFILE:
            # Exponential smoothing: alpha=0.05
            HOURLY_PROFILE[hour] = 0.95 * HOURLY_PROFILE[hour] + 0.05 * is_fraud
        else:
            HOURLY_PROFILE[hour] = float(is_fraud)

        # Update MAX_RATE
        MAX_RATE = max(MAX_RATE, ROLLING_FRAUD_RATE, 1e-6)

        # Append to FORECAST_TS time-series DataFrame
        bucket = int(transaction_time // 3600) if transaction_time > 0 else \
                 int(time.time() // 3600)
        new_row = pd.DataFrame([{
            "hour_bucket"       : bucket,
            "fraud_count"       : is_fraud,
            "total_count"       : 1,
            "fraud_rate"        : float(is_fraud),
            "rolling_fraud_rate": ROLLING_FRAUD_RATE,
            "spike"             : ROLLING_FRAUD_RATE > GLOBAL_MEAN_RATE * 3,
        }])
        if FORECAST_TS is None or FORECAST_TS.empty:
            FORECAST_TS = new_row
        else:
            FORECAST_TS = pd.concat([FORECAST_TS, new_row], ignore_index=True).tail(2000)


def log_decision_and_update_sarima(result: dict) -> None:
    """Unified: log + update SARIMA. Use this instead of log_decision directly."""
    log_decision(result)
    _update_live_sarima(
        decision=result.get("decision", ""),
        transaction_time=float(result.get("structured", {}).get("hour", 0) or 0) * 3600,
    )
    # ★ BUG FIX: auto-retrain when LearningAgent fires both signals
    both_firing = result.get("agentic", {}).get("both_drift_signals_firing", False)
    if both_firing:
        now = time.time()
        if (now - LAST_RETRAIN_TIME) > 3600:   # max once per hour
            logger.info("🤖 LearningAgent triggered auto-retrain")
            if _sarima_window and len(_sarima_window) >= 100:
                records = [r for r in _sarima_window if isinstance(r, dict)]
                if records:
                    df_logs = pd.DataFrame(records)
                    drift   = check_drift(df_logs)
                    threading.Thread(
                        target=retrain_job,
                        args=(df_logs, drift),
                        daemon=True,
                    ).start()


# ── App ──
app = FastAPI(
    title="FraudGuard AI",
    description="Production-Grade Fraud Detection API",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Load Models ──
MODEL_PATH     = os.getenv("MODEL_PATH",     "models/model_latest.pkl")
THRESHOLD_PATH = os.getenv("THRESHOLD_PATH", "models/threshold.pkl")
FEATURES_PATH  = os.getenv("FEATURES_PATH",  "models/expected_features.pkl")
BASELINE_PATH  = os.getenv("BASELINE_PATH",  "models/baseline_stats.pkl")

ACTIVE_MODEL     = None
ACTIVE_THRESHOLD = 0.2858
EXPECTED_FEATURES = []
BASELINE_STATS   = {}

# ── استبدل load_models كاملة ──

def _resolve_model_path() -> str:
    """
    Find model_latest.pkl OR the newest model_TIMESTAMP.pkl automatically.
    This handles the case where model_latest.pkl doesn't exist yet.
    """
    explicit = os.getenv("MODEL_PATH", "models/model_latest.pkl")
    if os.path.exists(explicit):
        return explicit

    # Fallback: find the newest model_*.pkl in models/
    import glob
    candidates = glob.glob("models/model_*.pkl")
    if candidates:
        newest = max(candidates, key=os.path.getmtime)
        logger.warning(f"model_latest.pkl not found — using newest: {newest}")
        # Create symlink alias so future loads are consistent
        try:
            import shutil
            shutil.copy2(newest, "models/model_latest.pkl")
            logger.info(f"✅ Copied {newest} → models/model_latest.pkl")
        except Exception:
            pass
        return newest

    logger.error("No model file found in models/")
    return explicit   # will trigger missing-file warning in load_models


def load_models() -> None:
    global ACTIVE_MODEL, ACTIVE_THRESHOLD, EXPECTED_FEATURES, BASELINE_STATS
    global MEDIAN_VALUES, MONITOR_FEATURES, MODEL_VERSION
    global EXPLAINER, GLOBAL_SHAP

    paths = {
        "model"   : _resolve_model_path(),
        "thresh"  : os.getenv("THRESH_PATH",   "models/threshold.pkl"),
        "features": os.getenv("FEATURES_PATH", "models/expected_features.pkl"),
        "baseline": os.getenv("BASELINE_PATH", "models/baseline_stats.pkl"),
        "medians" : os.getenv("MEDIANS_PATH",  "models/median_values.pkl"),
        "monitor" : os.getenv("MONITOR_PATH",  "models/monitor_features.pkl"),
    }

    # ── Required files — stop if missing ──
    REQUIRED = {"model", "thresh", "features", "baseline"}
    for key in REQUIRED:
        if not os.path.exists(paths[key]):
            logger.warning(f"Missing required artifact: {paths[key]}")
            return

    # ── Load required ──
    ACTIVE_MODEL      = joblib.load(paths["model"])
    ACTIVE_THRESHOLD  = float(joblib.load(paths["thresh"]))
    EXPECTED_FEATURES = list(joblib.load(paths["features"]))
    BASELINE_STATS    = dict(joblib.load(paths["baseline"]))
    MODEL_VERSION     = int(os.path.getmtime(paths["model"]))

    # ── Load optional: median_values ──
    if os.path.exists(paths["medians"]):
        MEDIAN_VALUES = dict(joblib.load(paths["medians"]))
        logger.info("✅ median_values.pkl loaded")
    else:
        MEDIAN_VALUES = {k: v.get("mean", 0.0) for k, v in BASELINE_STATS.items()}
        logger.warning("median_values.pkl missing — using baseline means as fallback")

    # ── Load optional: monitor_features ──
    if os.path.exists(paths["monitor"]):
        MONITOR_FEATURES = list(joblib.load(paths["monitor"]))
        logger.info("✅ monitor_features.pkl loaded")
    else:
        MONITOR_FEATURES = list(EXPECTED_FEATURES[:10])
        logger.warning("monitor_features.pkl missing — using top 10 features as fallback")

    # ── SHAP Explainer (TreeExplainer — Windows-safe, no Unix socket) ──
    try:
        import shap
        EXPLAINER = shap.TreeExplainer(
            ACTIVE_MODEL,
            feature_perturbation = "tree_path_dependent",
            model_output         = "raw",
            )

    
        sample_df = pd.DataFrame([MEDIAN_VALUES])[EXPECTED_FEATURES]
        sv_test   = EXPLAINER.shap_values(sample_df)

    # XGBoost binary: sv_test ممكن يكون list أو 2D array
        if isinstance(sv_test, list):
            sv_arr = sv_test[1]        # class 1 = fraud
        elif sv_test.ndim == 3:
            sv_arr = sv_test[:, :, 1]  # (n, features, classes) → fraud class
        else:
            sv_arr = sv_test           # (n, features)

        GLOBAL_SHAP = float(np.abs(sv_arr).mean()) or 1.0
        logger.info(f"✅ SHAP TreeExplainer ready — global_mean={GLOBAL_SHAP:.4f}")

    except Exception as e:
        logger.warning(f"SHAP TreeExplainer failed: {e}")
        EXPLAINER  = None
        GLOBAL_SHAP = 1.0
        


    # ── Fallback: XGBoost native importance ──
        try:
            scores   = ACTIVE_MODEL.get_booster().get_score(importance_type="gain")
            total    = max(sum(scores.values()), 1)
        # Store global — lowercase keys to match EXPECTED_FEATURES
            NATIVE_IMPORTANCE = {k.lower(): v / total for k, v in scores.items()}
            vals        = list(NATIVE_IMPORTANCE.values())
            GLOBAL_SHAP = float(np.mean(vals)) if vals else 1.0
            logger.info(f"✅ Native importance fallback — {len(NATIVE_IMPORTANCE)} features")
        except Exception as e2:
            logger.error(f"Both SHAP methods failed: {e2}")
            NATIVE_IMPORTANCE = {}

   # ── FCM artifacts ─────────────────────────────────────────
    global FCM_CENTROIDS, FCM_PCA, FCM_SCALER
    global FCM_CLUSTER_FRAUD_RATES, SHAP_CLUSTER_MEANS

    _fcm = {
        "fcm_centroids.pkl"          : "FCM_CENTROIDS",
        "fcm_pca.pkl"                : "FCM_PCA",
        "fcm_scaler.pkl"             : "FCM_SCALER",
        "fcm_cluster_fraud_rates.pkl": "FCM_CLUSTER_FRAUD_RATES",
        "shap_cluster_means.pkl"     : "SHAP_CLUSTER_MEANS",
    }
    for fname, gname in _fcm.items():
        p = f"models/{fname}"
        if os.path.exists(p):
            globals()[gname] = joblib.load(p)
            logger.info(f"✅ {fname} loaded")
        else:
            logger.warning(f"FCM artifact missing: {fname}") 


FRAUD_ORCHESTRATOR: Optional[FraudOrchestrator] = None

@app.on_event("startup")
async def startup() -> None:
    # Silence google-genai SDK asyncio cleanup bug (Python 3.13 + Windows)
    loop = asyncio.get_event_loop()
    _orig = loop.get_exception_handler()

    def _suppress(loop, ctx):
        exc = ctx.get("exception")
        if isinstance(exc, AttributeError) and "_async_httpx_client" in str(exc):
            return
        (_orig or loop.default_exception_handler)(loop, ctx)

    loop.set_exception_handler(_suppress)

    # ── Load resources first
    load_models()
    _load_forecast_snapshot()

    # ── Create orchestrator AFTER everything is ready
    global FRAUD_ORCHESTRATOR
    FRAUD_ORCHESTRATOR = FraudOrchestrator()

    # ── Bind runtime dependencies
    FRAUD_ORCHESTRATOR.bind(
        model_ref      = lambda: ACTIVE_MODEL,
        shap_fn_ref    = lambda: get_shap_score,
        explainer_ref  = lambda: EXPLAINER,
        forecast_fn    = lambda: get_forecast_risk,
        anomaly_fn     = lambda: _detect_anomaly,
        velocity_fn    = lambda: check_velocity,
        mfa_fn         = lambda: trigger_mfa,
        llm_fn         = lambda: _call_gemini,
        hourly_profile = lambda: HOURLY_PROFILE,
        global_mean    = lambda: GLOBAL_MEAN_RATE,
        features_ref   = lambda: EXPECTED_FEATURES,

    )

    logger.info("✅ FraudOrchestrator (Agentic Brain) ready")

# ── أضف بعد: async def startup() ──

def _load_forecast_snapshot() -> None:
    global HOURLY_PROFILE, GLOBAL_MEAN_RATE, MAX_RATE, ROLLING_FRAUD_RATE, FORECAST_TS
    snap_path = os.getenv("FORECAST_SNAP", "models/forecast_snapshot.pkl")
    if not os.path.exists(snap_path):
        # Static fallback — night hours have higher fraud
        for h in range(24):
            HOURLY_PROFILE[h] = 0.0015 if 0 <= h <= 6 else 0.0008
        logger.warning("Forecast snapshot missing — using static profile")
        return
    snap = joblib.load(snap_path)
    HOURLY_PROFILE     = snap.get("hourly_profile",     HOURLY_PROFILE)
    GLOBAL_MEAN_RATE   = snap.get("global_mean_rate",   0.001)
    MAX_RATE           = snap.get("max_rate",            0.015562)
    ROLLING_FRAUD_RATE = snap.get("rolling_fraud_rate",  0.001)
    FORECAST_TS        = snap.get("all_ts",              pd.DataFrame())
    logger.info("✅ Forecast snapshot loaded")


def _detect_anomaly() -> bool:
    if FORECAST_TS.empty or len(FORECAST_TS) < 30:
        return False
    try:
        recent   = FORECAST_TS["fraud_count"].iloc[-3:].mean()
        baseline = FORECAST_TS["fraud_count"].rolling(24, min_periods=6).mean().iloc[-1]
        std      = FORECAST_TS["fraud_count"].rolling(24, min_periods=6).std().iloc[-1]
        if any(np.isnan(x) for x in [recent, baseline, std]) or std == 0:
            return False
        return bool(recent > baseline + 2 * std)
    except Exception:
        return False


def get_forecast_risk(transaction_time: float = 0.0) -> float:
    """Real rolling fraud rate + hourly profile."""
    hour      = int((transaction_time // 3600) % 24)
    hour_rate = HOURLY_PROFILE.get(hour, GLOBAL_MEAN_RATE)
    risk      = (0.5 * hour_rate + 0.5 * ROLLING_FRAUD_RATE) / max(MAX_RATE, 1e-8)
    risk      = float(np.clip(risk, 0, 1))
    if _detect_anomaly():
        risk = min(risk * 1.25, 1.0)
    return risk


def get_adaptive_thresholds() -> Tuple[float, float]:
    if _detect_anomaly():
        return BLOCK_THRESHOLD_ANOMALY, REVIEW_THRESHOLD_ANOMALY
    return BLOCK_THRESHOLD_NORMAL, REVIEW_THRESHOLD_NORMAL


# ── أضف بعد: get_adaptive_thresholds ──

# ── استبدل get_shap_score كاملة ──

def get_shap_score(df: pd.DataFrame, prob: float,
                   force_run: bool = False) -> dict:
    """SHAP — TreeExplainer أو native importance fallback."""
    empty = {"shap_score_norm": 0.0, "top_drivers": []}

    if prob <= SHAP_THRESHOLD and not force_run:
        return empty

    cache_key = hashlib.md5(df.values.tobytes()).hexdigest()
    with SHAP_CACHE_LOCK:
        if cache_key in SHAP_CACHE:
            return SHAP_CACHE[cache_key]

    # ════ Path 1: TreeExplainer ════
    if EXPLAINER is not None:
        try:
            sv_raw = EXPLAINER.shap_values(df[EXPECTED_FEATURES])

            # ── Handle all XGBoost output formats ──
            if isinstance(sv_raw, list):
                sv_raw = sv_raw[1]               # binary: class 1
            if sv_raw.ndim == 3:
                sv_raw = sv_raw[:, :, 1]         # (n, feats, classes)

            shap_score = float(np.abs(sv_raw).mean())
            shap_norm  = float(np.clip(shap_score / (GLOBAL_SHAP + 1e-8), 0, 1))

            row_vals = sv_raw[0] if sv_raw.ndim == 2 else sv_raw
            contrib  = pd.DataFrame({
                "feature"   : EXPECTED_FEATURES,
                "shap_value": row_vals.tolist()
            })
            contrib["abs_val"] = contrib["shap_value"].abs()
            contrib = contrib.sort_values("abs_val", ascending=False).drop(columns=["abs_val"])

            top = contrib.head(5).to_dict(orient="records")
            for d in top:
                d["readable"] = FEATURE_MAP.get(d["feature"], "risk indicator")

            result = {"shap_score_norm": shap_norm, "top_drivers": top}

            if prob > 0.9:
                with SHAP_CACHE_LOCK:
                    if len(SHAP_CACHE) >= 200:
                        del SHAP_CACHE[next(iter(SHAP_CACHE))]
                    SHAP_CACHE[cache_key] = result

            return result

        except Exception as e:
            logger.warning(f"SHAP inference error: {e}")

    # ════ Path 2: Native XGBoost importance ════
    if NATIVE_IMPORTANCE:
        try:
            baseline   = 0.5
            scale      = abs(prob - baseline) * 2
            direction  = 1 if prob > 0.5 else -1

            top_feats = sorted(
                [(f, s) for f, s in NATIVE_IMPORTANCE.items() if f in EXPECTED_FEATURES],
                key=lambda x: x[1], reverse=True
            )[:5]

            top = []
            for feat, importance in top_feats:
                approx_shap = importance * scale * direction
                top.append({
                    "feature"    : feat,
                    "shap_value" : round(approx_shap, 4),
                    "readable"   : FEATURE_MAP.get(feat, "risk indicator"),
                })

            # Normalize score
            avg_contrib = np.mean([abs(t["shap_value"]) for t in top]) if top else 0.0
            shap_norm   = float(np.clip(avg_contrib / (GLOBAL_SHAP + 1e-8), 0, 1))

            return {"shap_score_norm": shap_norm, "top_drivers": top}

        except Exception as e:
            logger.warning(f"Native importance error: {e}")

    return empty


# ── استبدل explain_batch كاملة ──

def explain_batch(df: pd.DataFrame) -> np.ndarray:
    """Batch SHAP scores (0-1) — TreeExplainer أو native fallback."""
    n = len(df)

    # ════ Path 1: TreeExplainer ════
    if EXPLAINER is not None:
        try:
            chunk  = df[EXPECTED_FEATURES].head(500)
            sv     = EXPLAINER.shap_values(chunk)

            # Handle binary output
            if isinstance(sv, list):
                sv = sv[1]
            if sv.ndim == 3:
                sv = sv[:, :, 1]

            scores  = np.abs(sv).mean(axis=1)
            partial = np.clip(scores / (GLOBAL_SHAP + 1e-8), 0, 1)

            if len(partial) < n:
                return np.concatenate([partial, np.zeros(n - len(partial))])
            return partial

        except Exception as e:
            logger.warning(f"Batch SHAP error: {e}")

    # ════ Path 2: Native importance proxy ════
    if NATIVE_IMPORTANCE and ACTIVE_MODEL is not None:
        try:
            probs  = ACTIVE_MODEL.predict_proba(
                df[EXPECTED_FEATURES].values
            )[:, 1]
            # Scale by deviation from baseline — fraud far from 0.5 = high SHAP
            scores = np.abs(probs - 0.5) * 2
            return np.clip(scores, 0, 1)
        except Exception:
            pass

    return np.zeros(n)
# ── أضف بعد: explain_batch ──

def validate_and_clean(df: pd.DataFrame) -> Tuple[Optional[pd.DataFrame], dict]:
    """Full pipeline validation + feature engineering — never fails on engineerable columns."""
    df     = df.copy()
    report = {"original_rows": len(df), "issues": [], "status": "ok"}

    # ── Step 1: lowercase columns ──────────────────────────
    df.columns = [c.lower().strip() for c in df.columns]

    # ── Step 2: Drop target column if present ──────────────
    for target in ["class", "target", "label", "fraud", "is_fraud"]:
        if target in df.columns:
            df = df.drop(columns=[target])
            report["issues"].append(f"Dropped target column: {target}")

    # ── Step 3: Feature engineering BEFORE missing check ───
    if "log_amount" not in df.columns and "amount" in df.columns:
        df["log_amount"] = np.log1p(df["amount"].clip(lower=0))
    if "hour" not in df.columns and "time" in df.columns:
        df["hour"] = (df["time"] // 3600) % 24
    if "is_night" not in df.columns and "hour" in df.columns:
        df["is_night"] = df["hour"].between(0, 6).astype(int)
    if "amount_bucket" not in df.columns and "amount" in df.columns:
        df["amount_bucket"] = pd.cut(
            df["amount"], bins=[-1, 10, 100, np.inf], labels=[0, 1, 2]
        ).astype(int)

    # ── Step 4: Fill any still-missing features with median ─
    missing = set(EXPECTED_FEATURES) - set(df.columns)
    if missing:
        report["issues"].append(f"Filled {len(missing)} missing features with median")
        for col in missing:
            df[col] = float(MEDIAN_VALUES.get(col, 0.0))

    # ── Step 5: Drop extra columns ──────────────────────────
    extra = set(df.columns) - set(EXPECTED_FEATURES)
    if extra:
        df = df.drop(columns=list(extra), errors="ignore")

    # ── Step 6: Convert to numeric ──────────────────────────
    for col in EXPECTED_FEATURES:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # ── Step 7: Fill nulls ──────────────────────────────────
    null_count = int(df.isnull().sum().sum())
    if null_count > 0:
        report["issues"].append(f"Nulls filled: {null_count}")
        meds = pd.Series(MEDIAN_VALUES) if MEDIAN_VALUES else df.median(numeric_only=True)
        df   = df.fillna(meds)

    # ── Step 8: Remove negative amounts ─────────────────────
    if "amount" in df.columns:
        neg = int((df["amount"] < 0).sum())
        if neg:
            report["issues"].append(f"Negative amounts removed: {neg}")
            df = df[df["amount"] >= 0]

    report["clean_rows"] = len(df)
    return df[EXPECTED_FEATURES], report

# ── أضف بعد: validate_and_clean ──

def check_drift(df: pd.DataFrame, threshold: float = 0.3) -> dict:
    """Vectorized drift detection on monitor features."""
    if not MONITOR_FEATURES or not BASELINE_STATS:
        return {"drift_detected": False, "severity": "NONE",
                "drifted_features": [], "drift_ratio": 0.0}

    mf    = [f for f in MONITOR_FEATURES if f in df.columns]
    base  = np.array([BASELINE_STATS[c]["mean"] for c in mf])
    stds  = np.array([BASELINE_STATS[c]["std"] + 1e-8 for c in mf])
    curr  = df[mf].mean().values
    scores= np.abs(curr - base) / stds

    mask    = scores > threshold
    drifted = [mf[i] for i in np.where(mask)[0]]
    d_scores= {mf[i]: round(float(scores[i]), 3) for i in np.where(mask)[0]}
    ratio   = len(drifted) / max(len(mf), 1)

    return {
        "drift_detected"     : ratio > 0.3,
        "drift_ratio"        : round(ratio, 3),
        "overall_drift_score": round(float(np.mean(list(d_scores.values()))) if d_scores else 0.0, 3),
        "drifted_features"   : drifted,
        "drift_scores"       : d_scores,
        "severity"           : ("HIGH" if ratio > 0.5 else "LOW") if ratio > 0.3 else "NONE",
    }


def retrain_job(df_new: pd.DataFrame, drift: dict) -> None:
    """Background retrain — runs in separate thread."""
    global ACTIVE_MODEL, ACTIVE_THRESHOLD, EXPLAINER, GLOBAL_SHAP
    global LAST_RETRAIN_TIME, MODEL_VERSION

    with RETRAIN_LOCK:
        if time.time() - LAST_RETRAIN_TIME < 3600:
            logger.info("Retrain skipped — cooldown")
            return
        if not drift.get("drift_detected"):
            return
        try:
            from xgboost import XGBClassifier
            from sklearn.metrics import precision_recall_curve

            logger.info(f"Retraining — drifted: {drift['drifted_features']}")

            X_old = joblib.load("models/X_train_cache.pkl") if os.path.exists("models/X_train_cache.pkl") else None
            y_old = joblib.load("models/y_train_cache.pkl") if os.path.exists("models/y_train_cache.pkl") else None
            if X_old is None:
                logger.warning("Train cache missing — skip retrain")
                return

            if "class" in df_new.columns:
                X_all = np.vstack([X_old, df_new[EXPECTED_FEATURES].values])
                y_all = np.concatenate([y_old, df_new["class"].values])
            else:
                X_all, y_all = X_old, y_old

            spw = max(1, (y_all == 0).sum() / max((y_all == 1).sum(), 1))
            new_model = XGBClassifier(
                n_estimators=300, max_depth=6, learning_rate=0.05,
                subsample=0.8, colsample_bytree=0.8,
                scale_pos_weight=spw, eval_metric="logloss",
                random_state=42, n_jobs=-1,
            )
            new_model.fit(X_all, y_all)

            new_thresh = ACTIVE_THRESHOLD
            if os.path.exists("models/X_test_cache.pkl"):
                X_t = joblib.load("models/X_test_cache.pkl")
                y_t = joblib.load("models/y_test_cache.pkl")
                probs = new_model.predict_proba(X_t)[:, 1]
                prec, rec, ths = precision_recall_curve(y_t, probs)
                f2  = 4 * (prec * rec) / (4 * prec + rec + 1e-8)
                new_thresh = float(ths[np.argmax(f2)])

            ACTIVE_MODEL      = new_model
            ACTIVE_THRESHOLD  = new_thresh
            MODEL_VERSION     = int(time.time())
            LAST_RETRAIN_TIME = time.time()

            joblib.dump(new_model,  f"models/model_{MODEL_VERSION}.pkl")
            joblib.dump(new_model,  "models/model_latest.pkl")
            joblib.dump(new_thresh, "models/threshold.pkl")

            # Refresh SHAP
            try:
                import shap
                EXPLAINER   = shap.TreeExplainer(ACTIVE_MODEL)
                sample_df   = pd.DataFrame([MEDIAN_VALUES])[EXPECTED_FEATURES]
                sv          = EXPLAINER.shap_values(sample_df)
                GLOBAL_SHAP = float(np.abs(sv).mean()) or 1.0
            except Exception as e:
                logger.warning(f"SHAP refresh failed: {e}")

            logger.info(f"✅ Retrain done — v{MODEL_VERSION} | thresh={new_thresh:.4f}")
        except Exception as e:
            logger.error(f"Retrain failed: {e}")


# ── أضف بعد: retrain_job ──

def _send_email(to: str, subject: str, html: str) -> bool:
    if not EMAIL_SENDER or not EMAIL_PASSWORD:
        logger.warning("Email credentials not configured")
        return False
    try:
        m           = MIMEMultipart("alternative")
        m["From"]   = f"FraudGuard AI <{EMAIL_SENDER}>"
        m["To"]     = to
        m["Subject"]= subject
        m.attach(MIMEText(html, "html"))
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as s:
            s.login(EMAIL_SENDER, EMAIL_PASSWORD)
            s.sendmail(EMAIL_SENDER, to, m.as_string())
        logger.info(f"✅ Email → {to}")
        return True
    except Exception as e:
        logger.error(f"Email failed: {e}")
        return False


def send_fraud_alert(result: dict) -> bool:
    """Internal fraud alert email — full dark theme."""
    risk_pct = int(result.get("total_risk", 0) * 100)
    action_text = {
        "BLOCK 🚫" : "⚡ RECOMMENDED ACTION: BLOCK TRANSACTION",
        "REVIEW ⚠️": "⚠️ RECOMMENDED ACTION: MANUAL REVIEW REQUIRED",
        }.get(result.get("decision",""), "ℹ️ TRANSACTION FLAGGED FOR REVIEW")
    drivers_html = ""
    for i, d in enumerate(result.get("top_drivers", [])[:5]):
        feat  = d.get("readable", d.get("feature", ""))
        val   = d.get("shap_value", 0)
        bar_w = min(int(abs(val) * 20), 100)
        color = "#ff2d55" if val >= 0 else "#30d158"
        drivers_html += f"""
        <tr style="border-bottom:1px solid #1c1c2e;">
          <td style="padding:10px 8px;color:#a0a0b0;font-size:12px;">#{i+1}</td>
          <td style="padding:10px 8px;color:#e0e0ff;font-weight:600;">{feat}</td>
          <td style="padding:10px 8px;">
            <div style="background:#0d0d1a;border-radius:4px;height:7px;width:100px;">
              <div style="background:{color};width:{bar_w}%;height:7px;border-radius:4px;"></div>
            </div>
          </td>
          <td style="padding:10px 8px;color:{color};font-weight:700;font-size:12px;">{val:+.4f}</td>
        </tr>"""

    comp = result.get("risk_components", {})
    comp_html = ""
    for label, val in [("Model Prob", comp.get("model",0)),
                        ("SHAP Score", comp.get("shap",0)),
                        ("Forecast",   comp.get("forecast",0)),
                        ("LLM Score",  comp.get("llm_score",0))]:
        if val == 0 and label in ("SHAP Score","LLM Score"):
            continue
        pct   = min(int(val*100), 100)
        color = "#bf5af2" if "SHAP" in label else "#ff2d55" if "Prob" in label \
                else "#a855f7" if "LLM" in label else "#ff9f0a"
        comp_html += f"""
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;
                      color:#a0a0b0;font-size:12px;margin-bottom:3px;">
            <span>{label}</span><span style="color:{color};">{val:.4f}</span>
          </div>
          <div style="background:#0d0d1a;border-radius:6px;height:6px;">
            <div style="background:{color};width:{pct}%;height:6px;border-radius:6px;"></div>
          </div>
        </div>"""

    html = f"""<!DOCTYPE html><html><head><style>
@keyframes pulse{{0%{{box-shadow:0 0 0 0 rgba(255,45,85,.4)}}
  70%{{box-shadow:0 0 0 12px rgba(255,45,85,0)}}100%{{box-shadow:0 0 0 0 rgba(255,45,85,0)}}}}
@keyframes glow{{0%,100%{{text-shadow:0 0 10px #ff2d55,0 0 20px #ff2d55}}
  50%{{text-shadow:0 0 20px #ff2d55,0 0 40px #ff2d55}}}}
</style></head>
<body style="margin:0;padding:20px;background:#050508;
             font-family:'Segoe UI',Arial,sans-serif;">
<div style="max-width:660px;margin:auto;">
  <div style="background:linear-gradient(135deg,#0d0d1a,#1a0d2e);
              border-radius:16px 16px 0 0;padding:28px;text-align:center;
              border:1px solid #2d1b4e;border-bottom:none;position:relative;">
    <div style="position:absolute;top:0;left:0;right:0;height:3px;
                background:linear-gradient(90deg,#ff2d55,#bf5af2,#ff2d55);"></div>
    <div style="display:inline-block;background:rgba(255,45,85,.15);
                border:1px solid #ff2d55;border-radius:50%;
                width:56px;height:56px;line-height:56px;font-size:26px;
                margin-bottom:12px;animation:pulse 2s infinite;">🚨</div>
    <h1 style="margin:0;color:#ff2d55;font-size:22px;font-weight:800;
               letter-spacing:2px;animation:glow 2s ease-in-out infinite;">FRAUD ALERT</h1>
    <p style="margin:6px 0 0;color:#a0a0b0;font-size:12px;letter-spacing:1px;">
       FRAUDGUARD AI — SECURITY SYSTEM</p>
  </div>
  <div style="background:#1a0d1a;border:1px solid #2d1b4e;border-top:none;
              padding:18px 26px;display:flex;align-items:center;gap:18px;">
    <div style="background:linear-gradient(135deg,#ff2d55,#bf2040);
                border-radius:10px;padding:12px 22px;text-align:center;
                min-width:110px;box-shadow:0 4px 18px rgba(255,45,85,.4);">
      <div style="color:#fff;font-size:26px;font-weight:900;">{risk_pct}%</div>
      <div style="color:rgba(255,255,255,.75);font-size:10px;letter-spacing:1px;">RISK</div>
    </div>
    <div style="flex:1;">
      <div style="color:#ff2d55;font-size:17px;font-weight:700;margin-bottom:6px;">
        {result.get("decision","")}</div>
      <div style="background:#0d0d1a;border-radius:6px;height:8px;overflow:hidden;">
        <div style="background:linear-gradient(90deg,#ff2d55,#bf5af2);
                    width:{risk_pct}%;height:8px;border-radius:6px;"></div>
      </div>
      <div style="color:#a0a0b0;font-size:11px;margin-top:4px;">
        ID: <b style="color:#e0e0ff;">{result.get("row_id","N/A")}</b> |
        Path: <b style="color:#bf5af2;">{result.get("path","")}</b></div>
    </div>
  </div>
  <div style="background:#0f0f1a;border:1px solid #2d1b4e;
              border-top:none;padding:22px 26px;">
    <h3 style="color:#bf5af2;margin:0 0 12px;font-size:12px;
               letter-spacing:2px;text-transform:uppercase;">Transaction Details</h3>
    <table style="width:100%;border-collapse:collapse;">
      <tr><td style="padding:7px 0;color:#a0a0b0;font-size:12px;">Probability</td>
          <td style="color:#ff2d55;font-weight:700;">{result.get("probability",0):.4f}</td></tr>
      <tr><td style="padding:7px 0;color:#a0a0b0;font-size:12px;">SHAP Score</td>
          <td style="color:#bf5af2;font-weight:600;">{result.get("shap_score",0):.4f}</td></tr>
      <tr><td style="padding:7px 0;color:#a0a0b0;font-size:12px;">Forecast Risk</td>
          <td style="color:#ff9f0a;font-weight:600;">{result.get("forecast_risk",0):.4f}</td></tr>
      <tr><td style="padding:7px 0;color:#a0a0b0;font-size:12px;">Uncertainty</td>
          <td style="color:#e0e0ff;">{result.get("uncertainty",0):.4f}</td></tr>
      <tr><td style="padding:7px 0;color:#a0a0b0;font-size:12px;">Band</td>
          <td style="color:#30d158;font-weight:600;">{result.get("confidence_band","")}</td></tr>
    </table>
  </div>
  <div style="background:#0d0d1a;border:1px solid #2d1b4e;
              border-top:none;padding:22px 26px;">
    <h3 style="color:#bf5af2;margin:0 0 12px;font-size:12px;
               letter-spacing:2px;text-transform:uppercase;">Risk Breakdown</h3>
    {comp_html}
  </div>
  <div style="background:#0f0f1a;border:1px solid #2d1b4e;
              border-top:none;padding:22px 26px;">
    <h3 style="color:#bf5af2;margin:0 0 12px;font-size:12px;
               letter-spacing:2px;text-transform:uppercase;">Top Fraud Indicators</h3>
    <table style="width:100%;border-collapse:collapse;">
      <tr style="border-bottom:1px solid #1c1c2e;">
        <th style="padding:7px;color:#606080;font-size:10px;text-align:left;">#</th>
        <th style="padding:7px;color:#606080;font-size:10px;text-align:left;">INDICATOR</th>
        <th style="padding:7px;color:#606080;font-size:10px;text-align:left;">IMPACT</th>
        <th style="padding:7px;color:#606080;font-size:10px;text-align:left;">VALUE</th>
      </tr>
      {drivers_html}
    </table>
  </div>
  <div style="background:#0d0d1a;border:1px solid #2d1b4e;
              border-top:none;padding:22px 26px;">
    <div style="background:linear-gradient(135deg,#1a0d2e,#2d1b4e);
                border-left:3px solid #bf5af2;border-radius:6px;padding:14px;">
      <div style="color:#bf5af2;font-size:10px;letter-spacing:2px;margin-bottom:6px;">
         AI EXPLANATION</div>
      <div style="color:#e0e0ff;font-size:13px;line-height:1.6;">
        {result.get("explanation","")}</div>
    </div>
  </div>
  <div style="background:#1a0508;border:1px solid #2d1b4e;border-top:1px solid #ff2d5533;
              padding:22px 26px;text-align:center;">
    <div style="background:linear-gradient(135deg,#ff2d55,#bf2040);border-radius:10px;
                padding:16px;box-shadow:0 4px 22px rgba(255,45,85,.35);">
      <div style="color:#fff;font-size:15px;font-weight:800;letter-spacing:1px;">
         {action_text}</div>
    </div>
  </div>
  <div style="background:#080810;border:1px solid #2d1b4e;border-top:none;
              border-radius:0 0 16px 16px;padding:16px 26px;text-align:center;">
    <div style="color:#404060;font-size:10px;line-height:1.8;">
      <span style="color:#bf5af2;">FraudGuard AI</span> — XGBoost + SHAP<br>
      Model: {result.get("model_version","")} | {result.get("timestamp","")}
    </div>
  </div>
</div></body></html>"""
    return _send_email(
        EMAIL_RECEIVER or EMAIL_SENDER,
        f"🚨 FRAUD ALERT — {risk_pct}% Risk | ID: {result.get('row_id','N/A')}",
        html
    )


def send_customer_alert(customer_email: str, result: dict,
                        report_text: str = "") -> bool:
    """Simplified customer notification email."""
    color = ("#ff2d55" if "BLOCK"  in result.get("decision","") else
             "#ff9f0a" if "REVIEW" in result.get("decision","") else "#30d158")
    icon  = ("🚫"      if "BLOCK"  in result.get("decision","") else
             "⚠️"      if "REVIEW" in result.get("decision","") else "✅")
    body  = report_text or result.get("explanation", "Suspicious activity detected.")
    html  = f"""<!DOCTYPE html><html>
<body style="margin:0;padding:20px;background:#050508;font-family:Arial,sans-serif;">
  <div style="max-width:480px;margin:auto;background:#0f0f1a;
              border-radius:16px;border:1px solid #2d1b4e;">
    <div style="padding:24px;text-align:center;border-bottom:2px solid {color};">
      <h2 style="margin:0;color:{color};">🏦 FraudGuard AI</h2>
      <p style="margin:4px 0 0;color:#a0a0b0;font-size:11px;">Transaction Security Alert</p>
    </div>
    <div style="padding:24px;text-align:center;color:#e0e0ff;">
      <div style="font-size:38px;margin-bottom:8px;">{icon}</div>
      <h3 style="margin:0 0 10px;color:{color};">{result.get("decision","")}</h3>
      <p style="line-height:1.7;font-size:14px;">{body}</p>
    </div>
    <div style="background:#080810;padding:14px;text-align:center;color:#404060;
                font-size:10px;border-radius:0 0 16px 16px;">
      FraudGuard AI | {result.get("timestamp","")}
    </div>
  </div>
</body></html>"""
    return _send_email(customer_email, "Transaction Alert — Action Required", html)


def should_send_alert(result: dict) -> bool:
    """Delegated to email_mfa — dedup + smart trigger."""
    from email_mfa import should_send_alert as _should
    return _should(result)

# ── أضف بعد: should_send_alert ──

def _llm_cache_set(key: str, val: str) -> None:
    with LLM_CACHE_LOCK:
        if len(LLM_CACHE) >= LLM_CACHE_MAX:
            del LLM_CACHE[next(iter(LLM_CACHE))]
        LLM_CACHE[key] = val


def _call_gemini(
    prompt: str,
    max_tokens: int = 200,
    _retries: int = 2
) -> str:
    global LAST_LLM_CALL

    if not LLM_AVAILABLE or not LLM_ENABLED:
        return ""

    # ── Rate limiting ─────────────────────────────
    with API_LOCK:
        elapsed = time.time() - LAST_LLM_CALL
        sleep_needed = max(0.0, LLM_MIN_INTERVAL - elapsed)
        LAST_LLM_CALL = time.time()   # ← claim the slot first, then sleep outside

    if sleep_needed > 0.0:            # ← النوم خارج اللوك تماماً
        time.sleep(sleep_needed)

    # ── Retry loop ────────────────────────────────
    for attempt in range(_retries + 1):
        try:
            resp = _gemini_client.models.generate_content(
                model=LLM_MODEL,
                contents=[prompt],
                config=_genai_types.GenerateContentConfig(
                    max_output_tokens=250,
                    temperature=0.3,
                ),
            )

            if not resp or not getattr(resp, "text", None):
                return ""

            return resp.text.strip()

        except Exception as e:
            err_str = str(e)

            is_500 = (
                "500" in err_str or
                "INTERNAL" in err_str
            )

            is_429 = (
                "429" in err_str or
                "RATE" in err_str
            )

            # ── Rate limit fallback ───────────────
            if is_429:
                logger.warning(
                    "Gemini rate-limited — using fallback"
                )
                return ""

            # ── Retry on 500 ─────────────────────
            if is_500 and attempt < _retries:
                wait = 0.5 * (2 ** attempt)

                logger.debug(
                    f"Gemini 500 retry "
                    f"{attempt + 1}/{_retries} "
                    f"in {wait:.1f}s"
                )

                time.sleep(wait)
                continue

            # ── Final failure ────────────────────
            if is_500:
                logger.warning(
                    "Gemini 500 after retries"
                )
            else:
                logger.warning(f"LLM error: {e}")

            return ""

    return ""

def generate_report(result: dict) -> str:
    """LLM-powered English report with fallback template."""
    dmap  = {"BLOCK 🚫":"BLOCKED","REVIEW ⚠️":"UNDER REVIEW","ALLOW ✅":"APPROVED"}
    dec   = result.get("decision","")
    clean = dmap.get(dec, dec)
    risk  = result.get("total_risk", 0.0)

    key = hashlib.md5(f"rpt_{clean}_{risk:.3f}".encode()).hexdigest()
    with LLM_CACHE_LOCK:
        if key in LLM_CACHE:
            return LLM_CACHE[key]

    readable = []
    for d in result.get("top_drivers", [])[:3]:
        r = d.get("readable") or FEATURE_MAP.get(d.get("feature",""), "")
        if r:
            readable.append(r)
    reasons = ", ".join(readable) if readable else "suspicious activity patterns"

    fallback = (f"We detected {reasons} in this transaction. "
                f"Risk score: {risk:.2f}/1.00. "
                f"Recommended Action: {clean}")

    prompt = f"""Bank fraud detection AI. Write a short customer alert.
Decision: {clean} | Risk: {risk:.2f}/1.00
Reasons: {reasons}
Rules:
- Professional English, max 3 sentences
- NEVER say V14, V10, V12 or any feature code
- Use: "unusual patterns", "risk indicators"
- End EXACTLY with: "Recommended Action: {clean}"
Reply with message only, no subject line."""

    text = _call_gemini(prompt, max_tokens=150) or fallback
    _llm_cache_set(key, text)
    return text


# ── أضف بعد: generate_report ──

def update_user_profile(card_id: str, result: dict) -> None:
    """Update per-card risk history."""
    with USER_PROFILE_LOCK:
        p = USER_RISK_PROFILES[card_id]
        p["total_txns"] += 1
        p["last_seen"]   = result.get("timestamp")
        risk = result.get("total_risk", 0.0)
        p["avg_risk"]    = (p["avg_risk"] * (p["total_txns"]-1) + risk) / p["total_txns"]
        p["max_risk"]    = max(p["max_risk"], risk)

        if "BLOCK"  in result.get("decision",""):  p["fraud_count"]  += 1
        if "REVIEW" in result.get("decision",""):  p["review_count"] += 1

        # Keep last 20 transactions
        p["history"].append({
            "ts"      : result.get("timestamp"),
            "risk"    : round(risk, 4),
            "decision": result.get("decision",""),
            "path"    : result.get("path",""),
        })
        if len(p["history"]) > 20:
            p["history"].pop(0)


def check_mfa_required(card_id: str, result: dict) -> bool:
    """Return True if MFA should be triggered instead of hard BLOCK."""
    band = result.get("confidence_band","")
    dec  = result.get("decision","")

    # MFA for medium-high risk (not critical)
    if band in ("medium","high") and "BLOCK" in dec:
        return True

    # MFA if user has clean history but sudden high-risk tx
    with USER_PROFILE_LOCK:
        p = USER_RISK_PROFILES.get(card_id, {})
        if p.get("total_txns", 0) > 5 and p.get("fraud_count", 0) == 0:
            if result.get("total_risk", 0) > 0.5:
                return True
    return False


def trigger_mfa(card_id: str, result: dict,
                customer_email: str = "") -> dict:
    """
    Production MFA trigger — delegates to mfa_service.
    Uses crypto-secure OTP + auto-sends email.
    """
    if not customer_email:
        with USER_PROFILE_LOCK:
            p = USER_RISK_PROFILES.get(card_id, {})
            customer_email = p.get("email", "")

    return mfa_service.trigger(
        card_id        = card_id,
        result         = result,
        customer_email = customer_email,
    )


# ── أضف بعد: trigger_mfa ──

def auto_learn_from_logs(log_path: str = "logs/fraud_decisions.log",
                          min_records: int = 1000) -> dict:
    """
    Auto-Learning System:
    Reads audit logs → extracts confirmed fraud cases
    → triggers background retrain if enough new data.
    """
    if not os.path.exists(log_path):
        return {"status": "no_logs", "records": 0}

    records = []
    try:
        with open(log_path, "r", encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    # Extract JSON from log line (skip timestamp prefix)
                    start = line.find("{")
                    if start >= 0:
                        records.append(json.loads(line[start:]))
                except Exception:
                    continue
    except Exception as e:
        return {"status": "error", "message": str(e)}

    if len(records) < min_records:
        return {"status": "insufficient_data", "records": len(records)}

    # Build pseudo-labeled dataset from high-confidence decisions
    rows = []
    for r in records:
        if r.get("confidence_band") in ("critical","high") and \
           r.get("llm_override") is False:
            label = 1 if "BLOCK" in r.get("decision","") else 0
            rows.append({
                "total_risk"     : r.get("total_risk", 0),
                "probability"    : r.get("probability", 0),
                "shap_score"     : r.get("shap_score", 0),
                "forecast_risk"  : r.get("forecast_risk", 0),
                "pseudo_label"   : label,
            })

    return {
        "status"        : "analyzed",
        "total_records" : len(records),
        "high_confidence": len(rows),
        "fraud_in_logs" : sum(r["pseudo_label"] for r in rows),
        "message"       : f"Found {len(rows)} high-confidence records for potential retraining",
    }



# ── Constants ──
BLOCK_THRESHOLD       = 0.8
REVIEW_THRESHOLD      = 0.6
UNCERTAINTY_THRESHOLD = 0.3
LLM_HARD_BLOCK_FLAGS  = 2
SHAP_THRESHOLD        = 0.5

FEATURE_MAP = {
    "v14": "unusual transaction pattern",
    "v10": "atypical behavioral signal",
    "v12": "suspicious activity marker",
    "v4" : "irregular transaction behavior",
    "v3" : "anomalous spending pattern",
    "v11": "behavioral anomaly",
    "v8" : "suspicious transaction signal",
    "amount"    : "unusually large transaction amount",
    "log_amount": "high value transaction",
    "is_night"  : "transaction at unusual hours",
    "hour"      : "suspicious transaction timing",
}

VELOCITY_TRACKER: Dict[str, List[float]] = {}
VELOCITY_MAX_TXN = 3
VELOCITY_WINDOW  = 600

# ── Adaptive Thresholds ──
BLOCK_THRESHOLD_NORMAL   = 0.8
BLOCK_THRESHOLD_ANOMALY  = 0.6
REVIEW_THRESHOLD_NORMAL  = 0.6
REVIEW_THRESHOLD_ANOMALY = 0.4
UNCERTAINTY_THRESHOLD    = 0.3
SHAP_THRESHOLD           = 0.5

CONFIDENCE_BANDS = {"critical": 0.80, "high": 0.60, "medium": 0.40, "low": 0.0}

# ── Global ML State ──
EXPLAINER    = None
GLOBAL_SHAP  = 1.0
NATIVE_IMPORTANCE: Dict[str, float] = {}   # ← أضف السطر ده
# ── FCM Cluster State ──
FCM_CENTROIDS:          Optional[np.ndarray] = None
FCM_PCA                 = None
FCM_SCALER              = None
FCM_CLUSTER_FRAUD_RATES: dict = {}
SHAP_CLUSTER_MEANS:      dict = {}
CLUSTER_ARTIFACTS:       Optional[dict] = None

SHAP_CACHE: Dict = {}
SHAP_CACHE_LOCK  = threading.Lock()
MEDIAN_VALUES: Dict = {}
MONITOR_FEATURES: List[str] = []
MODEL_VERSION: int = 0
LAST_RETRAIN_TIME: float = 0.0
RETRAIN_LOCK = threading.Lock()

# ── Forecast State ──
HOURLY_PROFILE:    Dict[int, float] = {}
GLOBAL_MEAN_RATE:  float = 0.001
MAX_RATE:          float = 0.015562
ROLLING_FRAUD_RATE: float = 0.001
FORECAST_TS:       pd.DataFrame = pd.DataFrame()

# ── User Risk Profiles ──
USER_RISK_PROFILES: Dict[str, dict] = collections.defaultdict(lambda: {
    "total_txns": 0, "fraud_count": 0, "review_count": 0,
    "avg_risk": 0.0, "max_risk": 0.0, "last_seen": None,
    "mfa_triggered": 0, "history": []
})
USER_PROFILE_LOCK = threading.Lock()

# ── MFA Pending ──
MFA_PENDING: Dict[str, dict] = {}
MFA_LOCK    = threading.Lock()

# ── Email ──
EMAIL_SENDER   = "thelastking398@gmail.com"
EMAIL_PASSWORD = "pfsv zgmz bjiv flgn"
EMAIL_RECEIVER = "mohamed80598@gmail.com"

# ── LLM ──
LLM_CACHE:     Dict  = {}
LLM_CACHE_LOCK       = threading.Lock()
API_LOCK             = threading.Lock()
LAST_LLM_CALL: float = 0.0
LLM_MIN_INTERVAL     = 1.5
LLM_CACHE_MAX        = 500
LLM_ENABLED          = os.getenv("LLM_ENABLED", "true").lower() == "true"
LLM_MODEL = "gemma-4-31b-it"
try:
    from google import genai as _genai

    from google.genai import types as _genai_types
    _gemini_client = _genai.Client(api_key="AIzaSyClI2aXdzVoEegs_DEZD4sgaWfIPDE9JkA")
    LLM_AVAILABLE  = True
except Exception:
    LLM_AVAILABLE  = False

# ── Pydantic Models ──
class Transaction(BaseModel):
    amount: float
    time: Optional[float] = 0.0
    v1: Optional[float] = None
    v2: Optional[float] = None
    v3: Optional[float] = None
    v4: Optional[float] = None
    v5: Optional[float] = None
    v6: Optional[float] = None
    v7: Optional[float] = None
    v8: Optional[float] = None
    v9: Optional[float] = None
    v10: Optional[float] = None
    v11: Optional[float] = None
    v12: Optional[float] = None
    v13: Optional[float] = None
    v14: Optional[float] = None
    v15: Optional[float] = None
    v16: Optional[float] = None
    v17: Optional[float] = None
    v18: Optional[float] = None
    v19: Optional[float] = None
    v20: Optional[float] = None
    v21: Optional[float] = None
    v22: Optional[float] = None
    v23: Optional[float] = None
    v24: Optional[float] = None
    v25: Optional[float] = None
    v26: Optional[float] = None
    v27: Optional[float] = None
    v28: Optional[float] = None
    card_id: Optional[str] = None
    text_description: Optional[str] = None

class ChatRequest(BaseModel):
    message: str
    transaction_id: Optional[str] = None
    decision_context: Optional[Dict] = None

class ChatResponse(BaseModel):
    reply: str
    language_detected: str


# ── أضف بعد class ChatResponse (السطر 948) ──

class KafkaTransaction(BaseModel):
    """Kafka producer format — matches the real producer output."""
    transaction_id: int
    user_id:        int
    amount:         float
    currency:       str   = "EGP"
    location:       str   = ""
    device:         str   = "web"
    timestamp:      str   = ""
    is_fraud:       int   = 0
    time:           Optional[float] = None   # ← raw Time من الـ CSV

    # ── V-features من creditcard.csv ──
    v1:  Optional[float] = None
    v2:  Optional[float] = None
    v3:  Optional[float] = None
    v4:  Optional[float] = None
    v5:  Optional[float] = None
    v6:  Optional[float] = None
    v7:  Optional[float] = None
    v8:  Optional[float] = None
    v9:  Optional[float] = None
    v10: Optional[float] = None
    v11: Optional[float] = None
    v12: Optional[float] = None
    v13: Optional[float] = None
    v14: Optional[float] = None
    v15: Optional[float] = None
    v16: Optional[float] = None
    v17: Optional[float] = None
    v18: Optional[float] = None
    v19: Optional[float] = None
    v20: Optional[float] = None
    v21: Optional[float] = None
    v22: Optional[float] = None
    v23: Optional[float] = None
    v24: Optional[float] = None
    v25: Optional[float] = None
    v26: Optional[float] = None
    v27: Optional[float] = None
    v28: Optional[float] = None

    def to_transaction(self) -> "Transaction":
        """Map Kafka message → Transaction model — passes V1-V28 للموديل."""
        from datetime import datetime as dt

        # ── Timestamp ──────────────────────────────────────────
        try:
            t = dt.fromisoformat(self.timestamp).timestamp() \
                if self.timestamp else time.time()
        except Exception:
            t = time.time()

        # استخدم raw Time من الـ CSV لو موجود (أدق للـ hour calculation)
        raw_time = self.time if self.time is not None else t

        # ── Text description للـ LLM ───────────────────────────
        hour = dt.fromtimestamp(t).hour
        parts = []
        if hour <= 5 or hour >= 22:
            parts.append("midnight")
        loc = self.location.strip()
        parts.append(f"location={loc}" if loc else "")
        parts.append(f"device={self.device}")
        text = " ".join(p for p in parts if p)

        return Transaction(
            amount           = self.amount,
            time             = raw_time,
            card_id          = f"USER_{self.user_id}",
            text_description = text,
            # ── V1-V28 — الأهم للموديل ──
            v1=self.v1,   v2=self.v2,   v3=self.v3,   v4=self.v4,
            v5=self.v5,   v6=self.v6,   v7=self.v7,   v8=self.v8,
            v9=self.v9,   v10=self.v10, v11=self.v11, v12=self.v12,
            v13=self.v13, v14=self.v14, v15=self.v15, v16=self.v16,
            v17=self.v17, v18=self.v18, v19=self.v19, v20=self.v20,
            v21=self.v21, v22=self.v22, v23=self.v23, v24=self.v24,
            v25=self.v25, v26=self.v26, v27=self.v27, v28=self.v28,
        )

class TextPredictRequest(BaseModel):
    text: str   # e.g. "User spent 9000$ at midnight in a new country"


class FCMVisualizationRequest(BaseModel):
    n_samples: int = 1000



# ── Prediction Stats ──
prediction_stats = {
    "total": 0, "blocks": 0, "reviews": 0, "allows": 0,
    "llm_overrides": 0, "velocity_blocks": 0,
    "start_time": datetime.now().isoformat()
}
_stats_lock = threading.Lock()   # ← thread-safe counter

def _increment_stats(key: str, amount: int = 1) -> None:
    with _stats_lock:
        prediction_stats[key] = prediction_stats.get(key, 0) + amount



def get_fcm_signal(df: pd.DataFrame) -> dict:
    """
    Live FCM inference — NO re-clustering.
    Uses saved centroids + PCA + scaler from training cycle.
    Returns S, µ(predicted), cluster, arima_mult.
    """
    _default = {"S": 0.5, "mu_pred": 0.5, "cluster": 0,
                "arima_mult": 0.5, "membership": [0.333, 0.333, 0.334]}

    if FCM_CENTROIDS is None or FCM_PCA is None or FCM_SCALER is None:
        return _default

    try:
        import skfuzzy as fuzz

        # Only original features (no fcm_* columns)
        base_cols = [f for f in EXPECTED_FEATURES
             if not f.startswith("fcm_")]
        X_scaled = FCM_SCALER.transform(df[base_cols].values)  # (1, 33)
        X_pca    = FCM_PCA.transform(X_scaled)                 # (1, 5)

        # Predict membership using saved centroids (مش re-fit)
        _, u, _, _, _, _, _ = fuzz.cluster.cmeans_predict(
            X_pca.T,                      # (5, 1)
            FCM_CENTROIDS,                # (3, 5)
            m=2, error=0.005, maxiter=100
        )
        membership = u.T[0]              # (3,)
        cluster    = int(np.argmax(membership))
        mu_pred    = float(membership[cluster])

        # S: cluster severity = fraud_rate / max_fraud_rate
        _max_r    = max(FCM_CLUSTER_FRAUD_RATES.values(), default=1e-8)
        S         = float(FCM_CLUSTER_FRAUD_RATES.get(cluster, 0.5) / _max_r)
        arima_mult = float(min(S * 1.2, 1.0))  # trend proxy

        return {
            "S"          : S,
            "mu_pred"    : mu_pred,
            "cluster"    : cluster,
            "arima_mult" : arima_mult,
            "membership" : membership.tolist(),
        }
    except Exception as e:
        logger.warning(f"FCM signal error: {e}")
        return _default


def get_shap_cosine_similarity(shap_values: np.ndarray, cluster: int) -> float:
    """
    SHAP cosine similarity — prediction reliability signal.
    Measures how much current transaction looks like typical fraud in its cluster.
    High value → transaction strongly resembles known fraud patterns.
    """
    if not SHAP_CLUSTER_MEANS or cluster not in SHAP_CLUSTER_MEANS:
        return 0.5
    try:
        mean_shap = np.array(SHAP_CLUSTER_MEANS[cluster])
        curr_shap = shap_values[:len(mean_shap)]
        n_curr    = np.linalg.norm(curr_shap)
        n_mean    = np.linalg.norm(mean_shap)
        if n_curr < 1e-10 or n_mean < 1e-10:
            return 0.5
        cos = np.dot(curr_shap, mean_shap) / (n_curr * n_mean)
        return float(np.clip((cos + 1) / 2, 0, 1))  # normalize [-1,1] → [0,1]
    except Exception:
        return 0.5
    

# ── Helpers ──
def build_features(tx: Transaction) -> pd.DataFrame:
    """Build feature DataFrame from transaction."""
    if not EXPECTED_FEATURES:
        raise HTTPException(500, "Model not loaded")

    # Get median values from baseline
    row = {}
    for col in EXPECTED_FEATURES:
        # استخدم MEDIAN_VALUES للـ imputation — مش mean (أدق للـ outliers)
        v = MEDIAN_VALUES.get(col, BASELINE_STATS.get(col, {}).get("mean", 0.0))
        row[col] = float(v)
    # Override with provided values
    tx_dict = tx.dict(exclude={"card_id","text_description"})
    for col in EXPECTED_FEATURES:
        val = tx_dict.get(col.lower())
        if val is not None:
            row[col] = float(val)

    # Engineered features
    amount = float(tx.amount)
    t      = float(tx.time or 0)
    row["amount"]        = amount
    row["log_amount"]    = float(np.log1p(amount))
    row["hour"]          = float((t // 3600) % 24)
    row["is_night"]      = 1.0 if row["hour"] <= 6 else 0.0
    row["amount_bucket"] = 0.0 if amount < 10 else (1.0 if amount < 100 else 2.0)
    # ── FCM membership features ────────────────────────────────────
    fcm_cols = ['fcm_membership_0','fcm_membership_1','fcm_membership_2']
    if all(c in EXPECTED_FEATURES for c in fcm_cols):
        if FCM_CENTROIDS is not None:
            try:
                import skfuzzy as fuzz
                base_cols = [f for f in EXPECTED_FEATURES if f not in fcm_cols]
                _df_base  = pd.DataFrame([row])[base_cols]
                X_scaled  = FCM_SCALER.transform(_df_base.values)
                X_pca     = FCM_PCA.transform(X_scaled)
                u, _, _, _, _, _ = fuzz.cluster.cmeans_predict(
                    X_pca.T, FCM_CENTROIDS, m=2, error=0.005, maxiter=100
                )
                row['fcm_membership_0'] = float(u.T[0, 0])
                row['fcm_membership_1'] = float(u.T[0, 1])
                row['fcm_membership_2'] = float(u.T[0, 2])
            except Exception:
                row['fcm_membership_0'] = 0.333
                row['fcm_membership_1'] = 0.333
                row['fcm_membership_2'] = 0.334
        else:
            row['fcm_membership_0'] = 0.333
            row['fcm_membership_1'] = 0.333
            row['fcm_membership_2'] = 0.334

    return pd.DataFrame([row])[EXPECTED_FEATURES]


VELOCITY_LOCK = threading.Lock()   # ← أضف ده في Constants (السطر 843)

def check_velocity(card_id: str) -> dict:
    """Thread-safe velocity check with sliding window."""
    now = time.time()
    with VELOCITY_LOCK:
        if card_id not in VELOCITY_TRACKER:
            VELOCITY_TRACKER[card_id] = []
        # Sliding window — امسح القديم
        VELOCITY_TRACKER[card_id] = [
            t for t in VELOCITY_TRACKER[card_id]
            if now - t < VELOCITY_WINDOW
        ]
        VELOCITY_TRACKER[card_id].append(now)
        count = len(VELOCITY_TRACKER[card_id])
    return {
        "is_suspicious": count > VELOCITY_MAX_TXN,
        "count"        : count,
        "window_sec"   : VELOCITY_WINDOW
    }


# ── استبدل compute_total_risk كاملة ──

def compute_total_risk(prob: float,
                       forecast_risk: float  = 0.08,
                       shap_score:    float  = None,
                       llm_score:     float  = 0.0,
                       has_llm_risk:  bool   = False,
                       fcm_S:         float  = 0.5,
                       fcm_mu_pred:   float  = 0.5,
                       arima_mult:    float  = 0.5,
                       shap_cosine:   float  = 0.5) -> float:
    """
    Intelligent Score — 5 independent signals (none interchangeable):

      S1 : fcm_S        — Class Severity (cluster fraud rate)
      S2 : prob         — XGBoost classifier confidence
      S3 : fcm_mu_pred  — Geometric membership µ(predicted) from FCM centroids
      S4 : arima_mult   — ARIMA cluster trend multiplier
      S5 : shap_cosine  — SHAP prediction reliability (cosine similarity)
    """
    # ── LLM semantic override (has strong contextual flags) ──────
    if has_llm_risk and llm_score > 0:
        return float(np.clip(
            0.20 * prob                   +
            0.10 * (shap_score or 0.0)    +
            0.20 * forecast_risk          +
            0.50 * llm_score,
            0, 1
        ))

    # ── Kafka fast path (SHAP not computed yet) ───────────────────
    if shap_score is None:
        return float(np.clip(0.70 * prob + 0.30 * forecast_risk, 0, 1))

    # ── Full 5-Signal Intelligent Score ──────────────────────────
    if shap_score > 0.0:
        # All 5 signals active
        IS = (
            0.45 * prob          +   # S2: XGBoost confidence
            0.15 * fcm_S         +   # S1: Cluster severity
            0.10 * fcm_mu_pred   +   # S3: Geometric membership µ(predicted)
            0.20 * arima_mult    +   # S4: ARIMA cluster trend
            0.10 * shap_cosine       # S5: SHAP cosine reliability
        )
    else:
        # SHAP=0 (Windows fallback): redistribute SHAP weight
        IS = (
            0.45 * prob          +   # S2: upweighted
            0.15 * fcm_S         +   # S1
            0.20 * fcm_mu_pred   +   # S3
            0.20 * arima_mult        # S4
        )

    return float(np.clip(IS, 0, 1))

def get_confidence_band(risk: float) -> str:
    if risk >= CONFIDENCE_BANDS["critical"]: return "critical"   # 0.80
    if risk >= CONFIDENCE_BANDS["high"]:     return "high"       # 0.60
    if risk >= CONFIDENCE_BANDS["medium"]:   return "medium"     # 0.40
    return "low"


def make_agentic_prediction(tx, llm_risk_flags: dict = None,
                             enable_mfa: bool = True,
                             text_llm_score: float = None) -> dict:
    """
    Full Agentic prediction using the ReAct orchestrator.
    Falls back to make_prediction() if orchestrator not bound.
    """
    if ACTIVE_MODEL is None:
        raise HTTPException(503, "Model not loaded")
 
    # Build context for orchestrator
    df = build_features(tx)
    hour = int((float(tx.time or 0) // 3600) % 24)
    flags = llm_risk_flags or {}
    flag_count = sum(bool(v) for v in flags.values())
 
    # ★ LLM semantic score — use text_llm_score override if provided (from /text-predict)
    # text_llm_score is scaled 0-1 based on 5 signals vs old 3-signal /3.0
    if text_llm_score is not None:
        llm_score = float(text_llm_score)
    elif flag_count > 0:
        llm_score = min(flag_count / 4.0, 1.0)   # ★ /4 not /3 (5 flags now)
    else:
        llm_score = 0.0

    context = {
        "features_df"      : df,
        "amount"           : float(tx.amount),
        "hour"             : hour,
        "transaction_time" : float(tx.time or 0),
        "card_id"          : tx.card_id or "",
        "text_description" : tx.text_description or "",
        "llm_flags"        : flags,
        "llm_score"        : llm_score,
        "has_llm_risk"     : flag_count > 0,
        "location"         : "",
        "force_shap"       : flag_count > 0 or True,  # always try SHAP
        "flag_count"       : flag_count,              # ★ passed to DynamicWeightAgent
    }
 
    # Run full ReAct loop
    # بعد
    if FRAUD_ORCHESTRATOR is None:
        raise HTTPException(503, "Orchestrator not ready")
    result = FRAUD_ORCHESTRATOR.analyze(context)
 
    # Merge with standard result format
    prob      = result.get("probability", 0.0)
    shap      = result.get("shap_score", 0.0)
    forecast  = result.get("forecast_risk", 0.0)
    total_risk= result.get("total_risk", 0.0)
    decision  = result.get("decision", "ALLOW ✅")
    band      = result.get("confidence_band", "low")
 
    expl = result.get("weight_justification", "")
    if not expl and result.get("top_drivers"):
        readable = [FEATURE_MAP.get(d["feature"], "unusual pattern")
                    for d in result["top_drivers"][:3]]
        expl = "Fraud driven by: " + ", ".join(readable)
 
    # MFA check
    mfa_info = {}
    if enable_mfa and tx.card_id and "BLOCK" in decision and band != "critical":
        if check_mfa_required(tx.card_id, {**result, "decision": decision,
                                            "total_risk": total_risk,
                                            "confidence_band": band}):
            decision = "MFA_REQUIRED 🔐"
            mfa_info = trigger_mfa(tx.card_id, result)
    
    if tx.card_id:
        update_user_profile(tx.card_id, {
            **result,
            "decision"  : decision,
            "total_risk": total_risk,
            "probability": prob,
        })


    return {
        "timestamp"        : datetime.now().isoformat(),
        "model_version"    : f"model_{MODEL_VERSION}",
        "card_id"          : tx.card_id,
        "probability"      : prob,
        "shap_score"       : shap,
        "uncertainty"      : result.get("uncertainty", 0.0),
        "forecast_risk"    : forecast,
        "total_risk"       : total_risk,
        "decision"         : decision,
        "explanation"      : expl,
        "top_drivers"      : result.get("top_drivers", []),
        "path"             : result.get("routing_path", "AGENT"),
        "confidence"       : result.get("confidence", 0.0),
        "confidence_band"  : band,
        "llm_override"     : flag_count >= 2,
        "mfa_required"     : bool(mfa_info),
        "mfa"              : mfa_info or None,
        "layers_used"      : result.get("detection_layers", []) +
                             result.get("forecast_layers", []),
        "risk_components"  : {
            "model"    : round(prob, 4),
            "shap"     : round(shap, 4),
            "forecast" : round(forecast, 4),
            "llm_score": round(llm_score, 4),
        },
        "adaptive_thresholds": {
            "block"  : BLOCK_THRESHOLD_ANOMALY if _detect_anomaly() else BLOCK_THRESHOLD_NORMAL,
            "review" : REVIEW_THRESHOLD_ANOMALY if _detect_anomaly() else REVIEW_THRESHOLD_NORMAL,
            "mode"   : "anomaly" if _detect_anomaly() else "normal",
        },
        # ── NEW: Agentic metadata ─────────────────────────────────
        "agentic": {
            "reasoning_chain"          : result.get("reasoning_chain", []),
            "react_loop"               : result.get("react_loop", ""),
            "agent_latency_ms"         : result.get("agent_latency_ms", 0),
            "deterioration_score"      : result.get("deterioration_score", 0.0),
            "preemptive_action"        : result.get("preemptive_action", "none"),
            "action_intensity"         : result.get("action_intensity", "none"),
            "action_timing"            : result.get("action_timing", ""),
            "action_justification"     : result.get("action_justification", ""),
            "dynamic_weight"           : result.get("dynamic_weight", 1.0),
            "weight_justification"     : result.get("weight_justification", ""),
            "reflection_quality"       : result.get("reflection_quality", ""),
            "reflection_notes"         : result.get("reflection_notes", []),
            "six_agentic_properties"   : result.get("six_agentic_properties", {}),
            "both_drift_signals_firing": result.get("learning_status", {})
                                          .get("both_signals_firing", False),
        },
    }



def make_prediction(tx: Transaction, llm_risk_flags: dict = None,
                    enable_mfa: bool = True) -> dict:
    """4-Layer Decision Engine with SHAP + Real Forecast."""
    if ACTIVE_MODEL is None:
        raise HTTPException(503, "Model not loaded")

    flags      = llm_risk_flags or {}
    flag_count = sum([bool(flags.get("high_amount")),
                      bool(flags.get("unusual_time")),
                      bool(flags.get("new_location"))])
    has_llm    = flag_count > 0

    block_thresh, review_thresh = get_adaptive_thresholds()

    result = {
        "timestamp"    : datetime.now().isoformat(),
        "model_version": f"model_{MODEL_VERSION}",
        "card_id"      : tx.card_id,
        "llm_override" : False,
        "mfa_required" : False,
        "layers_used"  : [],
    }

    df = build_features(tx)

    # ════ LAYER 1: HARD RULES ════
    if tx.card_id:
        vel = check_velocity(tx.card_id)
        if vel["is_suspicious"]:
            prob     = float(ACTIVE_MODEL.predict_proba(df.values)[0, 1])
            forecast = get_forecast_risk(float(tx.time or 0))
            result.update({
                "probability": prob, "shap_score": 0.0, "uncertainty": 0.5,
                "forecast_risk": forecast, "total_risk": 0.95,
                "decision": "BLOCK 🚫",
                "explanation": f"Velocity alert: {vel['count']} transactions in {VELOCITY_WINDOW//60} min",
                "top_drivers": [], "path": "HARD_VELOCITY_BLOCK",
                "confidence": 0.95, "llm_override": True,
                "layers_used": ["L1_Velocity"],
                "risk_components": {"model": round(prob,4), "shap": 0.0,
                                    "forecast": round(forecast,4), "llm_score": 0.0},
                "confidence_band": "critical",
                "adaptive_thresholds": {"block": block_thresh, "review": review_thresh},
            })
            if tx.card_id: update_user_profile(tx.card_id, result)
            return result

    # LLM Hard Block
    # LLM Hard Block
    if has_llm and flag_count >= LLM_HARD_BLOCK_FLAGS:
        prob     = float(ACTIVE_MODEL.predict_proba(df.values)[0, 1])
        forecast = get_forecast_risk(float(tx.time or 0))
        llm_s    = flag_count / 3.0
        risk     = float(np.clip(0.2*prob + 0.2*forecast + 0.6*llm_s, 0, 1))

        # ✅ أضف SHAP حتى في Hard Block
        shap_res  = get_shap_score(df, prob, force_run=True)
        shap_norm = shap_res["shap_score_norm"]
        # ── FCM Signals ───────────────────────────────────────────
        _fcm      = get_fcm_signal(df)
        _fcm_S    = _fcm["S"]
        _fcm_mu   = _fcm["mu_pred"]
        _arima_m  = _fcm["arima_mult"]
        _fcm_clst = _fcm["cluster"]

        # ── SHAP Cosine ────────────────────────────────────────────
        _shap_cos = 0.5
        if shap_norm > 0.0 and EXPLAINER is not None:
            try:
                _sv = EXPLAINER.shap_values(df[EXPECTED_FEATURES])
                if isinstance(_sv, list): _sv = _sv[1]
                if _sv.ndim == 3:         _sv = _sv[:,:,1]
                _shap_cos = get_shap_cosine_similarity(_sv[0], _fcm_clst)
            except Exception:
                pass
        
        top_drvs  = shap_res["top_drivers"]


        reasons  = [f for f in ["high_amount","unusual_time","new_location"] if flags.get(f)]
        readable_reasons = {"high_amount":"high transaction amount",
                            "unusual_time":"unusual timing",
                            "new_location":"new location"}
        reason_str = ", ".join(readable_reasons[f] for f in reasons)

        result.update({
            "probability"  : prob,
            "shap_score"   : shap_norm,          # ← مش 0.0 تاني
            "uncertainty"  : float(1-abs(2*prob-1)),
            "forecast_risk": forecast,
            "total_risk"   : risk,
            "decision"     : "BLOCK 🚫",
            "explanation"  : f"Blocked: {reason_str}",
            "top_drivers"  : top_drvs,           # ← SHAP drivers حقيقية
            "path"         : "HARD_LLM_BLOCK",
            "confidence"   : 0.95,
            "llm_override" : True,
            "layers_used"  : ["L1_HardRules","L3_LLM","L3_SHAP"],  # ← أضف SHAP
            "risk_components": {"model":round(prob,4),"shap":round(shap_norm,4),
                                "forecast":round(forecast,4),"llm_score":round(llm_s,4)},
            "confidence_band": get_confidence_band(risk),
            "adaptive_thresholds": {"block":block_thresh,"review":review_thresh},
        })
        if tx.card_id: update_user_profile(tx.card_id, result)
        return result
    # Amount + Night
    hour = float((float(tx.time or 0) // 3600) % 24)
    if tx.amount >= 5000 and (hour <= 5 or hour >= 22):
        prob     = float(ACTIVE_MODEL.predict_proba(df.values)[0, 1])
        forecast = get_forecast_risk(float(tx.time or 0))
        result.update({
            "probability": prob, "shap_score": 0.0, "uncertainty": 0.5,
            "forecast_risk": forecast, "total_risk": 0.75,
            "decision": "REVIEW ⚠️",
            "explanation": f"High amount ({tx.amount:.0f}) at unusual hour ({int(hour)}:00)",
            "top_drivers": [], "path": "HARD_AMOUNT_NIGHT", "confidence": 0.80,
            "llm_override": True, "layers_used": ["L1_HardRules"],
            "risk_components": {"model":round(prob,4),"shap":0.0,
                                "forecast":round(forecast,4),"llm_score":0.0},
            "confidence_band": "high",
            "adaptive_thresholds": {"block":block_thresh,"review":review_thresh},
        })
        if tx.card_id: update_user_profile(tx.card_id, result)
        return result

    # ════ LAYER 2: XGBoost ════
    result["layers_used"].append("L2_XGBoost")
    prob = float(ACTIVE_MODEL.predict_proba(df.values)[0, 1])

    if prob < 0.2 and not has_llm:
        result.update({
            "probability": prob, "shap_score": 0.0,
            "uncertainty": float(1-abs(2*prob-1)),
            "forecast_risk": 0.0, "total_risk": prob,
            "decision": "ALLOW ✅", "explanation": "Low fraud probability — approved",
            "top_drivers": [], "path": "FAST",
            "confidence": round(1-(1-abs(2*prob-1)), 4),
            "layers_used": ["L2_XGBoost"],
            "risk_components": {"model":round(prob,4),"shap":0.0,"forecast":0.0,"llm_score":0.0},
            "confidence_band": get_confidence_band(prob),
            "adaptive_thresholds": {"block":block_thresh,"review":review_thresh},
        })
        if tx.card_id: update_user_profile(tx.card_id, result)
        return result

    # ════ LAYER 3: SHAP ════
    if has_llm:
        result["layers_used"].append("L3_LLM")
    shap_res  = get_shap_score(df, prob, force_run=has_llm)
    shap_norm = shap_res["shap_score_norm"]
    top_drvs  = shap_res["top_drivers"]
    uncert    = float(1 - abs(2 * prob - 1))

    # ════ LAYER 4: Forecast ════
    result["layers_used"].append("L4_Forecast")
    forecast = get_forecast_risk(float(tx.time or 0))

    # Dynamic weighting
    if has_llm and flag_count >= 1:
        llm_s      = flag_count / 3.0
        total_risk = compute_total_risk(prob, forecast, shap_norm, llm_s, True,
             fcm_S=_fcm_S, fcm_mu_pred=_fcm_mu,
             arima_mult=_arima_m, shap_cosine=_shap_cos)
        path       = "LLM_DYNAMIC"
        reasons_r  = {"high_amount":"high amount","unusual_time":"unusual timing",
                      "new_location":"new location"}
        expl = "Fraud driven by: " + ", ".join(
            reasons_r[f] for f in flags if flags.get(f))
    else:
        llm_s      = 0.0
        total_risk = compute_total_risk(
            prob, forecast, shap_norm if prob > SHAP_THRESHOLD else 0.0,
            fcm_S=_fcm_S, fcm_mu_pred=_fcm_mu,
            arima_mult=_arima_m, shap_cosine=_shap_cos)
        path       = "FULL"
        readable   = [FEATURE_MAP.get(d["feature"],"unusual pattern") for d in top_drvs[:3]]
        expl       = f"Fraud driven by: {', '.join(readable)}" if readable \
                     else f"Risk score: {prob:.2f}"

    total_risk = float(np.clip(total_risk, 0, 1))

    if total_risk > block_thresh and uncert < UNCERTAINTY_THRESHOLD:
        decision = "BLOCK 🚫"
    elif total_risk > review_thresh and uncert >= UNCERTAINTY_THRESHOLD:
        decision = "REVIEW ⚠️"
    elif total_risk > review_thresh:
        decision = "BLOCK 🚫"
    else:
        decision = "ALLOW ✅"

    band = get_confidence_band(total_risk)

    # MFA check — override BLOCK to MFA for medium-risk cases
    mfa_info = {}
    if enable_mfa and tx.card_id and "BLOCK" in decision and band != "critical":
        if check_mfa_required(tx.card_id, {**result, "decision": decision,
                                            "total_risk": total_risk,
                                            "confidence_band": band}):
            decision = "MFA_REQUIRED 🔐"
            mfa_info = trigger_mfa(tx.card_id, result)

    result.update({
        "probability"  : prob,
        "shap_score"   : shap_norm,
        "uncertainty"  : uncert,
        "forecast_risk": forecast,
        "total_risk"   : total_risk,
        "decision"     : decision,
        "explanation"  : expl,
        "top_drivers"  : top_drvs,
        "path"         : path,
        "confidence"   : round(1-uncert, 4),
        "risk_components": {"model":round(prob,4),"shap":round(shap_norm,4),
                            "forecast":round(forecast,4),"llm_score":round(llm_s,4)},
        "confidence_band": band,
        "mfa_required" : bool(mfa_info),
        "mfa"          : mfa_info or None,
        "adaptive_thresholds": {"block":block_thresh,"review":review_thresh,
                                "mode":"anomaly" if block_thresh < BLOCK_THRESHOLD_NORMAL else "normal"},
    })
    if tx.card_id:
        update_user_profile(tx.card_id, result)
    return result

# ════════════════════════════════════════════════
# ENDPOINTS
# ════════════════════════════════════════════════

@app.get("/")
async def root():
    return {"status": "FraudGuard AI Online", "version": "1.0.0", "model_loaded": ACTIVE_MODEL is not None}

@app.get("/health")
async def health():
    return {"status": "ok", "model": ACTIVE_MODEL is not None, "timestamp": datetime.now().isoformat()}


# ── استبدل async def predict كاملة ──

@app.post("/predict")
async def predict(tx: Transaction):
    t0 = time.time()
 
    flags: dict = {}
    if tx.text_description:
        desc = tx.text_description.lower()
        flags = {
            "high_amount"      : tx.amount >= 1000,
            "unusual_time"     : any(w in desc for w in [
                "midnight","night","2am","3am","late","after hours","early morning"
            ]),
            "new_location"     : any(w in desc for w in [
                "new country","abroad","foreign","overseas",
                "different location","different locations","another country",
                "international","unknown location",
            ]),
            # ★ NEW flags for velocity + multi-transaction patterns
            "velocity_attack"  : any(w in desc for w in [
                "minutes","last 5","last five","multiple transactions","rapid",
                "quick succession","several transactions","many transactions",
                "3 transactions","4 transactions","5 transactions",
            ]),
            "multi_transaction": any(w in desc for w in [
                "3 transactions","each","multiple","several","in a row","consecutively",
            ]),
        }
 
    # ★ Compute flag_count + text_llm_score for /predict (same as /text-predict)
    _p_flag_count   = sum(bool(v) for v in flags.values())
    _p_text_llm     = min(_p_flag_count / 4.0, 1.0) if _p_flag_count > 0 else 0.0

    # Use Agentic prediction (ReAct loop)
    # Use Agentic prediction (ReAct loop) — run in executor to avoid blocking event loop
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None,
        lambda: make_agentic_prediction(tx, flags, text_llm_score=_p_text_llm)
    )
    result["latency_ms"] = round((time.time() - t0) * 1000, 2)
 
    # Stats + logging (same as before)
    _increment_stats("total")
    if "BLOCK"  in result["decision"]:  _increment_stats("blocks")
    elif "REVIEW" in result["decision"]: _increment_stats("reviews")
    else:                                _increment_stats("allows")
    if result.get("llm_override"):       _increment_stats("llm_overrides")
 
    threading.Thread(target=log_decision_and_update_sarima, args=(result,), daemon=True).start()
    if should_send_alert(result):
        threading.Thread(target=send_fraud_alert, args=(result,), daemon=True).start()
 
    return result
 
# ── استبدل async def batch_predict كاملة ──

def add_fcm_features_batch(df: pd.DataFrame) -> pd.DataFrame:
    """
    يضيف الـ 3 FCM membership columns لأي DataFrame.
    بيستخدم saved centroids — بدون re-clustering.
    """
    fcm_cols = ['fcm_membership_0', 'fcm_membership_1', 'fcm_membership_2']
    if not all(c in EXPECTED_FEATURES for c in fcm_cols):
        return df  # model مش محتاج FCM features

    if FCM_CENTROIDS is None or FCM_PCA is None or FCM_SCALER is None:
        df['fcm_membership_0'] = 0.333
        df['fcm_membership_1'] = 0.333
        df['fcm_membership_2'] = 0.334
        return df

    try:
        import skfuzzy as fuzz
        base_cols = [f for f in EXPECTED_FEATURES if f not in fcm_cols]
        X_scaled  = FCM_SCALER.transform(df[base_cols].values)
        X_pca     = FCM_PCA.transform(X_scaled)

        u, _, _, _, _, _ = fuzz.cluster.cmeans_predict(
            X_pca.T, FCM_CENTROIDS, m=2, error=0.005, maxiter=100
        )
        membership = u.T  # (n, 3)

        df = df.copy()
        df['fcm_membership_0'] = membership[:, 0]
        df['fcm_membership_1'] = membership[:, 1]
        df['fcm_membership_2'] = membership[:, 2]
        return df
    except Exception as e:
        logger.warning(f"Batch FCM error: {e}")
        df['fcm_membership_0'] = 0.333
        df['fcm_membership_1'] = 0.333
        df['fcm_membership_2'] = 0.334
        return df

@app.post("/batch")
async def batch_predict(file: UploadFile = File(...)):
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Only .csv files accepted")

    content = await file.read()
    df_raw  = pd.read_csv(io.BytesIO(content))
    df_raw.columns = [c.lower().strip() for c in df_raw.columns]

    df_clean, report = validate_and_clean(df_raw)
    if df_clean is None:
        raise HTTPException(422, detail={"error": "Validation failed", "report": report})

    n = len(df_clean)

    # ── Drift detection (keep — needed even with agentic path) ───────────────
    drift = check_drift(df_clean)
    if drift["drift_detected"]:
        threading.Thread(target=retrain_job,
                         args=(df_clean, drift), daemon=True).start()

    # ── Agentic Predict per row ───────────────────────────────────────────────
    # make_agentic_prediction handles: XGBoost + SHAP + Forecast +
    # Velocity + RAG + Memory + WorldModel + ExplicitRAG.add()
    v_cols  = [c for c in df_clean.columns if c.startswith("v") and c[1:].isdigit()]
    results = []
    errors  = 0

    def _run_batch_agentic():
        """Run full agentic prediction for every row — called in executor."""
        _results = []
        _errors  = 0

        for i in range(n):
            try:
                row = df_clean.iloc[i]

                # ── Reconstruct amount from log_amount (validate_and_clean drops raw amount) ──
                # log_amount = log1p(amount)  →  amount = expm1(log_amount)
                amount = float(np.expm1(row["log_amount"])) \
                         if "log_amount" in df_clean.columns else 0.0

                # ── Reconstruct time in seconds from hour ──
                # hour = (time // 3600) % 24  →  approximate time_s = hour * 3600
                time_s = float(row["hour"]) * 3600 \
                         if "hour" in df_clean.columns else 0.0

                # ── Build Transaction ─────────────────────────────────────────
                tx_kwargs: dict = {
                    "amount" : amount,
                    "time"   : time_s,
                    "card_id": f"row_{i}",
                }
                for vc in v_cols:
                    if vc in df_clean.columns:
                        tx_kwargs[vc] = float(row[vc])

                tx = Transaction(**tx_kwargs)

                # ── Full Agent Brain ──────────────────────────────────────────
                # text_llm_score=0.0  →  no text → Gemini skipped automatically
                result = make_agentic_prediction(tx, {}, text_llm_score=0.0)

                row_result = {
                    "row_id"         : i,
                    "card_id"        : f"row_{i}",
                    "decision"       : result.get("decision",        "ALLOW ✅"),
                    "probability"    : round(result.get("probability",     0.0), 4),
                    "shap_score"     : round(result.get("shap_score",      0.0), 4),
                    "total_risk"     : round(result.get("total_risk",      0.0), 4),
                    "forecast_risk"  : round(result.get("forecast_risk",   0.0), 4),
                    "confidence_band": result.get("confidence_band",  "low"),
                    "path"           : result.get("path",             "BATCH"),
                    "explanation"    : result.get("explanation",      ""),
                    "top_drivers"    : result.get("top_drivers",      []),
                    "risk_components": result.get("risk_components",  {}),
                    "layers_used"    : result.get("layers_used",      []),
                    "timestamp"      : result.get("timestamp", datetime.now().isoformat()),
                    "agentic"        : result.get("agentic"),
                }
                _results.append(row_result)

                with BATCH_STORE_LOCK:
                    BATCH_RESULTS_STORE[str(i)] = row_result

            except Exception as e:
                _errors += 1
                logger.warning(f"Batch row {i} error: {e}")
                _results.append({
                    "row_id"         : i,
                    "card_id"        : f"row_{i}",
                    "decision"       : "ERROR",
                    "error"          : str(e),
                    "probability"    : 0, "shap_score": 0,
                    "total_risk"     : 0, "forecast_risk": 0,
                    "confidence_band": "low",
                    "top_drivers"    : [],
                })

        return _results, _errors

    # ── Run in executor — prevent blocking event loop ─────────────────────────
    loop            = asyncio.get_running_loop()
    results, errors = await loop.run_in_executor(None, _run_batch_agentic)

    fraud_found = sum(1 for r in results if "BLOCK" in r.get("decision", ""))

    # ── Update live SARIMA from batch results (non-blocking) ──────────────────
    def _batch_sarima_update():
        for r in results:
            _update_live_sarima(
                decision         = r.get("decision", ""),
                transaction_time = float(r.get("row_id", 0)) * 1.5,
            )
    threading.Thread(target=_batch_sarima_update, daemon=True).start()

    # ── Store batch meta for chatbot ──────────────────────────────────────────
    with BATCH_STORE_LOCK:
        LAST_BATCH_META.update({
            "total_rows" : len(results),
            "fraud_found": fraud_found,
            "fraud_rate" : round(fraud_found / max(len(results), 1) * 100, 2),
            "timestamp"  : datetime.now().isoformat(),
        })

    return {
        "total_rows" : len(results),
        "fraud_found": fraud_found,
        "fraud_rate" : round(fraud_found / max(len(results), 1) * 100, 2),
        "errors"     : errors,
        "drift"      : drift,
        "validation" : report,
        "results"    : results,
    }
# ── أضف قبل /chat endpoint مباشرة ──

# ════ CHATBOT SYSTEM ════
CHAT_HISTORY: List[dict] = []   # [{"role":"user","content":"..."}]
CHAT_LOCK    = threading.Lock()
CHAT_MAX_HISTORY = 8

EGY_WORDS = {"إيه","ليه","ازاي","دي","ده","اتحظرت","بيحصل","حصل","مش","عايز","بتاعتي","كمان","بقي","هو","ايه"}
MSA_WORDS = {"لماذا","كيف","ما هو","هل","ماذا","من فضلك","ما هي","ما سبب"}


def _detect_language(text: str) -> str:
    """Detect language: egy / ar / en."""
    if any(w in text for w in EGY_WORDS):
        return "egy"
    if any(w in text for w in MSA_WORDS):
        return "ar"
    return "en"


def build_system_prompt(ctx: dict) -> str:
    # ── Extract context ───────────────────────────────────────────────────────
    decision    = ctx.get("decision",        "N/A")
    risk        = float(ctx.get("total_risk",  0))
    explanation = ctx.get("explanation",     "")
    row_id      = ctx.get("row_id",          "N/A")
    fraud_today = int(ctx.get("fraud_today", 0))
    prob        = float(ctx.get("probability",   0))
    shap        = float(ctx.get("shap_score",    0))
    forecast    = float(ctx.get("forecast_risk", 0))
    band        = ctx.get("confidence_band", "unknown")
    path        = ctx.get("path",            "N/A")
    layers      = ctx.get("layers_used",     [])
    drivers     = ctx.get("top_drivers",     [])
    components  = ctx.get("risk_components", {})
    amount      = ctx.get("amount",          None)
    hour        = ctx.get("hour",            None)
    location    = ctx.get("location",        None)
    timestamp   = ctx.get("timestamp",       "")
    source      = ctx.get("source",          "predict")
    not_found   = ctx.get("not_found_row",   None)
    available   = ctx.get("available_rows",  [])

    # ── Decision label (clean emoji) ─────────────────────────────────────────
    dec_clean = decision.replace("🚫","").replace("✅","").replace("⚠️","").strip()
    dec_color = (
        "BLOCKED ❌"  if "BLOCK"  in decision else
        "UNDER REVIEW ⚠️" if "REVIEW" in decision else
        "APPROVED ✅"
    )

    # ── Pre-compute display values (NEVER "a large amount") ──────────────────
    amount_str = f"${float(amount):,.2f}"  if amount is not None else None
    hour_str   = f"{int(hour):02d}:00"     if hour   is not None else None
    risk_pct   = f"{risk * 100:.1f}%"
    prob_pct   = f"{prob * 100:.2f}%"
    fore_pct   = f"{forecast * 100:.1f}%"
    n_drivers  = len(drivers) if drivers else 0

    # ── Build transaction detail block ───────────────────────────────────────
    tx_lines = []
    if amount_str : tx_lines.append(f"Amount    : {amount_str}")
    if hour_str   : tx_lines.append(f"Time      : {hour_str}")
    if location   : tx_lines.append(f"Location  : {location}")
    if timestamp:
        try:
            from datetime import datetime as _dt
            tx_lines.append(f"Timestamp : {_dt.fromisoformat(timestamp).strftime('%Y-%m-%d %H:%M:%S')}")
        except Exception:
            tx_lines.append(f"Timestamp : {timestamp}")
    tx_block = "\n".join(tx_lines) if tx_lines else "No additional transaction details available."

    # ── Build drivers block ───────────────────────────────────────────────────
    driver_block_lines = []
    if drivers:
        for d in drivers[:5]:
            feat = d.get("readable") or d.get("feature", "")
            val  = d.get("shap_value", 0)
            bar  = "▓" * min(int(abs(val) * 5), 10)
            direction = "↑ FRAUD" if val > 0 else "↓ LEGIT"
            driver_block_lines.append(f"  • {feat:<35} {val:+.4f}  {bar} {direction}")
    else:
        if explanation:
            driver_block_lines.append(f"  • {explanation}")
        else:
            driver_block_lines.append("  • Risk driven by LLM semantic flags (SHAP unavailable on Windows)")
    driver_block = "\n".join(driver_block_lines)

    # ── Build not-found block ─────────────────────────────────────────────────
    not_found_block = ""
    if not_found:
        avail = ", ".join([f"#{r}" for r in available[:15]]) if available else "none yet"
        not_found_block = f"""
┌─────────────────────────────────────────────────────┐
│  ⚠️  ROW NOT FOUND                                   │
│  Requested row: #{not_found:<6}                          │
│  Available rows: {avail}
│  → Tell user clearly row #{not_found} doesn't exist.      │
│  → List available rows so they can retry.           │
│  → Do NOT invent data for missing rows.             │
└─────────────────────────────────────────────────────┘"""

    # ── In-context examples with ACTUAL values (not placeholders) ────────────
    eg_amount   = amount_str  or "$4,500.00"
    eg_hour     = hour_str    or "02:00"
    eg_risk     = risk_pct
    eg_row      = row_id
    eg_band     = band
    eg_fore     = fore_pct

    return f"""You are FraudGuard AI — an elite fraud detection assistant engineered by a senior ML team.
You have deep expertise in XGBoost, SHAP explainability, time-series forecasting, and financial crime.
Your job: explain decisions clearly, accurately, and helpfully in the user's own language.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SOURCE : {'Batch CSV Analysis  →  row #' + str(row_id) if source == 'batch' else 'Single Text Prediction'}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{not_found_block}

TRANSACTION SNAPSHOT
────────────────────────────────────────────────────
  Decision         : {dec_color}
  Transaction ID   : #{row_id}
  Total Risk Score : {risk:.4f} / 1.00  ({band.upper()} band)
  Fraud Probability: {prob_pct}
  Detection Path   : {path}
  Layers Active    : {' → '.join(layers) if layers else 'N/A'}
  Fraud Today      : {fraud_today} cases

{tx_block}

RISK SCORE COMPONENTS
────────────────────────────────────────────────────
  XGBoost Model    : {components.get('model', 0):.4f}
  SHAP Importance  : {components.get('shap',  0):.4f}
  Forecast Risk    : {components.get('forecast', 0):.4f}  (base rate = {fore_pct})
  LLM Override     : {components.get('llm_score', 0):.4f}

TOP FRAUD DRIVERS  ({n_drivers} signals)
────────────────────────────────────────────────────
{driver_block}

SYSTEM EXPLANATION
────────────────────────────────────────────────────
{explanation or 'No explanation available.'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LANGUAGE DETECTION  (execute before generating ANY word)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RULE A — Egyptian Arabic
  Trigger words: إيه ليه ازاي دي ده اتحظرت بيحصل حصل مش عايز
                 بتاعتي كمان بقي فين امتى فلوس محظور معاملة
  → ANY trigger found → write 100% Egyptian Arabic, zero English

RULE B — Formal Arabic (only when RULE A does NOT match)
  Trigger words: لماذا كيف ما هو هل ماذا من فضلك أريد يمكن هذه السبب يرجى
  → write 100% Modern Standard Arabic (فصحى), zero English

RULE C — English (default when A and B don't match)
  → write formal professional English

RULE D — Gibberish / unclear
  → ask for clarification in the DETECTED language only.
  → example (Egyptian): "مش فاهم سؤالك كويس، ممكن تسأل تاني؟"
  → example (English):  "I didn't catch that. Could you rephrase your question?"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESPONSE FORMAT  (critical — read carefully)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ START your answer on the VERY FIRST word. No preamble.
✅ Use bullet points (•) for lists, never numbered lists.
✅ Always mention: actual amount ({eg_amount}), risk score ({eg_risk}), row ID (#{eg_row}).
✅ Always end with ONE clear action for the user.
✅ Max 5 sentences / bullet points. Be precise, not verbose.

❌ NEVER write language labels: "Arabic:", "[AR]", "Formal Arabic (فصحى):", "[EN]"
❌ NEVER write "a large amount" — use the actual value {eg_amount}
❌ NEVER mix languages in one response
❌ NEVER mention feature codes: V14, V10, V12, V1…V28 (say "unusual pattern" instead)
❌ NEVER fabricate data not present in the context above

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
GROUNDED RESPONSE TEMPLATES
(use EXACT numbers from context — not placeholders)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

When asked "why was this blocked?" in ENGLISH → answer like this:
"Transaction #{eg_row} was blocked because the AI detected {n_drivers if n_drivers else 'multiple'} high-risk signals:
• Amount {eg_amount} — above normal spending threshold
• Time {eg_hour} — {eg_fore} elevated fraud rate at this hour
• Total risk score {eg_risk} ({eg_band} band) exceeds our safety threshold
To dispute: contact your bank and quote Transaction ID #{eg_row}."

When asked in EGYPTIAN → answer like this:
"المعاملة اتحظرت عشان فيها علامات مشبوهة:
• المبلغ {eg_amount} — أكبر بكتير من المعتاد
• درجة الخطر: {eg_risk} — ده عالي جداً
اتصل بالبنك وقولهم رقم المعاملة #{eg_row} عشان تعترض."

When asked in FORMAL ARABIC → answer like this:
"تم حظر المعاملة #{eg_row} بسبب عدة مؤشرات مشبوهة:
• المبلغ {eg_amount} يتجاوز الحد المعتاد للمعاملات
• درجة المخاطرة {eg_risk} ({eg_band}) — مرتفعة جداً
للاعتراض، يرجى التواصل مع البنك وذكر رقم المعاملة #{eg_row}."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
YOUR KNOWLEDGE BASE — answer these confidently
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Why was this transaction blocked/approved/reviewed?
2. What does the risk score {eg_risk} mean in practice?
3. What are the top fraud signals and what do they mean?
4. How does the 4-layer system work? (Hard Rules → XGBoost → SHAP → Forecast)
5. How to dispute a blocked transaction?
6. Details about any batch row by number (e.g., "tell me about row 11")
7. General fraud prevention tips
8. What is MFA and why was it triggered?
"""
def chat_with_context(message: str, ctx: dict) -> str:
    """Full chatbot with history + LLM + fallback."""
    global CHAT_HISTORY

    lang = _detect_language(message)

    # Check cache first
    key = hashlib.md5(
        f"chat_{message[:100]}_{ctx.get('decision','')}_{ctx.get('total_risk',0):.3f}_{ctx.get('row_id','')}".encode()
        ).hexdigest()
    with LLM_CACHE_LOCK:
        if key in LLM_CACHE:
            return LLM_CACHE[key]

    system_prompt = build_system_prompt(ctx)

    with CHAT_LOCK:
        # ★ Keep max 6 messages (3 turns) — shorter prompt = faster LLM
        if len(CHAT_HISTORY) > 8:
            CHAT_HISTORY = CHAT_HISTORY[-8:]
        history_text = "\n".join([
            f"{'User' if i%2==0 else 'Assistant'}: {m['content'][:200]}"  # ★ truncate long turns
            for i, m in enumerate(CHAT_HISTORY)
        ])
        CHAT_HISTORY.append({"role": "user", "content": message})

    prompt = (f"{system_prompt}\n\nConversation:\n{history_text}\n"
              f"User: {message}\nAssistant:")

    reply = _call_gemini(prompt, max_tokens=250) # ★ reduced: 300→180 = faster response

    if not reply:
        # Fallback by language
        dec  = ctx.get("decision", "")
        expl = ctx.get("explanation", "")
        fallbacks = {
            "egy": f"المعاملة {dec} — {expl}",
            "ar" : f"تم {'حظر' if 'BLOCK' in dec else 'معالجة'} المعاملة. {expl}",
            "en" : f"Transaction {dec}. {expl}",
        }
        reply = fallbacks.get(lang, fallbacks["en"])

    with CHAT_LOCK:
        CHAT_HISTORY.append({"role": "assistant", "content": reply})

    _llm_cache_set(key, reply)
    return reply


def reset_chat() -> None:
    global CHAT_HISTORY
    with CHAT_LOCK:
        CHAT_HISTORY = []


# ─── /chat endpoint ─────────────────────────────────────────
@app.post("/chat")
async def chat(req: ChatRequest):
    ctx = dict(req.decision_context or {})
    ctx["fraud_today"] = prediction_stats.get("blocks", 0)

    # ── Lookup batch row by transaction_id ──────────────────────────────────
    if req.transaction_id:
        row_id_str = str(req.transaction_id).strip()
        with BATCH_STORE_LOCK:
            stored = BATCH_RESULTS_STORE.get(row_id_str)
        if stored:
            # Override ctx with the actual batch row data
            ctx.update({
                "decision"       : stored.get("decision", ctx.get("decision","N/A")),
                "total_risk"     : stored.get("total_risk", 0),
                "explanation"    : stored.get("explanation", ""),
                "probability"    : stored.get("probability", 0),
                "shap_score"     : stored.get("shap_score", 0),
                "forecast_risk"  : stored.get("forecast_risk", 0),
                "confidence_band": stored.get("confidence_band", "low"),
                "path"           : stored.get("path", "N/A"),
                "layers_used"    : stored.get("layers_used", []),
                "top_drivers"    : stored.get("top_drivers", []),
                "risk_components": stored.get("risk_components", {}),
                "timestamp"      : stored.get("timestamp", ""),
                "row_id"         : row_id_str,
                "source"         : "batch",
            })
        else:
            # Row not found — tell the chatbot
            ctx["not_found_row"] = row_id_str
            ctx["available_rows"] = list(BATCH_RESULTS_STORE.keys())[:10]

    loop  = asyncio.get_event_loop()
    reply = await loop.run_in_executor(
        None, lambda: chat_with_context(req.message, ctx)
    )
    lang  = _detect_language(req.message)
    return ChatResponse(reply=reply, language_detected=lang)

@app.post("/chat/reset")
async def chat_reset():
    """Reset chat history."""
    reset_chat()
    return {"status": "ok", "message": "Chat history cleared"}

@app.get("/metrics")
async def metrics():
    uptime = (datetime.now() - datetime.fromisoformat(prediction_stats["start_time"])).total_seconds()
    total  = max(prediction_stats["total"], 1)

    return {
        **prediction_stats,

        "uptime_seconds"  : round(uptime, 0),
        "fraud_rate_pct"  : round(prediction_stats["blocks"] / total * 100, 2),
        "fraud_rate"      : round(prediction_stats["blocks"] / total * 100, 2),
        "review_rate_pct" : round(prediction_stats["reviews"] / total * 100, 2),
        "override_rate"   : round(prediction_stats["llm_overrides"] / total * 100, 2),

        "model_loaded"    : ACTIVE_MODEL is not None,
        "shap_ready"      : EXPLAINER is not None,
        "llm_ready"       : LLM_AVAILABLE and LLM_ENABLED,

        "threshold"       : ACTIVE_THRESHOLD,
        "features_count"  : len(EXPECTED_FEATURES),
        "model_version"   : MODEL_VERSION,

        "forecast": {
            "global_mean_rate"  : GLOBAL_MEAN_RATE,
            "rolling_rate"      : ROLLING_FRAUD_RATE,
            "anomaly_detected"  : _detect_anomaly(),
        },

        "drift": {
            "last_retrain"     : LAST_RETRAIN_TIME,
            "monitor_features" : MONITOR_FEATURES[:5],
        },

        "agent": {
            "status"             : "active",
            "react_loop"         : "observe→reason→act→reflect→learn",
            "memory_episodes"    : len(FRAUD_ORCHESTRATOR.memory.episodic._mem),
            "memory_users"       : len(FRAUD_ORCHESTRATOR.memory.user._profiles),
            "six_properties"     : 6,
            "orchestrator_ready" : True,
            "system_precision"   : round(FRAUD_ORCHESTRATOR.memory.episodic.precision_estimate(), 4),
            "both_signals_firing": (FRAUD_ORCHESTRATOR.learning._gap_decline >= 5 and
                                    FRAUD_ORCHESTRATOR.learning._centroid_move >= 3),
        },
    }
# ── أضف بعد: async def metrics() ──

@app.post("/ingest")
async def ingest_data(file: UploadFile = File(...)):
    """Automated Data Ingestion — validate + drift check + optional retrain."""
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Only .csv files accepted")
    content  = await file.read()
    df_raw   = pd.read_csv(io.BytesIO(content))
    df_clean, report = validate_and_clean(df_raw)
    if df_clean is None:
        raise HTTPException(422, detail=report)
    drift  = check_drift(df_clean)
    action = "STABLE"
    if drift["drift_detected"]:
        threading.Thread(target=retrain_job,
                         args=(df_clean, drift), daemon=True).start()
        action = "RETRAIN_QUEUED"
    return {"ingested_rows": len(df_clean), "validation": report,
            "drift": drift, "action": action}


@app.get("/user/{card_id}/profile")
async def get_user_profile(card_id: str):
    """User Risk Profile — history per card."""
    with USER_PROFILE_LOCK:
        profile = dict(USER_RISK_PROFILES.get(card_id, {}))
    if not profile:
        raise HTTPException(404, f"No profile for {card_id}")
    profile["fraud_rate"] = round(
        profile.get("fraud_count",0) / max(profile.get("total_txns",1),1) * 100, 2)
    return {"card_id": card_id, **profile}


class MFAVerifyRequest(BaseModel):
    token : str
    otp   : str
    ip    : Optional[str] = ""

class MFATriggerRequest(BaseModel):
    card_id        : str
    result         : dict
    customer_email : str = ""

@app.post("/mfa/verify")
async def verify_mfa(req: MFAVerifyRequest):
    """MFA Verification — POST body (token + otp), NOT query string."""
    success, resp = mfa_service.verify(
        token = req.token,
        otp   = req.otp.strip(),
        ip    = req.ip or "",
    )
    if not success:
        code = resp.get("code", "UNKNOWN")
        status_map = {
            "TOKEN_NOT_FOUND"       : 404,
            "TOKEN_EXPIRED"         : 410,
            "ALREADY_VERIFIED"      : 200,
            "ACCOUNT_LOCKED"        : 403,
            "MAX_ATTEMPTS_EXCEEDED" : 403,
            "WRONG_OTP"             : 401,
        }
        http_status = status_map.get(code, 400)
        if http_status == 200:
            return resp
        raise HTTPException(status_code=http_status, detail=resp)
    return resp

@app.get("/mfa/status/{token}")
async def mfa_status(token: str):
    status = mfa_service.status(token)
    if status is None:
        raise HTTPException(404, "Token not found")
    return status

@app.post("/mfa/resend/{token}")
async def mfa_resend(token: str):
    result = mfa_service.resend(token)
    if result.get("status") == "error":
        status_map = {"TOKEN_NOT_FOUND": 404, "TOKEN_EXPIRED": 410,
                      "ACCOUNT_LOCKED": 403, "NO_EMAIL": 422}
        raise HTTPException(status_map.get(result.get("code",""), 400), result)
    return result

@app.delete("/mfa/cancel/{token}")
async def mfa_cancel(token: str):
    removed = mfa_service.cancel(token)
    if not removed:
        raise HTTPException(404, "Token not found or already completed")
    return {"status": "cancelled", "token": token}

@app.post("/mfa/trigger")
async def mfa_trigger_direct(req: MFATriggerRequest):
    mfa_info = trigger_mfa(req.card_id, req.result, req.customer_email)
    return mfa_info

@app.get("/mfa/stats")
async def mfa_stats():
    return {
        "service_stats": mfa_service.get_stats(),
        "recent_audit" : mfa_service.get_audit(20),
    }

@app.get("/auto-learn")
async def auto_learn():
    """Auto-Learning — analyze logs for retraining signals."""
    result = auto_learn_from_logs()
    return result



@app.get("/reports/summary")
async def reports_summary():
    total   = max(prediction_stats["total"], 1)
    blocks  = prediction_stats["blocks"]
    reviews = prediction_stats["reviews"]
    allows  = prediction_stats["allows"]

    recent_decisions = []
    log_path = "logs/fraud_decisions.log"
    if os.path.exists(log_path):
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            for line in lines[-100:]:
                try:
                    start = line.find("{")
                    if start >= 0:
                        recent_decisions.append(json.loads(line[start:]))
                except Exception:
                    continue
        except Exception:
            pass

    band_dist = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for r in recent_decisions:
        band = r.get("confidence_band", "low")
        if band in band_dist:
            band_dist[band] += 1

    return {
        "total"          : total,
        "blocks"         : blocks,
        "reviews"        : reviews,
        "allows"         : allows,
        "fraud_rate_pct" : round(blocks / total * 100, 2),
        "llm_overrides"  : prediction_stats.get("llm_overrides", 0),
        "velocity_blocks": prediction_stats.get("velocity_blocks", 0),
        "confidence_dist": band_dist,
        "recent_count"   : len(recent_decisions),
        "model_version"  : MODEL_VERSION,
        "uptime_hours"   : round(
            (datetime.now() - datetime.fromisoformat(
                prediction_stats["start_time"])).total_seconds() / 3600, 2
        ),
    }


@app.post("/report")
async def generate_tx_report(result: dict):
    """Generate LLM report for a transaction result."""
    text = generate_report(result)
    return {"report": text}


# ✅ أضف بعد: @app.post("/report")

class EmailAlertRequest(BaseModel):
    customer_email: str
    result:         dict
    report_text:    str = ""

class BatchEmailRequest(BaseModel):
    results:           List[dict]
    customer_email:    str = ""
    send_internal:     bool = True

@app.post("/email/fraud-alert")
async def email_fraud_alert(req: EmailAlertRequest):
    """Send fraud alert email to internal team."""
    ok = send_fraud_alert(req.result)
    return {"status": "sent" if ok else "failed", "to": EMAIL_RECEIVER}

@app.post("/email/customer-alert")
async def email_customer_alert(req: EmailAlertRequest):
    """Send customer notification email."""
    if not req.customer_email:
        raise HTTPException(400, "customer_email required")
    ok = send_customer_alert(req.customer_email, req.result, req.report_text)
    return {"status": "sent" if ok else "failed", "to": req.customer_email}

@app.post("/email/batch-alert")
async def email_batch_alert(req: BatchEmailRequest):
    """
    Batch email — collect flagged transactions from batch
    and send summary email. Used by frontend 'Send Email' button.
    """
    fraud_results = [r for r in req.results if "BLOCK" in r.get("decision","")]
    if not fraud_results:
        return {"status": "no_fraud", "sent": 0}

    # Build summary result for the alert
    avg_risk = sum(r.get("total_risk",0) for r in fraud_results) / len(fraud_results)
    summary_result = {
        "decision"        : "BLOCK 🚫",
        "total_risk"      : round(avg_risk, 4),
        "probability"     : round(sum(r.get("probability",0) for r in fraud_results) / len(fraud_results), 4),
        "shap_score"      : 0.0,
        "forecast_risk"   : 0.0,
        "uncertainty"     : 0.0,
        "confidence_band" : "critical" if avg_risk >= 0.8 else "high",
        "explanation"     : f"Batch analysis: {len(fraud_results)} fraud transactions detected out of {len(req.results)} total.",
        "top_drivers"     : [],
        "path"            : "BATCH",
        "model_version"   : f"model_{MODEL_VERSION}",
        "timestamp"       : datetime.now().isoformat(),
        "risk_components" : {"model": round(avg_risk,4), "shap": 0.0, "forecast": 0.0, "llm_score": 0.0},
        "row_id"          : f"BATCH_{len(fraud_results)}_FRAUDS",
    }

    sent_internal = False
    sent_customer = False

    if req.send_internal:
        sent_internal = send_fraud_alert(summary_result)

    if req.customer_email:
        report_txt = (f"We detected {len(fraud_results)} suspicious transactions "
                      f"in your recent batch upload. "
                      f"Average risk score: {avg_risk:.2f}/1.00. "
                      f"Recommended Action: REVIEW")
        sent_customer = send_customer_alert(req.customer_email, summary_result, report_txt)

    return {
        "status"         : "ok",
        "fraud_count"    : len(fraud_results),
        "total_count"    : len(req.results),
        "sent_internal"  : sent_internal,
        "sent_customer"  : sent_customer,
        "avg_risk"       : round(avg_risk, 4),
    }

# ── أضف بعد: @app.post("/report") ──

@app.post("/text-predict")
async def text_predict(req: TextPredictRequest):
    """
    Text → Structured → Decision
    Input: "User spent 9000$ at midnight in a new country"
    """
    text = req.text.lower()
    t0   = time.time()

    # ── Parse amount ──
    # ── Parse amount ──
    amounts = re.findall(r"\$?\s*(\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)", text)
    numeric = []
    for a in amounts:
        try:
            numeric.append(float(a.replace(",","")))
        except:
            pass
    amount = max(numeric) if numeric else 100.0

    # ── Parse hour ──
    hour = 0
    if any(w in text for w in ["midnight","2am","3am","4am","5am","ليل","منتصف الليل","night","late night"]):
        hour = 0
    elif any(w in text for w in ["morning","صباح","6am","7am","8am"]):
        hour = 8
    elif any(w in text for w in ["noon","ظهر","12pm"]):
        hour = 12
    elif any(w in text for w in ["evening","مساء","8pm","9pm"]):
        hour = 20

    # ── Extract flags — comprehensive signal detection ──
    flags = {
        "high_amount"      : amount >= 1000,
        "unusual_time"     : hour <= 5 or hour >= 22,
        "new_location"     : any(w in text for w in [
            "new country","abroad","foreign","overseas","بلد جديد","خارج",
            "different location","different locations","multiple locations",
            "another country","other country","outside","international",
            "paris","london","dubai","new york","berlin","tokyo","unfamiliar",
        ]),
        # ★ Velocity attack signals
        "velocity_attack"  : any(w in text for w in [
            "minutes","last 5","last five","last 10","rapid","quick succession",
            "3 transactions","4 transactions","5 transactions","multiple transactions",
            "in a row","back to back","consecutively","دقائق","متتالية",
        ]),
        # ★ Multi-transaction signals
        "multi_transaction": any(w in text for w in [
            "3 transactions","4 transactions","each","multiple","several",
            "repeated","again and again","ثلاث","أربع","متعددة",
        ]),
    }

    flag_count = sum(bool(v) for v in flags.values())

    # ★ llm_score used in risk calculation — scales with flag_count
    _text_llm_score = min(flag_count / 4.0, 1.0)

    # ── Deterministic V-features scaled by signal_strength ──
    # signal_strength 1-5: controls how extreme v14/v4/v12 are
    # Small seed-based noise keeps SHAP dynamic (not static)
    _seed    = int(amount) % 1000
    _rng     = np.random.default_rng(seed=_seed)
    _noise   = 0.12   # small noise → SHAP varies per transaction

    # Scale: 5=velocity+multi+location+amount+time, 3=amount+location+time, 1=amount only
    _sig = flag_count   # 0-5

    def _scaled_v(base: float, strength: int) -> float:
        """Scale a fraud feature value by signal strength with small noise."""
        scaled = base * (strength / 3.0)   # multiply by strength ratio
        return round(float(np.clip(scaled + _rng.normal(0, _noise), -15, 0)), 4)

    v_features: dict = {}
    if flag_count >= 2:
        # Deterministic extreme features — scale with how many signals fire
        v_features = {
            "v14": _scaled_v(-5.0, _sig),   # most important feature
            "v4" : _scaled_v(-4.5, _sig),
            "v12": _scaled_v(-4.0, _sig),
            "v10": _scaled_v(-3.0, _sig),
            "v11": _scaled_v(-2.5, _sig),
            "v3" : _scaled_v(-2.8, _sig),
            "v8" : _scaled_v(-2.0, _sig),
            "v1" : _scaled_v(-1.5, _sig),
            "v26": round(float( 0.8 + _rng.normal(0, _noise)), 4),
        }
    elif flag_count == 1:
        v_features = {
            "v14": _scaled_v(-3.0, 1),
            "v4" : _scaled_v(-2.5, 1),
            "v12": _scaled_v(-2.0, 1),
        }

    # ── Build structured ──
    structured = {
        "amount"       : amount,
        "hour"         : hour,
        "is_night"     : 1 if hour <= 6 else 0,
        "amount_bucket": 0 if amount < 10 else (1 if amount < 100 else 2),
        "risk_flags"   : flags,
        "v_features"   : v_features,
    }

    # ── Build transaction ──
    tx = Transaction(
        amount           = amount,
        time             = float(hour * 3600),
        text_description = req.text,
        **v_features,
    )

    # ★ Pass llm_score override so DynamicWeightAgent uses text signals
    loop   = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None, lambda: make_agentic_prediction(tx, flags, text_llm_score=_text_llm_score)
    )
    result["structured"] = {
        "amount"  : structured.get("amount"),
        "hour"    : structured.get("hour"),
        "location": next(
            (w for w in ["paris","london","dubai","new york","berlin","tokyo",
                         "cairo","alex","giza","mansoura","different locations"]
            if w in text), "different locations" if flags.get("new_location") else None
        ),
        "flag_count"   : flag_count,
        "text_llm_score": _text_llm_score,
    }

    import hashlib as _hs
    result["row_id"] = _hs.md5(f"{req.text[:50]}{result['timestamp']}".encode()).hexdigest()[:8]    
    result["latency_ms"]  = round((time.time() - t0) * 1000, 2)

    threading.Thread(target=log_decision_and_update_sarima, args=(result,), daemon=True).start()
    if should_send_alert(result):
        threading.Thread(target=send_fraud_alert, args=(result,), daemon=True).start()
    
    return result


@app.get("/clustering/fcm")
async def clustering_fcm(n_samples: int = 500):
    """
    FCM + DBSCAN clustering visualization data.
    Returns cluster assignments for frontend scatter plot.
    Loads pre-computed clustering from models/clustering_snapshot.pkl
    """
    snap_path = "models/clustering_snapshot.pkl"

    if not os.path.exists(snap_path):
        return {
            "status" : "unavailable",
            "message": "Clustering snapshot not found. Run export_models() in Colab first.",
            "data"   : []
        }

    loop = asyncio.get_running_loop()
    snap = await loop.run_in_executor(None, lambda: joblib.load(snap_path))
    df_plot = snap.get("df_combined", pd.DataFrame())
    # Add jitter to separate overlapping points
    if "pca_x" in df_plot.columns:
        rng = np.random.default_rng(42)
        df_plot = df_plot.copy()
        df_plot["pca_x"] += rng.normal(0, 0.03, len(df_plot))
        df_plot["pca_y"] += rng.normal(0, 0.03, len(df_plot))

    if df_plot.empty:
        return {"status": "empty", "data": []}

    # Sample for frontend performance
    if len(df_plot) > n_samples:
        df_plot = df_plot.sample(n_samples, random_state=42)

    cols = ["dbscan_label", "fcm_cluster", "uncertainty",
            "zone", "zone_encoded", "class",
            "cluster_fraud_risk", "is_noise"]

    available = [c for c in cols if c in df_plot.columns]

    # Add PCA coordinates if available
    if "pca_x" in df_plot.columns:
        available += ["pca_x", "pca_y"]
        if "pca_z" in df_plot.columns:
            available += ["pca_z"]

    return {
        "status"         : "ok",
        "n_points"       : len(df_plot),
        "n_clusters_fcm" : int(df_plot["fcm_cluster"].nunique()) if "fcm_cluster" in df_plot.columns else 0,
        "n_clusters_dbscan": int(df_plot["dbscan_label"].nunique()) if "dbscan_label" in df_plot.columns else 0,
        "data"           : df_plot[available].to_dict(orient="records"),
    }

class ClusteringRequest(BaseModel):
    results: List[dict]          # batch results من /batch response
    n_components: int = 2        # PCA dimensions للـ visualization (2 أو 3)

@app.post("/clustering/fcm")
async def clustering_fcm_batch(req: ClusteringRequest):
    """
    FCM clustering على batch results — للـ frontend batch page visualization.
    بيأخذ results من /batch response ويرجع cluster data للـ scatter plot.
    """
    if not req.results:
        raise HTTPException(400, "No results provided")

    try:
        import skfuzzy as fuzz
        from sklearn.decomposition import PCA

        rows = req.results
        n    = len(rows)

        # ── Build feature matrix ──────────────────────────────────────────
        probs     = np.array([float(r.get("probability",   0.0)) for r in rows])
        risks     = np.array([float(r.get("total_risk",    0.0)) for r in rows])
        shaps     = np.array([float(r.get("shap_score",    0.0)) for r in rows])
        fcasts    = np.array([float(r.get("forecast_risk", 0.0)) for r in rows])
        dec_enc   = np.array([
            1.0 if "BLOCK"  in str(r.get("decision", "")) else
            0.5 if "REVIEW" in str(r.get("decision", "")) else 0.0
            for r in rows
        ])
        band_map  = {"critical": 1.0, "high": 0.75, "medium": 0.5, "low": 0.0}
        bands_enc = np.array([
            band_map.get(str(r.get("confidence_band", "low")).lower(), 0.0)
            for r in rows
        ])

        X = np.column_stack([probs, risks, shaps, fcasts, dec_enc, bands_enc])

        # ── Normalize 0-1 per column ──────────────────────────────────────
        X_min  = X.min(axis=0)
        X_max  = X.max(axis=0)
        X_norm = (X - X_min) / np.where(X_max - X_min < 1e-8, 1.0, X_max - X_min)

        # ── PCA first (like notebook) ─────────────────────────────────────
        n_pca = min(req.n_components, X_norm.shape[1], n)
        pca   = PCA(n_components=n_pca, random_state=42)
        X_pca = pca.fit_transform(X_norm)          # shape (N, n_pca)

        # ── Real FCM via skfuzzy ──────────────────────────────────────────
        n_clusters = min(3, n)
        X_fcm      = X_pca.T                       # skfuzzy expects (features, samples)

        cntr, u, _, _, _, _, _ = fuzz.cluster.cmeans(
            X_fcm,
            c       = n_clusters,
            m       = 2,
            error   = 0.005,
            maxiter = 1000,
        )
        membership = u.T                            # shape (N, K)

        # ── Uncertainty gap (like notebook) ───────────────────────────────
        sorted_mem = np.sort(membership, axis=1)
        gap        = sorted_mem[:, -1] - sorted_mem[:, -2]

        # نقسم الـ gap distribution على 3 بالتساوي تقريباً
        p33 = float(np.percentile(gap, 33))
        p66 = float(np.percentile(gap, 66))

        uncertain = gap <= p33
        core      = gap >= p66
        border    = ~uncertain & ~core
        def zone_label(i: int) -> str:
            if uncertain[i]: return "uncertain"
            if border[i]:    return "border"
            return "core"

        labels = np.argmax(membership, axis=1)     # hard label = argmax

        # ── Per-cluster fuzzy fraud rates ─────────────────────────────────
        fraud_proxy = np.array([
            1.0 if "BLOCK"  in str(r.get("decision", "")) else
            0.5 if "REVIEW" in str(r.get("decision", "")) else 0.0
            for r in rows
        ])

        U_m           = membership ** 2            # m = 2
        cluster_fraud: dict = {}
        cluster_sizes: dict = {}
        for c in range(n_clusters):
            w                = U_m[:, c]
            cluster_sizes[c] = int((labels == c).sum())
            cluster_fraud[c] = round(
                float((w * fraud_proxy).sum() / (w.sum() + 1e-10)), 4
            )

        # ── Build response data ───────────────────────────────────────────
        data = []
        for i, row in enumerate(rows):
            dec = str(row.get("decision", ""))

            # Soft classification: weighted blend across all clusters
            fuzzy_risk = float(
                sum(membership[i, c] * cluster_fraud[c] for c in range(n_clusters))
            )

            # ── Jitter لفصل النقاط المتراكمة في PCA space ──
            rng    = np.random.default_rng(seed=i)
            jitter = 0.015
            px     = round(float(X_pca[i, 0]) + rng.uniform(-jitter, jitter), 6)
            py     = round((float(X_pca[i, 1]) if n_pca > 1 else 0.0) + rng.uniform(-jitter, jitter), 6)

            point: dict = {
                "row_id"            : row.get("row_id", i),
                "fcm_cluster"       : int(labels[i]),
                "probability"       : round(float(probs[i]),  4),
                "total_risk"        : round(float(risks[i]),  4),
                "shap_score"        : round(float(shaps[i]),  4),
                "forecast_risk"     : round(float(fcasts[i]), 4),
                "decision"          : dec,
                "confidence_band"   : str(row.get("confidence_band", "low")),
                "cluster_fraud_risk": round(fuzzy_risk, 4),
                "is_fraud"          : 1 if "BLOCK" in dec else 0,
                "pca_x"             : px,
                "pca_y"             : py,
                "uncertainty"       : round(float(gap[i]), 4),
                "zone"              : zone_label(i),
                "memberships"       : {
                    c: round(float(membership[i, c]), 3)
                    for c in range(n_clusters)
                },
            }
            if n_pca >= 3:
                point["pca_z"] = round(float(X_pca[i, 2]), 6)

            data.append(point)

        return {
            "status"             : "ok",
            "n_points"           : len(data),
            "n_clusters_fcm"     : n_clusters,
            "n_clusters_dbscan"  : 0,
            "cluster_fraud_rates": cluster_fraud,
            "cluster_sizes"      : cluster_sizes,
            "explained_variance" : [round(float(v), 4) for v in pca.explained_variance_ratio_],
            "zone_summary"       : {
                "core"     : int(core.sum()),
                "border"   : int(border.sum()),
                "uncertain": int(uncertain.sum()),
            },
            "data": data,
        }

    except ImportError:
        raise HTTPException(500, "skfuzzy not installed — run: pip install scikit-fuzzy")
    except Exception as e:
        logger.error(f"clustering_fcm_batch error: {e}")
        raise HTTPException(500, f"Clustering failed: {e}")
    
@app.get("/forecast")
async def forecast_endpoint(transaction_time: float = 0.0):
    """Real-time fraud forecast risk."""
    risk    = get_forecast_risk(transaction_time)
    anomaly = _detect_anomaly()
    hour    = int((transaction_time // 3600) % 24)
    return {
        "forecast_risk"    : round(risk, 4),
        "anomaly_detected" : anomaly,
        "hour"             : hour,
        "hourly_rate"      : round(HOURLY_PROFILE.get(hour, GLOBAL_MEAN_RATE), 6),
        "adaptive_mode"    : "anomaly" if anomaly else "normal",
    }


@app.get("/drift/status")
async def drift_status():
    """Current drift status + model info."""
    return {
        "model_version"    : MODEL_VERSION,
        "threshold"        : ACTIVE_THRESHOLD,
        "last_retrain"     : LAST_RETRAIN_TIME,
        "monitor_features" : MONITOR_FEATURES[:5],
        "anomaly_detected" : _detect_anomaly(),
        "retrain_cooldown" : max(0, 3600 - (time.time() - LAST_RETRAIN_TIME)),
    }


# ── 5.1: ARIMA/SARIMA Time-Series Visualization ─────────────────
@app.get("/forecast/timeseries")
async def forecast_timeseries(horizon_hours: int = 24):
    """
    ARIMA/SARIMA visualization data for frontend charts.
    Returns: historical fraud rates + SARIMA forecast + anomaly windows.
    Connect this to your frontend chart component.
    """
    viz = build_sarima_visualization(FORECAST_TS, horizon_hours)
 
    # Add current live state
    viz["live"] = {
        "current_hour"      : int((time.time() // 3600) % 24),
        "rolling_fraud_rate": round(ROLLING_FRAUD_RATE, 6),
        "global_mean_rate"  : round(GLOBAL_MEAN_RATE, 6),
        "anomaly_active"    : _detect_anomaly(),
        "adaptive_mode"     : "anomaly" if _detect_anomaly() else "normal",
    }
 
    # Add SARIMA model metadata (for dashboard)
    viz["model_info"] = {
        "type"          : "SARIMA(1,1,1)(1,1,1,24)",
        "update_source" : "forecast_snapshot.pkl",
        "connected_to"  : "decision_engine",
        "last_updated"  : datetime.fromtimestamp(
            os.path.getmtime("models/forecast_snapshot.pkl")
        ).isoformat() if os.path.exists("models/forecast_snapshot.pkl") else "N/A",
    }
    return viz
 
 
# ── 5.2: Agent Status Dashboard ─────────────────────────────────
@app.get("/agent/status")
async def agent_status():
    """
    Full Agentic AI system status.
    Frontend Zone: System Alerts + Cluster Health
    """
    from agent_layer import _EXPLICIT_RAG
    status = FRAUD_ORCHESTRATOR.get_agent_status()
    status["react_log"]    = FRAUD_ORCHESTRATOR.get_react_log(10)
    status["system_goals"] = FRAUD_ORCHESTRATOR._goals
    # ★ Include Explicit RAG stats
    status["explicit_rag"] = {
        "size"         : _EXPLICIT_RAG.size,
        "ready"        : _EXPLICIT_RAG.size >= _EXPLICIT_RAG.MIN_DOCS,
        "min_docs"     : _EXPLICIT_RAG.MIN_DOCS,
        "k_neighbors"  : _EXPLICIT_RAG.K,
        "borderline_lo": _EXPLICIT_RAG.BORDERLINE_LO,
        "borderline_hi": _EXPLICIT_RAG.BORDERLINE_HI,
    }
    # ★ Include live SARIMA state
    status["sarima_live"] = {
        "rolling_fraud_rate": round(ROLLING_FRAUD_RATE, 6),
        "global_mean_rate"  : round(GLOBAL_MEAN_RATE, 6),
        "anomaly_active"    : _detect_anomaly(),
        "forecast_ts_rows"  : len(FORECAST_TS) if FORECAST_TS is not None and not FORECAST_TS.empty else 0,
    }
    return status


# ── 5.2b: Explicit RAG Status ─────────────────────────────────────
@app.get("/agent/rag-status")
async def agent_rag_status():
    """
    Explicit RAG index status — size, readiness, 7-path routing stats.
    Frontend: Zone 4 SHAP Reliability
    """
    from agent_layer import _EXPLICIT_RAG
    return {
        "explicit_rag_size"    : _EXPLICIT_RAG.size,
        "ready"                : _EXPLICIT_RAG.size >= _EXPLICIT_RAG.MIN_DOCS,
        "min_docs_needed"      : _EXPLICIT_RAG.MIN_DOCS,
        "k_neighbors"          : _EXPLICIT_RAG.K,
        "borderline_range"     : [_EXPLICIT_RAG.BORDERLINE_LO, _EXPLICIT_RAG.BORDERLINE_HI],
        "implicit_rag"         : "shap_cosine_similarity_to_cluster_mean",
        "seven_paths"          : [
            "P1_SECURITY_VETO",
            "P2_DIRECT_BLOCK",
            "P3_SHAP_RECHECK",
            "P4A_RAG_FRAUD_VOTE",
            "P4B_RAG_TIE_SHAP_FALLBACK",
            "P4C_RAG_ZERO_SUCCESS",
            "P4D_RAG_ARIMA_DAMPEN",
            "P5_HUMAN_REVIEW",
            "P6_STANDARD",
            "P7_LOW_RISK_DIRECT",
        ],
    }

# ── 5.3: Full Agentic Predict (explicit agent endpoint) ─────────
@app.post("/agent/predict")
async def agent_predict(tx: Transaction):
    """
    Explicit Agentic prediction endpoint.
    Runs full ReAct loop and returns ALL agent metadata.
    """
    flags: dict = {}
    if tx.text_description:
        desc = tx.text_description.lower()
        flags = {
            "high_amount" : tx.amount >= 1000,
            "unusual_time": any(w in desc for w in ["midnight","night","2am","3am","late"]),
            "new_location": any(w in desc for w in ["new country","abroad","foreign","overseas"]),
        }
    loop   = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None, lambda: make_agentic_prediction(tx, flags)
    )
    threading.Thread(target=log_decision_and_update_sarima, args=(result,), daemon=True).start()
    return result
 
 
# ── 5.4: ReAct Log ───────────────────────────────────────────────
@app.get("/agent/react-log")
async def agent_react_log(n: int = 20):
    """
    Last N ReAct loop traces — shows the agent's reasoning.
    Frontend: Zone 3 Action Dispatch + Zone 6 System Alerts
    """
    return {
        "react_log"      : FRAUD_ORCHESTRATOR.get_react_log(n),
        "total_decisions": len(FRAUD_ORCHESTRATOR._react_log),
    }
 
 
# ── 5.5: Human-in-the-Loop: Ground Truth Feedback ────────────────
class GroundTruthRequest(BaseModel):
    card_id  : str
    was_fraud: bool
    notes    : Optional[str] = None
 
@app.post("/agent/feedback")
async def agent_feedback(req: GroundTruthRequest):
    """
    Human-in-the-Loop feedback.
    Agent updates episodic memory + Explicit RAG simultaneously.
    """
    from agent_layer import _EXPLICIT_RAG
    updated   = FRAUD_ORCHESTRATOR.mark_ground_truth(req.card_id, req.was_fraud)
    precision = FRAUD_ORCHESTRATOR.memory.episodic.precision_estimate()

    # ★ Also update Explicit RAG with ground truth
    user_mem = FRAUD_ORCHESTRATOR.memory.user.get_profile_summary(req.card_id)
    risk_trend = user_mem.get("risk_trend", [])
    last_prob  = float(risk_trend[-1]) if risk_trend else 0.5
    _EXPLICIT_RAG.update_outcome(last_prob, [], req.was_fraud)

    return {
        "status"              : "learned",
        "episodes_updated"    : updated,
        "updated_precision"   : round(precision, 4),
        "card_id"             : req.card_id,
        "was_fraud"           : req.was_fraud,
        "adaptation_triggered": precision < 0.85,
        "rag_size"            : _EXPLICIT_RAG.size,
        "notes"               : req.notes,
    }

 
 
# ── 5.6: Agent Goals (Goal-Driven Behavior) ──────────────────────
class GoalUpdateRequest(BaseModel):
    goals: Dict[str, float]   # e.g. {"minimize_fraud_losses": 0.9}
 

 
 
# ── 5.7: User Memory Profile (Agent Memory) ──────────────────────
@app.get("/agent/user-memory/{card_id}")
async def get_user_memory(card_id: str):
    """
    Agent's learned memory about a specific user.
    Returns behavioral baseline + anomaly signals + risk trend.
    """
    profile = FRAUD_ORCHESTRATOR.memory.user.get_profile_summary(card_id)
    if not profile or profile.get("total_txns", 0) == 0:
        raise HTTPException(404, f"No memory for {card_id}")
    return {"card_id": card_id, "agent_memory": profile}
 
 
# ── 5.8: Self-Healing: Agent Self-Evaluation Report ──────────────
@app.get("/agent/self-evaluation")
async def agent_self_evaluation():
    """
    Agent evaluates its own performance and flags degradation.
    Zone 4 SHAP Reliability + Zone 5 Outcome Tracking
    """
    react_log = FRAUD_ORCHESTRATOR.get_react_log(100)
    quality_counts = {"good": 0, "uncertain": 0, "risky": 0, "partial": 0}
    for entry in react_log:
        q = entry.get("quality", "good")
        quality_counts[q] = quality_counts.get(q, 0) + 1
 
    total = max(len(react_log), 1)
    precision = FRAUD_ORCHESTRATOR.memory.episodic.precision_estimate()
    learning  = FRAUD_ORCHESTRATOR.learning._gap_decline
 
    health = "healthy"
    if precision < 0.85 or learning >= 5:
        health = "degrading"
    if precision < 0.70 or learning >= 8:
        health = "critical"
 
    return {
        "system_health"       : health,
        "precision_estimate"  : round(precision, 4),
        "decision_quality"    : quality_counts,
        "quality_rate"        : round(quality_counts["good"] / total, 4),
        "gap_decline_signal"  : learning,
        "both_signals_firing" : FRAUD_ORCHESTRATOR.learning._gap_decline >= 5 and
                                FRAUD_ORCHESTRATOR.learning._centroid_move >= 3,
        "retraining_recommended": health in ("degrading", "critical"),
        "memory_size"         : {
            "episodic": len(FRAUD_ORCHESTRATOR.memory.episodic._mem),
            "semantic": len(FRAUD_ORCHESTRATOR.memory.semantic._patterns),
            "users"   : len(FRAUD_ORCHESTRATOR.memory.user._profiles),
        },
        "six_properties_active": {
            "observes_continuously": True,
            "reasons_before_acting": True,
            "acts_with_explanation": True,
            "adapts_to_outcomes"   : len(FRAUD_ORCHESTRATOR.memory.episodic._mem) > 0,
            "detects_own_degradation": health != "healthy",
            "retrains_autonomously": FRAUD_ORCHESTRATOR.learning._gap_decline >= 5,
        },
    }
 


# ════════════════════════════════════════════════════════════════
# ★ NEW ENDPOINTS: 8 Agentic Systems
# ════════════════════════════════════════════════════════════════

@app.get("/agent/world-model")
async def agent_world_model():
    """World model: attacker intent, fraud patterns, campaign detection."""
    from agent_layer import _TOOL_REGISTRY
    return {
        "world_model"    : FRAUD_ORCHESTRATOR.world_model.get_summary(),
        "active_campaigns": FRAUD_ORCHESTRATOR.world_model._attack_types[-5:],
        "hour_risk_profile": dict(FRAUD_ORCHESTRATOR.world_model._hour_risk),
        "top_causal_features": sorted(
            FRAUD_ORCHESTRATOR.world_model._causal_map.items(),
            key=lambda x: x[1], reverse=True
        )[:10],
    }


@app.get("/agent/goals")
async def agent_get_goals():
    """All agent goals — active + completed + strategic."""
    return FRAUD_ORCHESTRATOR.goal_engine.get_all()


@app.post("/agent/goals")
async def agent_set_goals(req: GoalUpdateRequest):
    """Update strategic goal weights."""
    FRAUD_ORCHESTRATOR.set_goal_weights(req.goals)
    FRAUD_ORCHESTRATOR.goal_engine._strategic.update(req.goals)
    return {"status": "goals_updated", "current_goals": FRAUD_ORCHESTRATOR._goals}


@app.get("/agent/tools")
async def agent_tool_registry():
    """Autonomous tool discovery registry — all tools with performance metrics."""
    return {
        "tools"          : FRAUD_ORCHESTRATOR.tool_discovery.get_registry_summary(),
        "total_tools"    : len(_TOOL_REGISTRY),
        "situation_example": FRAUD_ORCHESTRATOR.tool_discovery.evaluate_and_select(
            ["core", "detection", "ml"], budget_ms=300.0
        ),
    }


@app.get("/agent/conflicts")
async def agent_conflicts():
    """Inter-agent communication log — conflicts and resolutions."""
    return {
        "recent_conflicts": FRAUD_ORCHESTRATOR.iap.get_recent_conflicts(20),
        "total_messages"  : len(FRAUD_ORCHESTRATOR.iap._messages),
    }


@app.get("/agent/health")
async def agent_system_health():
    """Self-healing infrastructure status — all subsystems + fallbacks."""
    return {
        "subsystems" : FRAUD_ORCHESTRATOR._health.get_status(),
        "alerts"     : FRAUD_ORCHESTRATOR._health.get_alerts(10),
        "shap_ok"    : FRAUD_ORCHESTRATOR._health.is_healthy("shap"),
        "kafka_ok"   : FRAUD_ORCHESTRATOR._health.is_healthy("kafka"),
        "llm_ok"     : FRAUD_ORCHESTRATOR._health.is_healthy("llm"),
        "rag_ok"     : FRAUD_ORCHESTRATOR._health.is_healthy("rag_index"),
    }


@app.get("/agent/rag-knowledge")
async def agent_rag_knowledge():
    """Fraud knowledge base — policies + playbooks used by RAG intelligence."""
    from agent_layer import FRAUD_KNOWLEDGE_BASE, _EXPLICIT_RAG
    return {
        "knowledge_base" : FRAUD_KNOWLEDGE_BASE,
        "explicit_rag_size": _EXPLICIT_RAG.size,
        "llm_cache_size" : len(FRAUD_ORCHESTRATOR.llm_reasoner._cache),
        "rag_ready"      : _EXPLICIT_RAG.size >= _EXPLICIT_RAG.MIN_DOCS,
    }


@app.post("/agent/attacker-intent")
async def agent_attacker_intent(tx: Transaction):
    """Ask the world model: what is this attacker trying to do?"""
    hour = int((float(tx.time or 0) // 3600) % 24)
    intent = FRAUD_ORCHESTRATOR.world_model.predict_attacker_intent(
        float(tx.amount), hour
    )
    return {
        "attacker_intent": intent,
        "world_model"    : FRAUD_ORCHESTRATOR.world_model.get_summary(),
        "hour_risk"      : FRAUD_ORCHESTRATOR.world_model._hour_risk.get(hour, 0.001),
    }


# ════ WebSocket for Real-Time Stream ════
class ConnectionManager:
    def __init__(self):
        self.connections: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.connections.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.connections:
            self.connections.remove(ws)
    async def broadcast(self, data: dict):
        dead = []
        for ws in self.connections:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.connections.remove(ws)

ws_manager = ConnectionManager()


@app.websocket("/ws/stream")
async def websocket_stream(ws: WebSocket):
    """
    Real-time transaction stream.
    ★ Latency fix: make_agentic_prediction runs in thread pool
      so the asyncio event loop is never blocked.
    """
    await ws_manager.connect(ws)
    loop = asyncio.get_event_loop()
    try:
        while True:
            data = await ws.receive_json()
            try:
                flags: dict = {}
                if data.get("text_description"):
                    desc = data["text_description"].lower()
                    flags = {
                        "high_amount" : data.get("amount", 0) >= 1000,
                        "unusual_time": any(w in desc for w in ["midnight","night","late"]),
                        "new_location": any(w in desc for w in ["new country","abroad","foreign"]),
                    }

                tx = Transaction(**data)

                # ★ Non-blocking: run CPU-bound agentic prediction in thread pool
                result = await loop.run_in_executor(
                    None, lambda: make_agentic_prediction(tx, flags)
                )

                # ★ SARIMA + profile update (fire-and-forget)
                threading.Thread(
                    target=log_decision_and_update_sarima, args=(result,), daemon=True
                ).start()
                if tx.card_id:
                    threading.Thread(
                        target=update_user_profile, args=(tx.card_id, result), daemon=True
                    ).start()
                if should_send_alert(result):
                    threading.Thread(
                        target=send_fraud_alert, args=(result,), daemon=True
                    ).start()

                # ★ Include agentic metadata in stream response
                ag = result.get("agentic", {})
                await ws.send_json({
                    "type"             : "prediction",
                    "decision"         : result["decision"],
                    "risk"             : result["total_risk"],
                    "probability"      : result["probability"],
                    "shap_score"       : result["shap_score"],
                    "path"             : result.get("path", result.get("routing_path","")),
                    "band"             : result["confidence_band"],
                    "mfa"              : result.get("mfa_required", False),
                    "explanation"      : result.get("explanation", ""),
                    "ts"               : result["timestamp"],
                    # ★ Agentic extras for frontend Zone 2 + Zone 3
                    "deterioration"    : ag.get("deterioration_score", 0.0),
                    "preemptive_action": ag.get("preemptive_action", "none"),
                    "react_path"       : result.get("routing_path", ""),
                    "agent_latency_ms" : ag.get("agent_latency_ms", 0),
                })
            except Exception as e:
                await ws.send_json({"type": "error", "message": str(e)})
    except WebSocketDisconnect:
        ws_manager.disconnect(ws)


# ❌ استبدل السطور 1526-1553 كلها

# ── أضف Kafka consumer background task ──
KAFKA_CONSUMER_ACTIVE = False
_kafka_thread          = None

def _kafka_consumer_loop() -> None:
    """Background consumer — reads fraud-detect topic every 2 minutes."""
    global KAFKA_CONSUMER_ACTIVE
    try:
        from confluent_kafka import Consumer, KafkaError

        conf = {
            "bootstrap.servers"    : os.getenv("KAFKA_BROKER", "localhost:9092"),
            "group.id"             : "fraudguard-api-consumer",
            "auto.offset.reset"    : "latest",
            "enable.auto.commit"   : True,
            "session.timeout.ms"   : "30000",
            "heartbeat.interval.ms": "10000",
        }
        consumer = Consumer(conf)
        consumer.subscribe(["fraud-detect"])          # ← hyphen, matches producer
        logger.info("✅ Kafka consumer started — topic=fraud-detect")

        _LOCAL = {"cairo","alex","giza","mansoura","alexandria","luxor","aswan"}

        while KAFKA_CONSUMER_ACTIVE:
            msgs = consumer.consume(num_messages=50, timeout=30.0)
            for msg in msgs:
                if msg.error():
                    if msg.error().code() != KafkaError._PARTITION_EOF:
                        logger.error(f"Kafka error: {msg.error()}")
                    continue
                try:
                    raw = json.loads(msg.value().decode("utf-8"))
                    ktx = KafkaTransaction(**raw)
                    tx  = ktx.to_transaction()

                    # ── Parse hour from raw timestamp ──────────────────
                    try:
                        _ts  = datetime.fromisoformat(raw["timestamp"]).timestamp() \
                               if raw.get("timestamp") else time.time()
                        _hour = int(datetime.fromtimestamp(_ts).hour)
                    except Exception:
                        _hour = datetime.now().hour

                    _loc = raw.get("location", "").strip().lower()

                    flags = {
                        "high_amount" : tx.amount >= 1000,
                        "unusual_time": (_hour <= 5 or _hour >= 22),
                        "new_location": bool(_loc and _loc not in _LOCAL),
                    }

                    result = make_agentic_prediction(tx, flags)

                    KAFKA_LOG.appendleft({
                        "user_id"     : raw.get("user_id"),
                        "amount"      : raw.get("amount"),
                        "location"    : raw.get("location"),
                        "v14"         : raw.get("v14"),
                        "is_fraud"    : raw.get("is_fraud"),
                        "decision"    : result.get("decision"),
                        "risk"        : result.get("total_risk"),
                        "probability" : result.get("probability"),
                        "ts"          : datetime.now().isoformat(),
                        })
                    # ★ SARIMA-aware log
                    threading.Thread(
                        target=log_decision_and_update_sarima, args=(result,), daemon=True
                    ).start()
                    if tx.card_id:
                        threading.Thread(
                            target=update_user_profile,
                            args=(tx.card_id, result), daemon=True
                        ).start()
                    if should_send_alert(result):
                        threading.Thread(
                            target=send_fraud_alert, args=(result,), daemon=True
                        ).start()

                    logger.info(
                        f"Kafka → {result['decision']} | "
                        f"risk={result['total_risk']:.3f} | "
                        f"path={result['path']}"
                    )
                except Exception as e:
                    logger.warning(f"Kafka msg failed: {e}")

        consumer.close()
        logger.info("Kafka consumer stopped")

    except ImportError:
        logger.warning("confluent-kafka not installed — consumer disabled")
    except Exception as e:
        logger.error(f"Kafka consumer error: {e}")
        KAFKA_CONSUMER_ACTIVE = False

@app.post("/kafka/produce")
async def kafka_produce(transactions: List[KafkaTransaction]):
    """Push KafkaTransaction messages to fraud-detect topic."""
    try:
        from confluent_kafka import Producer
        p = Producer({
            "bootstrap.servers": os.getenv("KAFKA_BROKER", "localhost:9092"),
            "client.id"        : "fraudguard-api-producer",
            "acks"             : "1",
            "linger.ms"        : "5",
        })
        sent = 0
        for tx in transactions:
            p.produce(
                topic  = "fraud-detect",
                value  = json.dumps(tx.dict()).encode("utf-8"),
                key    = f"USER_{tx.user_id}".encode("utf-8"),
            )
            sent += 1
        p.flush()
        return {"status": "ok", "sent": sent, "topic": "fraud-detect"}

    except ImportError:
        # Simulation mode
        results = []
        for ktx in transactions:
            tx  = ktx.to_transaction()
            res = make_agentic_prediction(tx)
            results.append({
                "transaction_id": ktx.transaction_id,
                "decision"      : res["decision"],
                "risk"          : res["total_risk"],
                "path"          : res["path"],
            })
        return {"status": "simulated", "results": results}

    except Exception as e:
        raise HTTPException(500, f"Kafka error: {e}")


@app.post("/kafka/consumer/start")
async def kafka_consumer_start():
    """Start background Kafka consumer."""
    global KAFKA_CONSUMER_ACTIVE, _kafka_thread
    if KAFKA_CONSUMER_ACTIVE:
        return {"status": "already_running"}
    KAFKA_CONSUMER_ACTIVE = True
    _kafka_thread = threading.Thread(
        target=_kafka_consumer_loop, daemon=True
    )
    _kafka_thread.start()
    return {"status": "started", "topic": "fraud-detect"}


@app.post("/kafka/consumer/stop")
async def kafka_consumer_stop():
    global KAFKA_CONSUMER_ACTIVE
    KAFKA_CONSUMER_ACTIVE = False
    return {"status": "stopped"}


@app.get("/kafka/consumer/status")
async def kafka_consumer_status():
    return {
        "active"       : KAFKA_CONSUMER_ACTIVE,
        "thread_alive" : _kafka_thread.is_alive() if _kafka_thread else False,
        "topic"        : "fraud-detect",
        "broker"       : os.getenv("KAFKA_BROKER", "localhost:9092"),
    }

@app.get("/kafka/consumer/log")
async def kafka_consumer_log(limit: int = 50):
    """Last N Kafka consumer decisions — for frontend terminal display."""
    entries = list(KAFKA_LOG)[:limit]
    total   = len(entries)
    fraud   = sum(1 for e in entries if "BLOCK" in str(e.get("decision","")))
    correct = sum(1 for e in entries
                  if ("BLOCK"  in str(e.get("decision","")) and e.get("is_fraud") == 1) or
                     ("BLOCK"  not in str(e.get("decision","")) and e.get("is_fraud") == 0))
    return {
        "entries"  : entries,
        "total"    : total,
        "fraud"    : fraud,
        "accuracy" : round(correct / max(total, 1) * 100, 1),
    }