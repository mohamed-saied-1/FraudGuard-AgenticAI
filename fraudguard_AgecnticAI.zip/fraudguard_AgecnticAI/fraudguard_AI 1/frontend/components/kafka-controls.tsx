"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Play, Square, RefreshCw, Loader2 } from "lucide-react"
import { api } from "@/lib/api"
import type { KafkaStatus } from "@/lib/types"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

interface Props {
  compact?: boolean
}

export function KafkaControls({ compact = false }: Props) {
  const [status, setStatus] = useState<KafkaStatus | null>(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const refresh = async () => {
    try {
      const s = await api.kafkaStatus()
      setStatus(s)
      setErr(null)
    } catch (e) {
      setErr((e as Error).message)
    }
  }

  useEffect(() => {
    let mounted = true
    const tick = async () => {
      try {
        const s = await api.kafkaStatus()
        if (mounted) {
          setStatus(s)
          setErr(null)
        }
      } catch (e) {
        if (mounted) setErr((e as Error).message)
      }
    }
    tick()
    const id = setInterval(tick, 6000)
    return () => {
      mounted = false
      clearInterval(id)
    }
  }, [])

  const start = async () => {
    setLoading(true)
    try {
      const r = await api.kafkaStart()
      toast.success(`Kafka consumer ${r.status}`)
      await refresh()
    } catch (e) {
      toast.error(`Start failed: ${(e as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  const stop = async () => {
    setLoading(true)
    try {
      const r = await api.kafkaStop()
      toast.success(`Kafka consumer ${r.status}`)
      await refresh()
    } catch (e) {
      toast.error(`Stop failed: ${(e as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  const active = status?.active && status?.thread_alive

  return (
    <div
      className={cn(
        "rounded-xl glass p-4 flex items-center gap-3",
        compact ? "" : "justify-between flex-wrap",
      )}
    >
      <div className="flex items-center gap-3 min-w-0">
        <div
          className={cn(
            "relative h-3 w-3 rounded-full shrink-0",
            active
              ? "bg-emerald-400 shadow-[0_0_12px_2px_oklch(0.70_0.18_150/0.7)]"
              : err
                ? "bg-red-400 shadow-[0_0_12px_2px_oklch(0.62_0.24_22/0.7)]"
                : "bg-muted-foreground/50",
          )}
        >
          {active && (
            <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-50" />
          )}
        </div>
        <div className="min-w-0">
          <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
            Kafka Consumer
          </div>
          <div className="font-mono text-sm truncate">
            {err ? (
              <span className="text-red-400">offline</span>
            ) : (
              <>
                <span className={active ? "text-emerald-300" : "text-muted-foreground"}>
                  {active ? "RUNNING" : "STOPPED"}
                </span>
                {status?.topic && (
                  <span className="text-muted-foreground"> · topic: {status.topic}</span>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <motion.button
          whileTap={{ scale: 0.96 }}
          type="button"
          onClick={start}
          disabled={loading || active}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition",
            "border border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
            "hover:bg-emerald-500/20 disabled:opacity-40 disabled:cursor-not-allowed",
          )}
        >
          {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
          Start
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.96 }}
          type="button"
          onClick={stop}
          disabled={loading || !active}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition",
            "border border-red-500/30 bg-red-500/10 text-red-300",
            "hover:bg-red-500/20 disabled:opacity-40 disabled:cursor-not-allowed",
          )}
        >
          <Square className="h-3.5 w-3.5" />
          Stop
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.96 }}
          type="button"
          onClick={refresh}
          className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/50 px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition"
        >
          <RefreshCw className="h-3.5 w-3.5" />
        </motion.button>
      </div>
    </div>
  )
}
