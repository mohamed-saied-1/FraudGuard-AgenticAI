"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface Props {
  title: string
  subtitle?: string
  badge?: string
  actions?: ReactNode
  children: ReactNode
}

export function PageShell({ title, subtitle, badge, actions, children }: Props) {
  return (
    <div className="mx-auto max-w-7xl px-4 md:px-6 py-8">
      <motion.header
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8 flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          {badge && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-[10px] font-mono uppercase tracking-[0.2em] text-primary">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
              {badge}
            </span>
          )}
          <h1 className="mt-3 text-3xl md:text-4xl font-semibold tracking-tight text-balance">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-2 max-w-2xl text-sm md:text-base text-muted-foreground text-pretty">
              {subtitle}
            </p>
          )}
        </div>
        {actions && <div className="flex items-center gap-2">{actions}</div>}
      </motion.header>
      {children}
    </div>
  )
}
