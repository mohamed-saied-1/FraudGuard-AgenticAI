"use client"

import { Bar, BarChart, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"
import type { ShapDriver } from "@/lib/types"
import { motion } from "framer-motion"

// LLM flag drivers لما SHAP مش متاح
const LLM_FLAG_COLORS: Record<string, string> = {
  "high_amount"   : "oklch(0.78 0.16 75)",   // amber
  "unusual_time"  : "oklch(0.62 0.24 22)",   // red
  "new_location"  : "oklch(0.62 0.24 295)",  // purple
  "high transaction amount" : "oklch(0.78 0.16 75)",
  "unusual timing"          : "oklch(0.62 0.24 22)",
  "new location"            : "oklch(0.62 0.24 295)",
}

export function ShapChart({
  drivers,
  explanation,
}: {
  drivers:     ShapDriver[]
  explanation?: string
}) {
  // ── Case 1: SHAP drivers موجودة وعندهم قيم حقيقية ──
  const hasRealShap = drivers?.some(d => Math.abs(d.shap_value) > 0.001)

  if (hasRealShap) {
    const data = drivers
      .map(d => ({
        name : d.readable || d.feature,
        value: Number(d.shap_value.toFixed(4)),
        abs  : Math.abs(d.shap_value),
      }))
      .sort((a, b) => b.abs - a.abs)
      .slice(0, 8)

    return <ShapBarChart data={data} mode="shap" />
  }

  // ── Case 2: LLM flag drivers (shap_value = 0 لكن readable موجود) ──
  if (drivers?.length > 0) {
    const data = drivers.map((d, i) => ({
      name : d.readable || d.feature,
      value: (3 - i) * 0.33,   // قيمة تقديرية للعرض بس
      abs  : (3 - i) * 0.33,
    }))
    return <ShapBarChart data={data} mode="llm" />
  }

  // ── Case 3: مفيش حاجة خالص ──
  // استخرج flags من الـ explanation
  if (explanation) {
    const synth = []
    if (explanation.includes("high amount") || explanation.includes("high transaction"))
      synth.push({ name: "High Transaction Amount", value: 0.9, abs: 0.9 })
    if (explanation.includes("timing") || explanation.includes("midnight") || explanation.includes("night"))
      synth.push({ name: "Unusual Timing",          value: 0.7, abs: 0.7 })
    if (explanation.includes("location") || explanation.includes("country"))
      synth.push({ name: "New Location",             value: 0.6, abs: 0.6 })
    if (explanation.includes("velocity") || explanation.includes("transactions"))
      synth.push({ name: "Velocity Alert",           value: 1.0, abs: 1.0 })

    if (synth.length > 0)
      return <ShapBarChart data={synth} mode="llm" />
  }

  return (
    <div className="rounded-xl glass p-8 text-center text-sm text-muted-foreground">
      No SHAP drivers available — risk below threshold.
    </div>
  )
}

// ── Shared bar chart ──────────────────────────────────────
function ShapBarChart({
  data,
  mode,
}: {
  data: { name: string; value: number; abs: number }[]
  mode: "shap" | "llm"
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.05 }}
      className="rounded-xl glass p-5"
    >
      <div className="mb-4 flex items-center justify-between">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
            Explainability
          </div>
          <h3 className="text-base font-semibold">Top {mode === "shap" ? "SHAP" : "LLM"} Drivers</h3>
        </div>
        {mode === "shap" ? (
          <div className="flex items-center gap-3 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-sm bg-red-400" /> push fraud
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-sm bg-emerald-400" /> push legit
            </span>
          </div>
        ) : (
          <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400/70 border border-amber-500/20 bg-amber-500/10 rounded-full px-2 py-0.5">
            LLM Risk Flags
          </span>
        )}
      </div>

      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ left: 8, right: 24, top: 4, bottom: 4 }}>
            <XAxis
              type="number"
              tick={{ fill: "oklch(0.65 0.025 280)", fontSize: 11, fontFamily: "var(--font-mono)" }}
              axisLine={{ stroke: "oklch(0.22 0.03 285 / 0.6)" }}
              tickLine={false}
              domain={[0, mode === "llm" ? 1 : "auto"]}
              tickFormatter={v => mode === "llm" ? "" : v.toFixed(2)}
            />
            <YAxis
              type="category"
              dataKey="name"
              width={150}
              tick={{ fill: "oklch(0.85 0.01 280)", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              cursor={{ fill: "oklch(0.62 0.24 295 / 0.08)" }}
              contentStyle={{
                background: "oklch(0.10 0.02 280 / 0.95)",
                border: "1px solid oklch(0.62 0.24 295 / 0.4)",
                borderRadius: 8,
                fontFamily: "var(--font-mono)",
                fontSize: 12,
                color: "oklch(0.96 0.005 280)",
              }}
              formatter={(v: number) =>
                mode === "llm"
                  ? ["Risk Factor Detected", "LLM Flag"]
                  : [v.toFixed(4), "SHAP value"]
              }
            />
            <Bar dataKey="value" radius={[4, 4, 4, 4]}>
              {data.map((d, i) => (
                <Cell
                  key={i}
                  fill={
                    mode === "shap"
                      ? d.value >= 0
                        ? "oklch(0.62 0.24 22)"
                        : "oklch(0.70 0.18 150)"
                      : Object.values(["oklch(0.62 0.24 22)","oklch(0.78 0.16 75)","oklch(0.62 0.24 295)"])[i % 3]
                  }
                  fillOpacity={0.85}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  )
}