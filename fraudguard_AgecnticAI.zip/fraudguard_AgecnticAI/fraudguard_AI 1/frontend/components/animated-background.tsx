// Pure CSS animated background — no JS, no hydration cost.
// Renders as part of the server component tree so content is always visible.

export function AnimatedBackground() {
  return (
    <div
      className="fixed inset-0 overflow-hidden pointer-events-none -z-10"
      aria-hidden="true"
    >
      {/* Solid base */}
      <div className="absolute inset-0 bg-background" />

      {/* Subtle grid lines */}
      <div className="absolute inset-0 grid-bg opacity-40" />

      {/* Aurora orbs — pure CSS animation */}
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />

      {/* Vignette to focus content */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 35%, oklch(0.04 0.01 280 / 0.85) 100%)",
        }}
      />

      {/* Top scan line */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
    </div>
  )
}
