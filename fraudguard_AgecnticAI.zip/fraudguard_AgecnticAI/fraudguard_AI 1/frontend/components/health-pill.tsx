"use client"

import { useEffect, useState } from "react"
import { api } from "@/lib/api"
import { cn } from "@/lib/utils"

type Status = "checking" | "online" | "offline"

export function HealthPill() {
  const [status, setStatus] = useState<Status>("checking")

  useEffect(() => {
    let mounted = true
    const check = async () => {
      try {
        const h = await api.health()
        if (!mounted) return
        setStatus(h.status === "ok" ? "online" : "offline")
      } catch {
        if (mounted) setStatus("offline")
      }
    }
    check()
    const id = setInterval(check, 12_000)
    return () => {
      mounted = false
      clearInterval(id)
    }
  }, [])

  const dotCls =
    status === "online"
      ? "bg-emerald-400 shadow-[0_0_12px_2px_oklch(0.70_0.18_150/0.7)]"
      : status === "offline"
        ? "bg-red-400 shadow-[0_0_12px_2px_oklch(0.62_0.24_22/0.7)]"
        : "bg-amber-400"

  const text =
    status === "online" ? "API Online" : status === "offline" ? "API Offline" : "Checking…"

  return (
    <div
      className={cn(
        "hidden sm:flex items-center gap-2 rounded-full border border-border/60 bg-card/50 px-3 py-1.5 text-xs font-mono",
      )}
    >
      <span className={cn("relative h-2 w-2 rounded-full", dotCls)}>
        {status === "online" && (
          <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-50" />
        )}
      </span>
      <span className="text-muted-foreground">{text}</span>
    </div>
  )
}
