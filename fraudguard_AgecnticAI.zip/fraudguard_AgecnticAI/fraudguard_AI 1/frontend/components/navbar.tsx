"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import {
  LayoutDashboard,
  Brain,
  FileSpreadsheet,
  Radio,
  MessageSquare,
  BarChart3,
  ShieldCheck,
  Menu,
  X,
} from "lucide-react"
import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import { HealthPill } from "@/components/health-pill"

const NAV = [
  { href: "/dashboard", label: "Dashboard", Icon: LayoutDashboard },
  { href: "/predict", label: "Predict", Icon: Brain },
  { href: "/batch", label: "Batch", Icon: FileSpreadsheet },
  { href: "/stream", label: "Stream", Icon: Radio },
  { href: "/chat", label: "Assistant", Icon: MessageSquare },
  { href: "/reports", label: "Reports", Icon: BarChart3 },
]

export function Navbar() {
  const pathname = usePathname() || "/"
  const [open, setOpen] = useState(false)

  // Hide navbar on landing
  const isLanding = pathname === "/"

  useEffect(() => setOpen(false), [pathname])

  if (isLanding) return null

  return (
    <header className="sticky top-0 z-50 border-b border-border/50 glass-strong">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2.5 group">
          <motion.div
            initial={{ rotate: -10, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            className="relative grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-primary to-accent shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.7)]"
          >
            <ShieldCheck className="h-5 w-5 text-primary-foreground" strokeWidth={2.5} />
            <span className="absolute inset-0 rounded-lg ring-1 ring-white/15" />
          </motion.div>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-tight">FraudGuard</span>
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
              AI · v1.0
            </span>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {NAV.map(({ href, label, Icon }) => {
            const active = pathname === href || pathname.startsWith(href + "/")
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "relative flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
                  active
                    ? "text-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                <span>{label}</span>
                {active && (
                  <motion.span
                    layoutId="nav-active"
                    className="absolute inset-0 -z-10 rounded-md bg-primary/15 ring-1 ring-primary/40"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  />
                )}
              </Link>
            )
          })}
        </nav>

        <div className="flex items-center gap-3">
          <HealthPill />
          <button
            type="button"
            aria-label="Toggle menu"
            onClick={() => setOpen((s) => !s)}
            className="md:hidden grid h-9 w-9 place-items-center rounded-md border border-border/60 bg-card/40"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <nav className="md:hidden border-t border-border/50 bg-background/80 backdrop-blur">
          <ul className="px-4 py-3 grid gap-1">
            {NAV.map(({ href, label, Icon }) => {
              const active = pathname === href || pathname.startsWith(href + "/")
              return (
                <li key={href}>
                  <Link
                    href={href}
                    className={cn(
                      "flex items-center gap-2 rounded-md px-3 py-2.5 text-sm",
                      active
                        ? "bg-primary/15 ring-1 ring-primary/40 text-foreground"
                        : "text-muted-foreground hover:bg-muted/40",
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {label}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>
      )}
    </header>
  )
}
