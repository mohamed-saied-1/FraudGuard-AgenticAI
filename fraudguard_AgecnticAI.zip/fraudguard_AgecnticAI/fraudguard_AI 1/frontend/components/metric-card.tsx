"use client"

import { motion } from "framer-motion"
import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface Props {
  label: string
  value: string | number
  sub?: string
  Icon?: LucideIcon
  tone?: "primary" | "danger" | "success" | "warning" | "muted"
  delay?: number
}

const TONE: Record<NonNullable<Props["tone"]>, string> = {
  primary: "text-primary",
  danger: "text-red-400",
  success: "text-emerald-400",
  warning: "text-amber-400",
  muted: "text-muted-foreground",
}

export function MetricCard({ label, value, sub, Icon, tone = "primary", delay = 0 }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      whileHover={{ y: -2 }}
      className="group relative overflow-hidden rounded-xl glass p-5"
    >
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent opacity-60" />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
            {label}
          </div>
          <div className="mt-2 font-mono text-3xl font-semibold tabular-nums">{value}</div>
          {sub && <div className="mt-1 text-xs text-muted-foreground">{sub}</div>}
        </div>
        {Icon && (
          <div
            className={cn(
              "grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-primary/10 ring-1 ring-primary/30 transition-shadow",
              "group-hover:shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.6)]",
              TONE[tone],
            )}
          >
            <Icon className="h-5 w-5" />
          </div>
        )}
      </div>
    </motion.div>
  )
}
