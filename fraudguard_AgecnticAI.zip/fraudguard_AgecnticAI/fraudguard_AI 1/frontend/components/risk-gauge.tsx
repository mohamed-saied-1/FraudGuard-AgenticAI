"use client"

import { motion, useMotionValue, useTransform, animate } from "framer-motion"
import { useEffect } from "react"

interface Props {
  value: number // 0..1
  label?: string
  size?: number
}

export function RiskGauge({ value, label = "Total Risk", size = 220 }: Props) {
  const radius = size / 2 - 16
  const circ = 2 * Math.PI * radius
  const target = Math.max(0, Math.min(1, value))
  const display = useMotionValue(0)
  const offset = useTransform(display, (v) => circ * (1 - v))
  const pct = useTransform(display, (v) => `${Math.round(v * 100)}`)

  useEffect(() => {
    const ctrl = animate(display, target, { duration: 0.9, ease: "easeOut" })
    return () => ctrl.stop()
  }, [target, display])

  const stroke =
    target >= 0.7 ? "oklch(0.62 0.24 22)" : target >= 0.4 ? "oklch(0.78 0.16 75)" : "oklch(0.70 0.18 150)"

  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="rotate-[-90deg]" aria-label={label}>
        <defs>
          <linearGradient id="riskGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="oklch(0.62 0.24 295)" />
            <stop offset="100%" stopColor="oklch(0.70 0.22 305)" />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="oklch(0.22 0.03 285 / 0.6)"
          strokeWidth={10}
          fill="none"
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={stroke}
          strokeWidth={10}
          strokeLinecap="round"
          fill="none"
          style={{
            strokeDasharray: circ,
            strokeDashoffset: offset,
            filter: `drop-shadow(0 0 12px ${stroke})`,
          }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <motion.div className="font-mono text-4xl font-semibold tabular-nums">
            <motion.span>{pct}</motion.span>
            <span className="text-xl text-muted-foreground">%</span>
          </motion.div>
          <div className="mt-1 text-[10px] font-mono uppercase tracking-[0.25em] text-muted-foreground">
            {label}
          </div>
        </div>
      </div>
    </div>
  )
}
