"use client"

import { motion } from "framer-motion"
import { ShieldAlert, ShieldCheck, ShieldQuestion, KeyRound } from "lucide-react"
import { cn } from "@/lib/utils"
import type { PredictResponse } from "@/lib/types"
import { decisionTone } from "@/lib/constants"

function Icon({ d }: { d: string }) {
  if (d.startsWith("BLOCK")) return <ShieldAlert className="h-7 w-7" />
  if (d.startsWith("REVIEW")) return <ShieldQuestion className="h-7 w-7" />
  if (d.startsWith("ALLOW")) return <ShieldCheck className="h-7 w-7" />
  if (d.startsWith("MFA")) return <KeyRound className="h-7 w-7" />
  return <ShieldQuestion className="h-7 w-7" />
}

export function DecisionCard({ result }: { result: PredictResponse }) {
  const tone = decisionTone(result.decision)
  const isBlock = result.decision.startsWith("BLOCK")

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      className={cn(
        "relative overflow-hidden rounded-2xl glass-strong p-6",
        tone.border,
        tone.glow,
        isBlock && "animate-danger-pulse",
      )}
    >
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />
      <div className="flex items-center gap-4">
        <div className={cn("grid h-14 w-14 place-items-center rounded-xl ring-1", tone.bg, tone.border, tone.color)}>
          <Icon d={result.decision} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-[11px] font-mono uppercase tracking-[0.25em] text-muted-foreground">
            Decision
          </div>
          <div className={cn("text-2xl font-semibold tracking-tight", tone.color)}>
            {result.decision}
          </div>
        </div>
        <div className="text-right shrink-0">
          <div className="text-[11px] font-mono uppercase tracking-[0.25em] text-muted-foreground">
            Total Risk
          </div>
          <div className="font-mono text-3xl font-semibold tabular-nums">
            {(result.total_risk * 100).toFixed(1)}
            <span className="text-base text-muted-foreground">%</span>
          </div>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Stat k="Probability" v={`${(result.probability * 100).toFixed(2)}%`} />
        <Stat k="SHAP" v={result.shap_score.toFixed(3)} />
        <Stat k="Forecast" v={result.forecast_risk.toFixed(3)} />
        <Stat k="Confidence" v={result.confidence_band} />
      </div>

      {result.explanation && (
        <p className="mt-5 rounded-lg border border-border/60 bg-background/40 p-3 text-sm text-muted-foreground">
          {result.explanation}
        </p>
      )}

      <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] font-mono">
        {result.layers_used?.map((l) => (
          <span
            key={l}
            className="rounded-md border border-border/60 bg-muted/40 px-2 py-0.5 uppercase tracking-wider text-muted-foreground"
          >
            {l}
          </span>
        ))}
        {result.llm_override && (
          <span className="rounded-md border border-accent/40 bg-accent/10 px-2 py-0.5 uppercase tracking-wider text-accent-foreground">
            LLM override
          </span>
        )}
        <span className="ml-auto text-muted-foreground">
          {result.latency_ms}ms · {new Date(result.timestamp).toLocaleTimeString()}
        </span>
      </div>
    </motion.div>
  )
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-lg border border-border/60 bg-background/40 px-3 py-2">
      <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-muted-foreground">{k}</div>
      <div className="font-mono text-sm font-semibold tabular-nums">{v}</div>
    </div>
  )
}
