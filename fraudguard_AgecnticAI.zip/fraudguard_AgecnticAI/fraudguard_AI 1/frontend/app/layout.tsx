import type { Metadata, Viewport } from "next"
import { Space_Grotesk, JetBrains_Mono } from "next/font/google"
import { Toaster } from "@/components/ui/sonner"
import { AnimatedBackground } from "@/components/animated-background"
import { Navbar } from "@/components/navbar"
import "./globals.css"

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  display: "swap",
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: "FraudGuard AI — Real-Time Fraud Detection",
  description:
    "Production-grade AI fraud detection platform with SHAP explainability, Kafka streaming, and adaptive risk scoring.",
  generator: "v0.app",
}

export const viewport: Viewport = {
  themeColor: "#0a0814",
  colorScheme: "dark",
}

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={`dark ${spaceGrotesk.variable} ${jetbrainsMono.variable}`}
    >
      <body className="bg-background text-foreground font-sans antialiased min-h-screen relative">
        <AnimatedBackground />
        <Navbar />
        <main className="relative z-10">{children}</main>
        <Toaster
          theme="dark"
          position="top-right"
          toastOptions={{
            style: {
              background: "oklch(0.11 0.02 280 / 0.9)",
              border: "1px solid oklch(0.62 0.24 295 / 0.3)",
              backdropFilter: "blur(12px)",
              color: "oklch(0.96 0.005 280)",
            },
          }}
        />
      </body>
    </html>
  )
}
