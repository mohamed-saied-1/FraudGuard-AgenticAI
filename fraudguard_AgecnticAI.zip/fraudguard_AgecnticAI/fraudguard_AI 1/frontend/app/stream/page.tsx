"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Play, Pause, Trash2, Activity, Wifi, WifiOff, Send, Terminal,
  Brain, Zap, TrendingUp, Shield, AlertTriangle, Database,
  HeartPulse, CheckCircle2,
} from "lucide-react"
import { WS_BASE, API_BASE, api } from "@/lib/api"
import type { StreamMessage, RagStatusResponse, AgentHealthResponse } from "@/lib/types"
import { PageShell }     from "@/components/page-shell"
import { KafkaControls } from "@/components/kafka-controls"
import { decisionTone }  from "@/lib/constants"
import { cn }            from "@/lib/utils"
import { Line, LineChart, ResponsiveContainer, YAxis, Tooltip } from "recharts"
import { toast }         from "sonner"

type ConnState = "idle" | "connecting" | "open" | "closed" | "error"

// ── Preemptive Action Badge ──────────────────────────────────────
function ActionBadge({ action }: { action?: string }) {
  if (!action || action === "none") return null
  const map: Record<string, { label: string; cls: string }> = {
    escalate_now  : { label: "⬆ ESCALATE", cls: "border-red-500/50 bg-red-500/15 text-red-300"      },
    monitor_close : { label: "👁 MONITOR",  cls: "border-amber-500/50 bg-amber-500/15 text-amber-300" },
    soft_flag     : { label: "⚑ FLAG",      cls: "border-blue-500/50 bg-blue-500/15 text-blue-300"   },
  }
  const m = map[action]
  if (!m) return null
  return (
    <span className={cn(
      "inline-flex items-center rounded border px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase",
      m.cls,
    )}>
      {m.label}
    </span>
  )
}

// ── Deterioration Mini-Bar ───────────────────────────────────────
function DeteriorationBar({ value }: { value?: number }) {
  if (value === undefined || value === null) return null
  const pct  = Math.round(value * 100)
  const color = value > 0.7 ? "bg-red-500" : value > 0.4 ? "bg-amber-500" : "bg-emerald-500"
  return (
    <span className="flex items-center gap-1">
      <span className="text-muted-foreground/60 text-[9px] font-mono">det</span>
      <span className="w-10 h-1 rounded-full bg-white/8 overflow-hidden">
        <span className={cn("block h-full rounded-full", color)} style={{ width: `${pct}%` }} />
      </span>
      <span className={cn("text-[9px] font-mono tabular-nums",
        value > 0.7 ? "text-red-400" : value > 0.4 ? "text-amber-400" : "text-white/40")}>
        {pct}%
      </span>
    </span>
  )
}

// ── RAG Status Panel ────────────────────────────────────────────
function RagPanel({ rag }: { rag: RagStatusResponse | null }) {
  if (!rag) return (
    <div className="flex h-16 items-center justify-center text-[10px] font-mono text-muted-foreground/50">
      Loading RAG status…
    </div>
  )

  const progressPct = Math.min(100, Math.round(rag.explicit_rag_size / rag.min_docs_needed * 100))

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className={cn(
          "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider",
          rag.ready
            ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
            : "border-amber-500/40 bg-amber-500/10 text-amber-300",
        )}>
          <span className={cn("h-1.5 w-1.5 rounded-full",
            rag.ready ? "bg-emerald-400" : "bg-amber-400 animate-pulse")} />
          {rag.ready ? "RAG READY" : `WARMING UP ${progressPct}%`}
        </span>
        <span className="text-[10px] font-mono text-muted-foreground">
          {rag.explicit_rag_size} / {rag.min_docs_needed} docs
        </span>
      </div>

      {!rag.ready && (
        <div className="h-1.5 w-full rounded-full bg-white/8 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progressPct}%` }}
            className="h-full rounded-full bg-amber-500"
          />
        </div>
      )}

      <div className="grid grid-cols-2 gap-1.5 text-[9px] font-mono">
        <div className="rounded border border-border/40 bg-background/30 px-2 py-1.5 text-center">
          <div className="text-muted-foreground uppercase tracking-wider mb-0.5">K Neighbors</div>
          <div className="font-semibold text-foreground">{rag.k_neighbors}</div>
        </div>
        <div className="rounded border border-border/40 bg-background/30 px-2 py-1.5 text-center">
          <div className="text-muted-foreground uppercase tracking-wider mb-0.5">Borderline</div>
          <div className="font-semibold text-foreground">
            {rag.borderline_range[0]}–{rag.borderline_range[1]}
          </div>
        </div>
      </div>

      <div>
        <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground mb-1.5">
          Active Routing Paths
        </div>
        <div className="flex flex-wrap gap-1">
          {rag.seven_paths.slice(0, 8).map((p) => (
            <span key={p}
              className="rounded border border-primary/20 bg-primary/8 px-1.5 py-0.5 text-[8px] font-mono text-primary/70">
              {p.replace("P", "").replace(/_/g, " ")}
            </span>
          ))}
        </div>
      </div>

      <div className="rounded border border-border/40 bg-background/30 px-2 py-1.5 text-[9px] font-mono">
        <span className="text-muted-foreground">Implicit RAG: </span>
        <span className="text-primary/70">SHAP cosine → cluster mean</span>
      </div>
    </div>
  )
}

// ── ★ NEW: Self-Healing Health Panel ────────────────────────────
function AgentHealthPanel({ data }: { data: AgentHealthResponse | null }) {
  if (!data) {
    return (
      <div className="flex h-16 items-center justify-center text-[10px] font-mono text-muted-foreground/50">
        Loading health monitor…
      </div>
    )
  }

  const components: { key: keyof AgentHealthResponse; label: string }[] = [
    { key: "shap_ok",  label: "SHAP"  },
    { key: "kafka_ok", label: "Kafka" },
    { key: "llm_ok",   label: "LLM"   },
    { key: "rag_ok",   label: "RAG"   },
  ]

  const allOk = components.every(({ key }) => data[key])

  return (
    <div className="space-y-3">
      {/* Overall status badge */}
      <span className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider",
        allOk
          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
          : "border-red-500/40 bg-red-500/10 text-red-300",
      )}>
        <span className={cn("h-1.5 w-1.5 rounded-full",
          allOk ? "bg-emerald-400 animate-pulse" : "bg-red-400")} />
        {allOk ? "All systems normal" : "Fallbacks active"}
      </span>

      {/* Component grid */}
      <div className="grid grid-cols-2 gap-1.5">
        {components.map(({ key, label }) => {
          const ok  = data[key] as boolean
          const sub = data.subsystems?.[key.replace("_ok", "")]
          return (
            <div key={key}
              className={cn(
                "rounded border px-2.5 py-2",
                ok ? "border-emerald-500/25 bg-emerald-500/8" : "border-red-500/25 bg-red-500/8",
              )}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-semibold">{label}</span>
                {ok
                  ? <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                  : <AlertTriangle className="h-3 w-3 text-red-400" />}
              </div>
              {!ok && sub?.fallback && (
                <div className="mt-0.5 text-[9px] font-mono text-amber-400/80">
                  ↳ {sub.fallback.replace(/_/g, " ")}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Recent alerts */}
      {data.alerts && data.alerts.length > 0 && (
        <div className="space-y-1">
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">
            Recent Alerts
          </div>
          {data.alerts.slice(0, 2).map((a, i) => (
            <div key={i} className="flex items-start gap-1.5 rounded border border-red-500/20 bg-red-500/5 px-2 py-1.5">
              <AlertTriangle className="h-3 w-3 text-red-400 shrink-0 mt-0.5" />
              <div className="min-w-0">
                <div className="text-[9px] font-mono text-red-300 truncate">
                  {a.component} · {a.fallback?.replace(/_/g, " ")}
                </div>
                {a.error && (
                  <div className="text-[8px] font-mono text-muted-foreground/50 truncate">
                    {a.error}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ════════════════════════════════════════════════════════════════
// MAIN PAGE
// ════════════════════════════════════════════════════════════════

export default function StreamPage() {
  const [items,      setItems]      = useState<StreamMessage[]>([])
  const [state,      setState]      = useState<ConnState>("idle")
  const [ragStatus,  setRagStatus]  = useState<RagStatusResponse | null>(null)
  const [agentHealth,setAgentHealth]= useState<AgentHealthResponse | null>(null)   // ★ NEW
  const wsRef        = useRef<WebSocket | null>(null)
  const reconnectRef = useRef<NodeJS.Timeout | null>(null)
  const isStreamRef  = useRef(false)

  const [amount, setAmount] = useState("")
  const [time,   setTime]   = useState("10")
  const [cardId, setCardId] = useState("")
  const [desc,   setDesc]   = useState("")

  // ★ FIXED: uses api.kafkaConsumerLog instead of direct fetch
  const [kafkaLog,   setKafkaLog]   = useState<any[]>([])
  const [kafkaStats, setKafkaStats] = useState({ total: 0, fraud: 0, accuracy: 0 })

  const fetchKafkaLog = useCallback(async () => {
    try {
      const d = await api.kafkaConsumerLog(30)   // ★ was: fetch(`${API_BASE}/kafka/consumer/log?limit=30`)
      setKafkaLog(d.entries ?? [])
      setKafkaStats({ total: d.total, fraud: d.fraud, accuracy: d.accuracy })
    } catch {}
  }, [])

  const fetchRag = useCallback(async () => {
    try {
      const r = await api.agentRagStatus()
      setRagStatus(r)
    } catch {}
  }, [])

  // ★ NEW: fetch agent health
  const fetchHealth = useCallback(async () => {
    try {
      const r = await api.agentHealth()
      setAgentHealth(r)
    } catch {}
  }, [])

  useEffect(() => {
    fetchKafkaLog()
    fetchRag()
    fetchHealth()
    const kafkaId  = setInterval(fetchKafkaLog, 5000)
    const ragId    = setInterval(fetchRag, 10000)
    const healthId = setInterval(fetchHealth, 10000)   // ★ NEW
    return () => {
      clearInterval(kafkaId)
      clearInterval(ragId)
      clearInterval(healthId)
    }
  }, [fetchKafkaLog, fetchRag, fetchHealth])

  const open = () => {
    if (wsRef.current?.readyState === WebSocket.OPEN ||
        wsRef.current?.readyState === WebSocket.CONNECTING) return
    isStreamRef.current = true
    setState("connecting")
    try {
      const ws = new WebSocket(`${WS_BASE}/ws/stream`)
      wsRef.current = ws
      ws.onopen    = () => { setState("open"); toast.success("Stream connected") }
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data) as StreamMessage
          setItems((prev) => [msg, ...prev].slice(0, 50))
        } catch { /* ignore malformed */ }
      }
      ws.onerror = () => setState("error")
      ws.onclose = () => {
        setState("closed"); wsRef.current = null
        if (isStreamRef.current) {
          reconnectRef.current = setTimeout(() => { if (isStreamRef.current) open() }, 3000)
        }
      }
    } catch (e) {
      setState("error")
      toast.error(`WebSocket error: ${(e as Error).message}`)
    }
  }

  const close = () => {
    isStreamRef.current = false
    if (reconnectRef.current) { clearTimeout(reconnectRef.current); reconnectRef.current = null }
    wsRef.current?.close(); wsRef.current = null; setState("closed")
  }

  useEffect(() => () => {
    isStreamRef.current = false
    if (reconnectRef.current) clearTimeout(reconnectRef.current)
    wsRef.current?.close(); wsRef.current = null
  }, [])

  const sendManual = (e: React.FormEvent) => {
    e.preventDefault()
    if (wsRef.current?.readyState !== WebSocket.OPEN) {
      toast.error("Stream not connected. Press Start first."); return
    }
    const hours        = parseInt(time, 10) || 0
    const secondsInDay = hours * 3600
    const payload: Record<string, unknown> = { amount: Number(amount) || 0, time: secondsInDay }
    if (cardId) payload.card_id          = cardId
    if (desc)   payload.text_description = desc
    wsRef.current.send(JSON.stringify(payload))
    setAmount(""); setCardId(""); setDesc("")
    toast.success(`Event sent — hour ${hours} (${secondsInDay}s)`)
  }

  const trendData = [...items].reverse().slice(-30).map((m, i) => ({
    i,
    risk         : Number(m.risk?.toFixed(3) || 0),
    prob         : Number((m.probability || 0).toFixed(3)),
    deterioration: Number((m.deterioration || 0).toFixed(3)),
  }))

  const counts = items.reduce(
    (acc, m) => {
      if (m.decision?.startsWith("BLOCK"))       acc.block++
      else if (m.decision?.startsWith("REVIEW")) acc.review++
      else if (m.decision?.startsWith("ALLOW"))  acc.allow++
      return acc
    },
    { block: 0, review: 0, allow: 0 },
  )

  return (
    <PageShell
      title="Real-Time Stream"
      subtitle="Live Kafka decisions over WebSocket with full Agentic AI metadata — deterioration, ReAct path, preemptive action."
      badge="Stream"
      actions={
        <div className="flex items-center gap-2">
          {state === "open" ? (
            <button type="button" onClick={close}
              className="inline-flex items-center gap-1.5 rounded-md border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs font-medium text-red-300 hover:bg-red-500/20 transition">
              <Pause className="h-4 w-4" /> Stop Stream
            </button>
          ) : (
            <button type="button" onClick={open}
              className="inline-flex items-center gap-1.5 rounded-md bg-gradient-to-br from-primary to-accent px-3 py-2 text-xs font-medium text-primary-foreground shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.6)] transition hover:shadow-[0_0_36px_-2px_oklch(0.62_0.24_295/0.9)]">
              <Play className="h-4 w-4" /> Start Stream
            </button>
          )}
          {items.length > 0 && (
            <button type="button" onClick={() => setItems([])}
              className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/50 px-3 py-2 text-xs font-medium text-muted-foreground hover:text-foreground transition">
              <Trash2 className="h-4 w-4" /> Clear
            </button>
          )}
        </div>
      }
    >
      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        {/* ── Left column ── */}
        <div className="space-y-4">
          <KafkaControls />

          {/* Connection status + Risk/Deterioration trend chart */}
          <div className="rounded-xl glass p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <ConnDot state={state} />
                <div>
                  <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">WebSocket</div>
                  <div className="font-mono text-sm">
                    {state.toUpperCase()}
                    <span className="text-muted-foreground"> · {WS_BASE}/ws/stream</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono">
                <Pill tone="emerald" label={`A ${counts.allow}`} />
                <Pill tone="amber"   label={`R ${counts.review}`} />
                <Pill tone="red"     label={`B ${counts.block}`} />
              </div>
            </div>

            {/* Three-line chart: risk + prob + deterioration */}
            <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendData} margin={{ left: 0, right: 0, top: 6, bottom: 0 }}>
                  <YAxis hide domain={[0, 1]} />
                  <Tooltip
                    contentStyle={{
                      background: "oklch(0.10 0.02 280 / 0.95)",
                      border: "1px solid oklch(0.62 0.24 295 / 0.4)",
                      borderRadius: 8, fontFamily: "var(--font-mono)", fontSize: 11,
                    }}
                    labelFormatter={() => ""}
                    formatter={(v: number, n: string) => [
                      `${(v * 100).toFixed(1)}%`,
                      n === "risk" ? "Risk" : n === "prob" ? "Prob" : "Deterioration",
                    ]}
                  />
                  <Line type="monotone" dataKey="risk"
                    stroke="oklch(0.62 0.24 295)" strokeWidth={2} dot={false} isAnimationActive={false} />
                  <Line type="monotone" dataKey="prob"
                    stroke="oklch(0.70 0.22 305)" strokeWidth={1.5} strokeDasharray="3 3" dot={false} isAnimationActive={false} />
                  <Line type="monotone" dataKey="deterioration"
                    stroke="oklch(0.62 0.24 22)" strokeWidth={1.5} strokeDasharray="2 4" dot={false} isAnimationActive={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-1 flex items-center gap-4 text-[9px] font-mono text-muted-foreground/60">
              <span className="flex items-center gap-1">
                <span className="inline-block w-3 h-0.5 bg-[oklch(0.62_0.24_295)] rounded" /> Risk
              </span>
              <span className="flex items-center gap-1">
                <span className="inline-block w-3 h-0.5 border-t border-dashed border-[oklch(0.70_0.22_305)]" /> Prob
              </span>
              <span className="flex items-center gap-1">
                <span className="inline-block w-3 h-0.5 border-t border-dashed border-[oklch(0.62_0.24_22)]" /> Deterioration
              </span>
            </div>
          </div>

          {/* Live Feed */}
          <div className="rounded-xl glass overflow-hidden">
            <div className="flex items-center justify-between border-b border-border/50 px-5 py-3">
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Activity className="h-4 w-4 text-primary" /> Live Feed
                <span className="text-[10px] font-mono text-muted-foreground font-normal">
                  · Agentic AI
                </span>
              </h3>
              <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
                {items.length} / 50
              </span>
            </div>
            <div className="max-h-[520px] overflow-auto no-scrollbar">
              {items.length === 0 ? (
                <div className="p-10 text-center text-sm text-muted-foreground">
                  {state === "open"
                    ? "Connected — waiting for events…"
                    : "Press Start Stream to begin receiving live transactions."}
                </div>
              ) : (
                <ul>
                  <AnimatePresence initial={false}>
                    {items.map((m, idx) => {
                      const tone = decisionTone(m.decision)
                      const path = (m.react_path || m.path || "").replace(/_/g, " ")
                      return (
                        <motion.li
                          key={`${m.ts}-${idx}`}
                          layout
                          initial={{ opacity: 0, x: -16, backgroundColor: "oklch(0.62 0.24 295 / 0.12)" }}
                          animate={{ opacity: 1, x: 0,  backgroundColor: "oklch(0.62 0.24 295 / 0)" }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.35 }}
                          className="border-b border-border/30 px-5 py-2.5 font-mono text-xs"
                        >
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={cn(
                              "inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold uppercase border",
                              tone.bg, tone.border, tone.color,
                            )}>
                              {tone.label}
                            </span>
                            <span className={cn("font-semibold", tone.color)}>
                              {(m.risk * 100).toFixed(1)}%
                            </span>
                            <span className="text-muted-foreground/50">·</span>
                            <span className="text-white/70">
                              p={(m.probability * 100).toFixed(2)}%
                            </span>
                            <span className="text-muted-foreground/50">·</span>
                            <span className="text-primary/60">{m.band}</span>
                            {m.preemptive_action && m.preemptive_action !== "none" && (
                              <>
                                <span className="text-muted-foreground/50">·</span>
                                <ActionBadge action={m.preemptive_action} />
                              </>
                            )}
                            <span className="ml-auto text-muted-foreground/40 tabular-nums text-[9px]">
                              {new Date(m.ts).toLocaleTimeString()}
                            </span>
                          </div>
                          <div className="mt-1 flex items-center gap-3 flex-wrap">
                            {path && (
                              <span className="text-[9px] text-primary/50 truncate max-w-[160px]">
                                {path}
                              </span>
                            )}
                            <DeteriorationBar value={m.deterioration} />
                            {m.agent_latency_ms !== undefined && m.agent_latency_ms > 0 && (
                              <span className="text-[9px] text-muted-foreground/40 flex items-center gap-0.5">
                                <Zap className="h-2.5 w-2.5" />
                                {m.agent_latency_ms.toFixed(0)}ms
                              </span>
                            )}
                          </div>
                        </motion.li>
                      )
                    })}
                  </AnimatePresence>
                </ul>
              )}
            </div>
          </div>

          {/* Kafka Consumer Log */}
          <div className="rounded-xl glass overflow-hidden">
            <div className="flex items-center justify-between border-b border-border/50 px-5 py-3">
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Terminal className="h-4 w-4 text-primary" /> Kafka Consumer Log
              </h3>
              <div className="flex items-center gap-3 text-[10px] font-mono text-muted-foreground">
                {kafkaStats.total > 0 && (
                  <>
                    <span>total=<span className="text-white">{kafkaStats.total}</span></span>
                    <span>fraud=<span className="text-red-300">{kafkaStats.fraud}</span></span>
                    <span>acc=<span className="text-emerald-300">{kafkaStats.accuracy}%</span></span>
                  </>
                )}
                <button onClick={fetchKafkaLog}
                  className="text-muted-foreground hover:text-white transition ml-2">↻</button>
              </div>
            </div>
            <div className="max-h-[360px] overflow-auto no-scrollbar bg-[#070710]/60">
              {kafkaLog.length === 0 ? (
                <div className="p-8 text-center text-xs font-mono text-muted-foreground/60">
                  Kafka consumer not running or no messages yet...
                  <br />Start the consumer:{" "}
                  <span className="text-primary">python consumer.py</span>
                </div>
              ) : (
                <ul className="py-2">
                  {kafkaLog.map((entry, i) => {
                    const isBlock  = String(entry.decision ?? "").includes("BLOCK")
                    const isReview = String(entry.decision ?? "").includes("REVIEW")
                    const isAllow  = String(entry.decision ?? "").includes("ALLOW")
                    const truth    = entry.is_fraud === 1 ? "FRAUD 🚨" : entry.is_fraud === 0 ? "LEGIT  ✅" : "?"
                    const modelFraud = isBlock || isReview
                    const correct  = entry.is_fraud !== -1 && entry.is_fraud !== null
                      ? (modelFraud && entry.is_fraud === 1) || (!modelFraud && entry.is_fraud === 0)
                      : null
                    const decColor = isBlock ? "text-red-400" : isReview ? "text-amber-400"
                                   : isAllow ? "text-emerald-400" : "text-muted-foreground"
                    const marker   = correct === true ? "✅" : correct === false ? "❌" : "·"
                    const v14      = entry.v14 != null
                      ? `V14=${Number(entry.v14) >= 0 ? "+" : ""}${Number(entry.v14).toFixed(2)}` : ""
                    return (
                      <motion.li key={i}
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.02 }}
                        className="px-5 py-1.5 font-mono text-[11px] border-b border-white/5 hover:bg-white/[0.02] transition flex items-center gap-2 flex-wrap">
                        <span className="text-white/40 w-4 shrink-0">{marker}</span>
                        <span className="text-white/50 w-10 shrink-0">u={entry.user_id ?? "?"}</span>
                        <span className="text-white/70 w-20 shrink-0">
                          ${Number(entry.amount ?? 0).toFixed(2)}
                        </span>
                        <span className="text-primary/60 w-20 shrink-0 truncate">{entry.location ?? "?"}</span>
                        {v14 && (
                          <span className={cn("w-20 shrink-0",
                            Number(entry.v14) < -2 ? "text-red-400" : "text-white/40")}>
                            {v14}
                          </span>
                        )}
                        <span className="text-white/40">p={((entry.probability ?? 0) * 100).toFixed(2)}%</span>
                        <span className={cn("font-semibold", decColor)}>
                          {String(entry.decision ?? "").replace("🚫","").replace("✅","").replace("⚠️","").trim()}
                        </span>
                        <span className={cn(
                          Number(entry.risk ?? 0) > 0.6 ? "text-red-400" :
                          Number(entry.risk ?? 0) > 0.3 ? "text-amber-400" : "text-white/40",
                        )}>
                          risk={((entry.risk ?? 0) * 100).toFixed(1)}%
                        </span>
                        <span className="ml-auto text-white/30 shrink-0">{truth}</span>
                      </motion.li>
                    )
                  })}
                </ul>
              )}
            </div>
          </div>
        </div>

        {/* ── Right column ── */}
        <div className="space-y-4">
          {/* Manual injector */}
          <motion.form onSubmit={sendManual}
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="rounded-xl glass p-5">
            <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
              Manual Inject
            </div>
            <h3 className="mt-1 text-lg font-semibold">Send via WebSocket</h3>
            <p className="mt-1 text-xs text-muted-foreground">Push a synthetic transaction to the live stream.</p>
            <div className="mt-4 space-y-3">
              <Field label="Amount">
                <input type="number" step="0.01" value={amount}
                  onChange={(e) => setAmount(e.target.value)} placeholder="1234.56" required className="input" />
              </Field>
              <Field label="Hour (0–23)">
                <input type="number" min="0" max="23" value={time}
                  onChange={(e) => setTime(e.target.value)} placeholder="10" required className="input" />
              </Field>
              <Field label="Card ID (optional)">
                <input value={cardId} onChange={(e) => setCardId(e.target.value)}
                  placeholder="card_abc123" className="input" />
              </Field>
              <Field label="Description (optional)">
                <input value={desc} onChange={(e) => setDesc(e.target.value)}
                  placeholder="Online purchase" className="input" />
              </Field>
            </div>
            <button type="submit" disabled={state !== "open"}
              className="mt-4 w-full inline-flex items-center justify-center gap-2 rounded-lg bg-gradient-to-br from-primary to-accent px-4 py-2 text-sm font-medium text-primary-foreground shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.6)] transition disabled:opacity-50">
              <Send className="h-4 w-4" /> Send Event
            </button>
            <style jsx>{`
              .input {
                width: 100%;
                border-radius: 0.5rem;
                border: 1px solid oklch(0.22 0.03 285 / 0.6);
                background: oklch(0.10 0.02 280 / 0.5);
                padding: 0.5rem 0.75rem;
                font-size: 0.875rem;
                font-family: var(--font-mono);
                outline: none;
                transition: border-color 0.15s;
              }
              .input:focus {
                border-color: oklch(0.62 0.24 295 / 0.6);
                box-shadow: 0 0 0 4px oklch(0.62 0.24 295 / 0.15);
              }
            `}</style>
          </motion.form>

          {/* Explicit RAG Status Panel */}
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }} className="rounded-xl glass p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                  Explicit RAG
                </div>
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Database className="h-4 w-4 text-primary" /> KNN Index
                </h3>
              </div>
              <button onClick={fetchRag}
                className="text-[10px] font-mono text-muted-foreground hover:text-foreground transition">
                ↻
              </button>
            </div>
            <RagPanel rag={ragStatus} />
          </motion.div>

          {/* ★ NEW: Self-Healing Health Panel */}
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }} className="rounded-xl glass p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                  Agentic Feature 7
                </div>
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <HeartPulse className="h-4 w-4 text-primary" /> Self-Healing Monitor
                </h3>
              </div>
              <button onClick={fetchHealth}
                className="text-[10px] font-mono text-muted-foreground hover:text-foreground transition">
                ↻
              </button>
            </div>
            <AgentHealthPanel data={agentHealth} />
          </motion.div>

          {/* Agentic legend */}
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="rounded-xl glass p-4 text-[10px] font-mono space-y-2">
            <div className="text-muted-foreground uppercase tracking-wider mb-2">
              Live Feed Legend
            </div>
            {[
              { icon: <Brain       className="h-3 w-3 text-primary"   />, label: "det=X%",      desc: "Deterioration score"        },
              { icon: <Zap         className="h-3 w-3 text-primary"   />, label: "Xms",          desc: "Agent ReAct latency"        },
              { icon: <AlertTriangle className="h-3 w-3 text-red-400" />, label: "⬆ ESCALATE",   desc: "Preemptive: escalate now"   },
              { icon: <Shield      className="h-3 w-3 text-amber-400" />, label: "👁 MONITOR",   desc: "Preemptive: close monitoring"},
              { icon: <TrendingUp  className="h-3 w-3 text-blue-400"  />, label: "⚑ FLAG",       desc: "Preemptive: soft flag"       },
            ].map(({ icon, label, desc }) => (
              <div key={label} className="flex items-center gap-2">
                {icon}
                <span className="text-foreground/80">{label}</span>
                <span className="text-muted-foreground">— {desc}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </PageShell>
  )
}

// ── Sub-components ───────────────────────────────────────────────

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  )
}

function ConnDot({ state }: { state: ConnState }) {
  const cls =
    state === "open"       ? "bg-emerald-400 shadow-[0_0_12px_2px_oklch(0.70_0.18_150/0.7)]" :
    state === "connecting" ? "bg-amber-400 shadow-[0_0_12px_2px_oklch(0.78_0.16_75/0.5)]"   :
    state === "error"      ? "bg-red-400 shadow-[0_0_12px_2px_oklch(0.62_0.24_22/0.7)]"      :
    "bg-muted-foreground/50"
  const Icon = state === "open" ? Wifi : WifiOff
  return (
    <div className="relative flex items-center gap-2">
      <span className={cn("relative h-2.5 w-2.5 rounded-full", cls)}>
        {state === "open" && (
          <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-50" />
        )}
      </span>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </div>
  )
}

function Pill({ tone, label }: { tone: "emerald" | "amber" | "red"; label: string }) {
  const map: Record<typeof tone, string> = {
    emerald: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
    amber  : "border-amber-500/40 bg-amber-500/10 text-amber-300",
    red    : "border-red-500/40 bg-red-500/10 text-red-300",
  }
  return (
    <span className={cn("rounded-full border px-2 py-0.5 uppercase tracking-wider text-[10px]", map[tone])}>
      {label}
    </span>
  )
}