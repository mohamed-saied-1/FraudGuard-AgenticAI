import Link from "next/link"
import {
  ShieldCheck,
  ArrowRight,
  Brain,
  Radio,
  FileSpreadsheet,
  MessageSquare,
  BarChart3,
  Zap,
  ScanLine,
  LayoutDashboard,
} from "lucide-react"

export default function LandingPage() {
  return (
    <div className="relative">
      {/* Hero */}
      <section className="relative mx-auto max-w-7xl px-4 md:px-6 pt-16 md:pt-24 pb-20">
        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-12 items-center">
          {/* Copy */}
          <div className="reveal" style={{ animationDelay: "0ms" }}>
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1.5 text-xs font-mono uppercase tracking-[0.2em] text-primary">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
              </span>
              Live · Production v1.0
            </div>

            <h1 className="mt-6 text-5xl md:text-6xl lg:text-7xl font-semibold tracking-tight text-balance leading-[1.05]">
              Real-time fraud
              <br />
              defense,{" "}
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent neon-text">
                explained
              </span>
              .
            </h1>

            <p className="mt-6 max-w-xl text-base md:text-lg text-muted-foreground text-pretty leading-relaxed">
              FraudGuard AI fuses an XGBoost model, SHAP explainability, an LLM override layer
              and live Kafka streams into a single sub-second decision engine — with full
              transparency on every block.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <Link
                href="/dashboard"
                className="group inline-flex items-center gap-2 rounded-lg bg-gradient-to-br from-primary to-accent px-5 py-3 text-sm font-medium text-primary-foreground shadow-[0_0_32px_-4px_oklch(0.62_0.24_295/0.7)] transition hover:shadow-[0_0_48px_-2px_oklch(0.62_0.24_295/0.95)] hover:-translate-y-0.5"
              >
                <LayoutDashboard className="h-4 w-4" />
                Open Dashboard
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
              </Link>
              <Link
                href="/predict"
                className="inline-flex items-center gap-2 rounded-lg border border-border/60 bg-card/50 px-5 py-3 text-sm font-medium text-foreground hover:bg-card/80 hover:border-primary/40 transition"
              >
                <Brain className="h-4 w-4" />
                Try a Prediction
              </Link>
            </div>

            {/* Stat strip */}
            <dl className="mt-10 grid grid-cols-3 max-w-md gap-6">
              {[
                { k: "Latency", v: "<150ms" },
                { k: "Layers", v: "4-stage" },
                { k: "Languages", v: "EN·AR·EGY" },
              ].map((s) => (
                <div key={s.k}>
                  <dt className="text-[10px] font-mono uppercase tracking-[0.25em] text-muted-foreground">
                    {s.k}
                  </dt>
                  <dd className="mt-1 font-mono text-xl font-semibold">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>

          {/* Animated guest / shield */}
          <div className="reveal" style={{ animationDelay: "120ms" }}>
            <ShieldGuest />
          </div>
        </div>
      </section>

      {/* Feature grid */}
      <section className="mx-auto max-w-7xl px-4 md:px-6 pb-24">
        <div className="mb-10 reveal" style={{ animationDelay: "200ms" }}>
          <div className="text-[11px] font-mono uppercase tracking-[0.25em] text-primary">
            ▸ Pipeline
          </div>
          <h2 className="mt-2 text-3xl md:text-4xl font-semibold tracking-tight text-balance">
            One platform. Every fraud surface.
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {FEATURES.map((f, i) => (
            <div
              key={f.title}
              className="reveal"
              style={{ animationDelay: `${260 + i * 60}ms` }}
            >
              <Link
                href={f.href}
                className="group relative block h-full overflow-hidden rounded-xl glass p-6 transition hover:-translate-y-0.5 hover:border-primary/40"
              >
                <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent opacity-0 group-hover:opacity-100 transition" />
                <div className="grid h-11 w-11 place-items-center rounded-lg bg-primary/10 ring-1 ring-primary/30 text-primary group-hover:shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.7)] transition">
                  <f.Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                <div className="mt-5 inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-primary">
                  Open <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
                </div>
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

const FEATURES = [
  {
    title: "Live Dashboard",
    desc: "Real-time metrics, drift monitoring, anomaly detection and Kafka consumer status.",
    href: "/dashboard",
    Icon: LayoutDashboard,
  },
  {
    title: "Predict",
    desc: "Natural-language transaction analysis with SHAP-explained decisions in milliseconds.",
    href: "/predict",
    Icon: Brain,
  },
  {
    title: "Batch CSV",
    desc: "Upload thousands of transactions, auto-engineer features, and view FCM cluster scatter.",
    href: "/batch",
    Icon: FileSpreadsheet,
  },
  {
    title: "Kafka Stream",
    desc: "WebSocket-powered live feed of decisions as they flow through the consumer.",
    href: "/stream",
    Icon: Radio,
  },
  {
    title: "AI Assistant",
    desc: "Multilingual chatbot grounded in your last decision context. EN, AR, and EGY.",
    href: "/chat",
    Icon: MessageSquare,
  },
  {
    title: "Reports",
    desc: "Aggregate analytics, confidence distributions and uptime telemetry.",
    href: "/reports",
    Icon: BarChart3,
  },
] as const

/* ── Animated guest: orbiting shield with scanning ring ── */
function ShieldGuest() {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[480px]">
      {/* Outer ring with ticks */}
      <div className="absolute inset-0 rounded-full border border-primary/25 spin-slow">
        {Array.from({ length: 12 }).map((_, i) => (
          <span
            key={i}
            className="absolute left-1/2 top-0 h-2 w-px -translate-x-1/2 bg-primary/60"
            style={{
              transform: `rotate(${i * 30}deg) translateY(-1px)`,
              transformOrigin: "50% 240px",
            }}
          />
        ))}
      </div>

      {/* Middle ring */}
      <div className="absolute inset-[10%] rounded-full border border-accent/30 spin-rev" />

      {/* Inner dashed ring */}
      <div
        className="absolute inset-[22%] rounded-full spin-mid"
        style={{ border: "1px dashed oklch(0.62 0.24 295 / 0.5)" }}
      />

      {/* Glow halo */}
      <div className="absolute inset-[28%] rounded-full bg-primary/20 blur-3xl" />

      {/* Shield core */}
      <div className="absolute inset-[30%] grid place-items-center rounded-full bg-gradient-to-br from-primary via-primary to-accent shadow-[0_0_80px_-10px_oklch(0.62_0.24_295/0.9)] animate-float">
        <ShieldCheck className="h-20 w-20 text-primary-foreground" strokeWidth={2} />
        <span className="absolute inset-0 rounded-full ring-1 ring-white/15" />
      </div>

      {/* Scanning line */}
      <div className="absolute inset-[28%] overflow-hidden rounded-full">
        <div className="absolute inset-x-0 h-1/2 scanline animate-scan-y" />
      </div>

      {/* Floating chips */}
      <FloatingChip
        label="ALLOW"
        Icon={ShieldCheck}
        tone="emerald"
        style={{ left: "0%", top: "18%", animationDelay: "0s" }}
      />
      <FloatingChip
        label="SHAP"
        Icon={ScanLine}
        tone="violet"
        style={{ right: "-2%", top: "32%", animationDelay: "0.6s" }}
      />
      <FloatingChip
        label="<150ms"
        Icon={Zap}
        tone="amber"
        style={{ right: "8%", bottom: "10%", animationDelay: "1.2s" }}
      />
      <FloatingChip
        label="BLOCK"
        Icon={ShieldCheck}
        tone="red"
        style={{ left: "-2%", bottom: "20%", animationDelay: "1.8s" }}
      />
    </div>
  )
}

function FloatingChip({
  label,
  Icon,
  tone,
  style,
}: {
  label: string
  Icon: typeof ShieldCheck
  tone: "emerald" | "red" | "violet" | "amber"
  style: React.CSSProperties
}) {
  const palette: Record<typeof tone, string> = {
    emerald:
      "border-emerald-500/40 bg-emerald-500/10 text-emerald-300 shadow-[0_0_24px_-6px_oklch(0.70_0.18_150/0.6)]",
    red:
      "border-red-500/40 bg-red-500/10 text-red-300 shadow-[0_0_24px_-6px_oklch(0.62_0.24_22/0.6)]",
    violet:
      "border-primary/40 bg-primary/10 text-primary shadow-[0_0_24px_-6px_oklch(0.62_0.24_295/0.7)]",
    amber:
      "border-amber-500/40 bg-amber-500/10 text-amber-300 shadow-[0_0_24px_-6px_oklch(0.78_0.16_75/0.5)]",
  }
  return (
    <div
      style={style}
      className={`absolute inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-mono uppercase tracking-wider backdrop-blur-md animate-float-chip ${palette[tone]}`}
    >
      <Icon className="h-3.5 w-3.5" />
      {label}
    </div>
  )
}
