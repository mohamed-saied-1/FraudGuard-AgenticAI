"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { BarChart3, Database, Clock, TrendingUp, RefreshCw, Loader2 } from "lucide-react"
import { api } from "@/lib/api"
import type { ReportSummary, MetricsResponse } from "@/lib/types"
import { PageShell } from "@/components/page-shell"
import { MetricCard } from "@/components/metric-card"
import {
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts"
import { Skeleton } from "@/components/ui/skeleton"

const PALETTE = [
  "oklch(0.62 0.24 295)",
  "oklch(0.70 0.22 305)",
  "oklch(0.78 0.16 75)",
  "oklch(0.62 0.24 22)",
  "oklch(0.70 0.18 150)",
]

export default function ReportsPage() {
  const [data, setData] = useState<ReportSummary | null>(null)
  const [metrics, setMetrics] = useState<MetricsResponse | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const load = async () => {
    setRefreshing(true)
    try {
      const [s, m] = await Promise.all([api.reportsSummary(), api.metrics()])
      setData(s)
      setMetrics(m)
      setErr(null)
    } catch (e) {
      setErr((e as Error).message)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    let mounted = true
    const tick = async () => {
      try {
        const [s, m] = await Promise.all([api.reportsSummary(), api.metrics()])
        if (!mounted) return
        setData(s)
        setMetrics(m)
        setErr(null)
      } catch (e) {
        if (mounted) setErr((e as Error).message)
      } finally {
        if (mounted) setLoading(false)
      }
    }
    tick()
    const id = setInterval(tick, 10_000)
    return () => {
      mounted = false
      clearInterval(id)
    }
  }, [])

  const confidenceData = data
    ? Object.entries(data.confidence_dist).map(([k, v]) => ({ name: k, value: Number(v) }))
    : []

  return (
    <PageShell
      title="Reports & Analytics"
      subtitle="Aggregate analytics, confidence distribution and uptime telemetry from /reports/summary."
      badge="Reports"
      actions={
        <button
          type="button"
          onClick={load}
          disabled={refreshing}
          className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/50 px-3 py-2 text-xs font-medium text-muted-foreground hover:text-foreground transition disabled:opacity-50"
        >
          {refreshing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          Refresh
        </button>
      }
    >
      {err && (
        <div className="mb-6 rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-300">
          <strong>Backend offline:</strong> {err}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {loading && !data ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-[124px] rounded-xl" />)
        ) : data ? (
          <>
            <MetricCard
              label="Total Predictions"
              value={data.total.toLocaleString()}
              Icon={Database}
              tone="primary"
              delay={0}
            />
            <MetricCard
              label="Fraud Rate"
              value={`${data.fraud_rate_pct.toFixed(2)}%`}
              Icon={TrendingUp}
              tone="danger"
              delay={0.05}
            />
            <MetricCard
              label="Recent (last hour)"
              value={data.recent_count.toLocaleString()}
              Icon={BarChart3}
              tone="success"
              delay={0.1}
            />
            <MetricCard
              label="Uptime"
              value={`${data.uptime_hours.toFixed(1)}h`}
              Icon={Clock}
              tone="warning"
              delay={0.15}
            />
          </>
        ) : null}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-xl glass p-5"
        >
          <div className="mb-4">
            <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
              Confidence
            </div>
            <h3 className="text-base font-semibold">Distribution by band</h3>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={confidenceData} margin={{ left: 0, right: 12, top: 6, bottom: 6 }}>
                <CartesianGrid stroke="oklch(0.22 0.03 285 / 0.4)" strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fill: "oklch(0.85 0.01 280)", fontSize: 11, fontFamily: "var(--font-mono)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "oklch(0.65 0.025 280)", fontSize: 11, fontFamily: "var(--font-mono)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  cursor={{ fill: "oklch(0.62 0.24 295 / 0.08)" }}
                  contentStyle={{
                    background: "oklch(0.10 0.02 280 / 0.95)",
                    border: "1px solid oklch(0.62 0.24 295 / 0.4)",
                    borderRadius: 8,
                    fontFamily: "var(--font-mono)",
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {confidenceData.map((_, i) => (
                    <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="rounded-xl glass p-5"
        >
          <div className="mb-4">
            <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
              Decision Volume
            </div>
            <h3 className="text-base font-semibold">Allow · Review · Block</h3>
          </div>
          {metrics ? (
            <div className="grid grid-cols-3 gap-3">
              {[
                { name: "Allow", v: metrics.allows, tone: "emerald" as const },
                { name: "Review", v: metrics.reviews, tone: "amber" as const },
                { name: "Block", v: metrics.blocks, tone: "red" as const },
              ].map((d) => (
                <Tile key={d.name} {...d} total={metrics.total} />
              ))}
            </div>
          ) : (
            <Skeleton className="h-24" />
          )}

          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-lg border border-border/60 bg-background/40 p-3">
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                Velocity Blocks
              </div>
              <div className="mt-1 font-mono text-xl font-semibold tabular-nums">
                {metrics?.velocity_blocks ?? 0}
              </div>
            </div>
            <div className="rounded-lg border border-border/60 bg-background/40 p-3">
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                LLM Overrides
              </div>
              <div className="mt-1 font-mono text-xl font-semibold tabular-nums">
                {metrics?.llm_overrides ?? 0}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </PageShell>
  )
}

function Tile({
  name,
  v,
  total,
  tone,
}: {
  name: string
  v: number
  total: number
  tone: "emerald" | "amber" | "red"
}) {
  const pct = total > 0 ? (v / total) * 100 : 0
  const map = {
    emerald: "from-emerald-500/30 to-emerald-500/5 border-emerald-500/30 text-emerald-300",
    amber: "from-amber-500/30 to-amber-500/5 border-amber-500/30 text-amber-300",
    red: "from-red-500/30 to-red-500/5 border-red-500/30 text-red-300",
  }
  return (
    <div
      className={`rounded-lg border bg-gradient-to-b ${map[tone]} p-3`}
    >
      <div className="text-[11px] font-mono uppercase tracking-[0.2em] opacity-80">{name}</div>
      <div className="mt-1 font-mono text-2xl font-semibold tabular-nums">{v.toLocaleString()}</div>
      <div className="mt-1 text-[11px] font-mono opacity-70">{pct.toFixed(1)}%</div>
    </div>
  )
}
