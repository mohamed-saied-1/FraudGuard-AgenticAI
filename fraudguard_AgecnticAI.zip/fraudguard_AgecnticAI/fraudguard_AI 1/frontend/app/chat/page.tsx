"use client"

import { useEffect, useRef, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { Send, Loader2, RotateCcw, Sparkles, Bot, User as UserIcon, Globe, Hash } from "lucide-react"
import { api } from "@/lib/api"
import type { DecisionContext } from "@/lib/types"
import { PageShell } from "@/components/page-shell"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  language?: string
  ts: number
}

const SUGGESTIONS = [
  "Why was this decision made?",
  "Explain the SHAP drivers in plain English",
  "ما سبب رفض المعاملة؟",
  "هي العملية دي خطر ولا لأ؟",
  "What should I do next?",
]

const DEFAULT_CTX: DecisionContext = {
  decision: "N/A",
  total_risk: 0,
  explanation: "No prediction yet",
  row_id: null,
}

function loadCtx(): DecisionContext {
  if (typeof window === "undefined") return DEFAULT_CTX
  try {
    const raw = sessionStorage.getItem("fraudguard:last_prediction")
    if (!raw) return DEFAULT_CTX
    const p = JSON.parse(raw)
    return {
      decision        : p.decision        ?? "N/A",
      total_risk      : p.total_risk      ?? 0,
      explanation     : p.explanation     ?? "",
      row_id          : p.row_id          ?? null,
      probability     : p.probability     ?? 0,
      shap_score      : p.shap_score      ?? 0,
      forecast_risk   : p.forecast_risk   ?? 0,
      confidence_band : p.confidence_band ?? "low",
      path            : p.path            ?? "N/A",
      layers_used     : p.layers_used     ?? [],
      top_drivers     : p.top_drivers     ?? [],
      risk_components : p.risk_components ?? {},
      timestamp       : p.timestamp       ?? "",
      amount          : p.amount          ?? null,
      hour            : p.hour            ?? null,
      location        : p.location        ?? null,
    }
  } catch {
    return DEFAULT_CTX
  }
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "intro",
      role: "assistant",
      content:
        "Hi — I'm the FraudGuard assistant. I can explain the latest decision, walk you through SHAP drivers, and answer in English, Arabic or Egyptian dialect. Ask me anything.",
      ts: Date.now(),
      language: "en",
    },
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [ctx, setCtx] = useState<DecisionContext>(DEFAULT_CTX)
  const scrollRef = useRef<HTMLDivElement>(null)

  const router = useRouter()
  const searchParams = useSearchParams()
  const urlRowId = searchParams.get("row")   // e.g. "11" from /chat?row=11
  const [activeRowId, setActiveRowId] = useState<string | null>(urlRowId)

  useEffect(() => {
    const loaded = loadCtx()
    setCtx(loaded)
    
    // If URL has ?row=11, override context with that row's data
    if (urlRowId) {
      setActiveRowId(urlRowId)
      // Show a welcome message mentioning the row
      setMessages([{
        id: "intro-batch",
        role: "assistant",
        content: `I'm now looking at batch row #${urlRowId}. Ask me anything about this transaction — why it was ${loaded.decision?.replace("🚫","").replace("✅","").replace("⚠️","").trim() ?? "processed"}, what the risk factors were, or what you should do next.`,
        ts: Date.now(),
        language: "en",
      }])
    }
    
    const onStorage = () => setCtx(loadCtx())
    window.addEventListener("storage", onStorage)
    return () => window.removeEventListener("storage", onStorage)
  }, [urlRowId])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [messages, loading])

  const send = async (raw?: string) => {
    const text = (raw ?? input).trim()
    if (!text || loading) return
    setInput("")
    const userMsg: Message = {
      id: `u-${Date.now()}`,
      role: "user",
      content: text,
      ts: Date.now(),
    }
    setMessages((p) => [...p, userMsg])
    setLoading(true)
    try {
      // RULE 3: always include decision_context — fall back to default if no prediction
      const r = await api.chat(text, ctx, activeRowId ?? undefined)
      const aiMsg: Message = {
        id: `a-${Date.now()}`,
        role: "assistant",
        content: r.reply,
        language: r.language_detected,
        ts: Date.now(),
      }
      setMessages((p) => [...p, aiMsg])
    } catch (e) {
      const msg = (e as Error).message
      toast.error(msg)
      setMessages((p) => [
        ...p,
        {
          id: `err-${Date.now()}`,
          role: "assistant",
          content: `⚠️ Backend error: ${msg}`,
          ts: Date.now(),
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  const reset = async () => {
    try {
      await api.chatReset()
      toast.success("Conversation reset")
    } catch (e) {
      toast.error((e as Error).message)
    }
    setMessages([
      {
        id: "intro-2",
        role: "assistant",
        content: "Conversation reset. How can I help you next?",
        ts: Date.now(),
        language: "en",
      },
    ])
  }

  return (
    <PageShell
      title="AI Assistant"
      subtitle="Multilingual chatbot grounded in your last prediction. Decision context is always sent to the backend."
      badge="Chat"
      actions={
        <button
          type="button"
          onClick={reset}
          className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-card/50 px-3 py-2 text-xs font-medium text-muted-foreground hover:text-foreground transition"
        >
          <RotateCcw className="h-4 w-4" /> Reset
        </button>
      }
    >
      {/* Batch row indicator */}
      {activeRowId && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-primary/30 bg-primary/8 px-4 py-2.5 text-xs font-mono">
          <Hash className="h-3.5 w-3.5 text-primary" />
          <span className="text-muted-foreground">Viewing batch row</span>
          <span className="text-primary font-semibold">#{activeRowId}</span>
          <span className="text-muted-foreground">·</span>
          <span className={
            ctx.decision?.includes("BLOCK")  ? "text-red-300"     :
            ctx.decision?.includes("REVIEW") ? "text-amber-300"   : "text-emerald-300"
          }>
            {ctx.decision?.replace("🚫","").replace("✅","").replace("⚠️","").trim()}
          </span>
          <button
            onClick={() => { setActiveRowId(null); router.push("/chat") }}
            className="ml-auto text-muted-foreground hover:text-foreground transition text-[10px]"
          >
            ✕ clear
          </button>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        {/* Chat */}
        <div className="rounded-xl glass overflow-hidden flex flex-col h-[68vh]">
          <div ref={scrollRef} className="flex-1 overflow-auto no-scrollbar p-5 space-y-4">
            <AnimatePresence initial={false}>
              {messages.map((m) => (
                <motion.div
                  key={m.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className={cn(
                    "flex gap-3",
                    m.role === "user" ? "justify-end" : "justify-start",
                  )}
                >
                  {m.role === "assistant" && (
                    <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-primary to-accent shadow-[0_0_16px_-4px_oklch(0.62_0.24_295/0.7)]">
                      <Bot className="h-4 w-4 text-primary-foreground" />
                    </div>
                  )}
                  <div
                    className={cn(
                      "max-w-[78%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm",
                      m.role === "user"
                        ? "bg-primary/15 ring-1 ring-primary/40 text-foreground"
                        : "bg-card/70 ring-1 ring-border/60",
                    )}
                  >
                    <p
                      className={cn(
                        "whitespace-pre-wrap text-pretty",
                        (m.language === "ar" || m.language === "egy") && "text-right",
                      )}
                      dir={m.language === "ar" || m.language === "egy" ? "rtl" : "ltr"}
                    >
                      {m.content}
                    </p>
                    {m.language && m.role === "assistant" && (
                      <div className="mt-1.5 flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                        <Globe className="h-3 w-3" /> {m.language}
                      </div>
                    )}
                  </div>
                  {m.role === "user" && (
                    <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-border/60 bg-muted">
                      <UserIcon className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            {loading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3 justify-start"
              >
                <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-primary to-accent">
                  <Bot className="h-4 w-4 text-primary-foreground" />
                </div>
                <div className="rounded-2xl bg-card/70 ring-1 ring-border/60 px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    <Dot delay={0} />
                    <Dot delay={0.15} />
                    <Dot delay={0.3} />
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Input */}
          <div className="border-t border-border/50 p-3">
            <div className="flex gap-2 items-end">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    send()
                  }
                }}
                rows={1}
                placeholder="Ask about the latest decision…"
                className="flex-1 resize-none rounded-lg border border-border/60 bg-background/40 px-3 py-2.5 text-sm outline-none transition focus:border-primary/60 focus:shadow-[0_0_0_4px_oklch(0.62_0.24_295/0.15)] max-h-32"
              />
              <button
                type="button"
                onClick={() => send()}
                disabled={!input.trim() || loading}
                className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.6)] transition hover:shadow-[0_0_36px_-2px_oklch(0.62_0.24_295/0.9)] disabled:opacity-50"
                aria-label="Send"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </button>
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => send(s)}
                  className="rounded-full border border-border/60 bg-card/40 px-2.5 py-1 text-[11px] text-muted-foreground hover:text-foreground hover:border-primary/40 transition"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Context sidebar */}
        <div className="space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-xl glass p-5"
          >
            <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
              <Sparkles className="h-4 w-4 text-primary" /> Active Context
            </div>
            <div className="mt-3 space-y-2.5 text-sm">
              <Row label="Decision" value={ctx.decision} mono />
              <Row label="Total Risk" value={`${(ctx.total_risk * 100).toFixed(2)}%`} mono />
              <Row label="Row" value={String(ctx.row_id ?? "—")} mono />
            </div>
            <p className="mt-3 rounded-lg border border-border/60 bg-background/40 p-2.5 text-xs leading-relaxed text-muted-foreground">
              {ctx.explanation || "Run a /predict to populate context."}
            </p>
          </motion.div>

          <div className="rounded-xl glass p-5 text-xs text-muted-foreground leading-relaxed">
            <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-primary mb-1.5">
              Tips
            </div>
            Ask in <span className="font-mono">English</span>,{" "}
            <span className="font-mono">العربية</span>, or{" "}
            <span className="font-mono">العامية المصرية</span>. The assistant detects the
            language automatically.
          </div>
        </div>
      </div>
    </PageShell>
  )
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-border/60 bg-background/40 px-2.5 py-1.5">
      <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <span className={cn("text-sm", mono && "font-mono")}>{value}</span>
    </div>
  )
}

function Dot({ delay }: { delay: number }) {
  return (
    <motion.span
      className="h-1.5 w-1.5 rounded-full bg-primary"
      animate={{ opacity: [0.3, 1, 0.3], y: [0, -2, 0] }}
      transition={{ duration: 1.1, repeat: Infinity, delay }}
    />
  )
}