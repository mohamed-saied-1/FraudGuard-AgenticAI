"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Send, Loader2, Sparkles, MessageSquare, RotateCcw,
  Zap, Shield, TrendingUp, AlertTriangle, Brain, ChevronDown, ChevronUp,
  Globe, Swords, Clock, X,
} from "lucide-react"
import Link from "next/link"
import { api } from "@/lib/api"
import type { PredictResponse, AttackerIntentResponse } from "@/lib/types"
import { PageShell }    from "@/components/page-shell"
import { DecisionCard } from "@/components/decision-card"
import { ShapChart }    from "@/components/shap-chart"
import { RiskGauge }    from "@/components/risk-gauge"
import { toast }        from "sonner"
import { cn }           from "@/lib/utils"


// ── MFA Verification Modal ────────────────────────────────────────────────────

interface MfaModalProps {
  token     : string
  sentTo    : string
  expiresIn : number
  onVerified: (decision: string) => void
  onCancel  : () => void
}

function MfaModal({ token, sentTo, expiresIn, onVerified, onCancel }: MfaModalProps) {
  const [otp,          setOtp]          = useState("")
  const [submitting,   setSubmitting]   = useState(false)
  const [resending,    setResending]    = useState(false)
  const [error,        setError]        = useState<string | null>(null)
  const [success,      setSuccess]      = useState(false)
  const [timeLeft,     setTimeLeft]     = useState(expiresIn)
  const [attemptsLeft, setAttemptsLeft] = useState(3)

  useEffect(() => {
    if (timeLeft <= 0 || success) return
    const id = setInterval(() => setTimeLeft((t) => Math.max(0, t - 1)), 1000)
    return () => clearInterval(id)
  }, [timeLeft, success])

  const handleOtp = (v: string) => {
    setOtp(v.replace(/\D/g, "").slice(0, 6))
    setError(null)
  }

  const verify = async () => {
    if (otp.length !== 6 || submitting) return
    setSubmitting(true)
    setError(null)
    try {
      const r = await api.mfaVerify(token, otp)
      if (["verified", "SUCCESS", "ALREADY_VERIFIED"].some((s) =>
        r.status === s || r.code === s)) {
        setSuccess(true)
        toast.success("Identity verified — transaction approved!")
        setTimeout(() => onVerified(r.original_decision ?? "ALLOW ✅"), 1500)
      } else {
        const msg = typeof r.detail === "object"
          ? (r.detail as any)?.detail ?? "Verification failed"
          : r.message ?? String(r.detail ?? "Verification failed")
        setError(msg)
        if (r.attempts_remaining !== undefined) setAttemptsLeft(r.attempts_remaining)
      }
    } catch (e: any) {
      const detail = e?.detail
      if (typeof detail === "object" && detail !== null) {
        setError(detail.detail ?? "Verification failed")
        if (detail.attempts_remaining !== undefined) setAttemptsLeft(detail.attempts_remaining)
      } else {
        setError(String(detail ?? (e as Error).message))
      }
    } finally {
      setSubmitting(false)
    }
  }

  const resend = async () => {
    setResending(true)
    setError(null)
    try {
      const r = await api.mfaResend(token)
      setTimeLeft(r.expires_in ?? 300)
      setOtp("")
      toast.success(`New OTP sent to ${r.otp_sent_to}`)
    } catch (e) {
      toast.error("Resend failed — " + (e as Error).message)
    } finally {
      setResending(false)
    }
  }

  const cancel = async () => {
    try { await api.mfaCancel(token) } catch {}
    onCancel()
  }

  const mins    = Math.floor(timeLeft / 60)
  const secs    = timeLeft % 60
  const expired = timeLeft <= 0

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92 }}
        className="w-full max-w-sm rounded-2xl border border-primary/30 bg-card/98 backdrop-blur p-6 shadow-2xl mx-4"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-primary/60 to-accent/60 text-xl">
              🔐
            </div>
            <div>
              <h3 className="font-semibold text-sm">Identity Verification</h3>
              <p className="text-[10px] font-mono text-muted-foreground">
                {sentTo && sentTo !== "none" ? `OTP sent to ${sentTo}` : "Check your registered email"}
              </p>
            </div>
          </div>
          <button onClick={cancel}
            className="grid h-7 w-7 place-items-center rounded-md border border-border/50 text-muted-foreground hover:text-foreground transition">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>

        {success ? (
          <div className="py-6 text-center space-y-3">
            <div className="text-5xl">✅</div>
            <p className="font-semibold text-emerald-300">Transaction Approved!</p>
            <p className="text-xs font-mono text-muted-foreground">Identity successfully verified</p>
          </div>
        ) : (
          <>
            {/* Timer */}
            <div className={cn(
              "mb-4 rounded-lg border px-3 py-2 text-center font-mono",
              expired       ? "border-red-500/40 bg-red-500/10 text-red-300"     :
              timeLeft < 60 ? "border-amber-500/40 bg-amber-500/10 text-amber-300" :
                              "border-border/50 bg-background/40 text-muted-foreground",
            )}>
              <div className="text-[9px] uppercase tracking-wider mb-0.5">
                {expired ? "Code Expired — Resend to continue" : "Code expires in"}
              </div>
              {!expired && (
                <div className="font-semibold text-lg tabular-nums">
                  {String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}
                </div>
              )}
            </div>

            {/* OTP Input */}
            <div className="mb-4">
              <label className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                Enter 6-Digit Code
              </label>
              <input
                type="text"
                inputMode="numeric"
                value={otp}
                onChange={(e) => handleOtp(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") verify() }}
                placeholder="_ _ _ _ _ _"
                disabled={expired || submitting}
                className="mt-1.5 w-full rounded-lg border border-border/60 bg-background/40 px-3 py-3 text-center font-mono text-2xl tracking-[0.6em] outline-none transition focus:border-primary/60 focus:shadow-[0_0_0_4px_oklch(0.62_0.24_295/0.15)] disabled:opacity-50"
              />
              {attemptsLeft < 3 && !error && (
                <p className="mt-1 text-[10px] font-mono text-amber-400">
                  ⚠ {attemptsLeft} attempt{attemptsLeft !== 1 ? "s" : ""} remaining
                </p>
              )}
            </div>

            {/* Error */}
            {error && (
              <div className="mb-4 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs font-mono text-red-300">
                {error}
              </div>
            )}

            {/* Verify button */}
            <button
              type="button"
              onClick={verify}
              disabled={otp.length !== 6 || submitting || expired}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-gradient-to-br from-primary to-accent px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.6)] transition disabled:opacity-50"
            >
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              {submitting ? "Verifying…" : "Verify Identity"}
            </button>

            {/* Resend + Cancel */}
            <div className="mt-3 flex items-center justify-between">
              <button
                type="button"
                onClick={resend}
                disabled={resending || submitting}
                className="inline-flex items-center gap-1 text-[11px] font-mono text-primary/70 hover:text-primary transition disabled:opacity-50"
              >
                {resending && <Loader2 className="h-3 w-3 animate-spin" />}
                Resend OTP
              </button>
              <button
                type="button"
                onClick={cancel}
                className="text-[11px] font-mono text-muted-foreground hover:text-foreground transition"
              >
                Cancel Transaction
              </button>
            </div>

            <p className="mt-3 text-center text-[9px] font-mono text-muted-foreground/40">
              Never share this code · FraudGuard will never ask for it by phone or chat
            </p>
          </>
        )}
      </motion.div>
    </motion.div>
  )
}


const SAMPLES = [
  "Customer just made 3 transactions of $4,500 each in the last 5 minutes from different locations",
  "Card was used for $9.99 subscription renewal at recurring merchant",
  "Wire transfer of $50,000 to new beneficiary in foreign country at 3:14 AM",
  "ATM withdrawal of $200 at usual location during morning commute",
]

// ── Attacker Intent Panel ★ NEW ───────────────────────────────────────────────

function AttackerIntentPanel({ intent }: { intent: AttackerIntentResponse }) {
  const wm = intent.world_model
  const hasIntent = intent.attacker_intent !== "normal transaction pattern"

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15 }}
      className={cn(
        "rounded-xl glass overflow-hidden",
        hasIntent ? "ring-1 ring-amber-500/30" : "",
      )}
    >
      <div className="flex items-center justify-between px-5 py-4 border-b border-border/30">
        <div className="flex items-center gap-3">
          <div className={cn(
            "grid h-8 w-8 place-items-center rounded-lg",
            hasIntent
              ? "bg-gradient-to-br from-amber-500/40 to-red-500/40"
              : "bg-gradient-to-br from-primary/40 to-accent/40",
          )}>
            <Globe className="h-4 w-4 text-white/80" />
          </div>
          <div>
            <div className="text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">
              World Model · Feature 2
            </div>
            <div className="text-sm font-semibold">Attacker Intent Analysis</div>
          </div>
        </div>
        {hasIntent && (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-[10px] font-mono text-amber-300 uppercase">
            <AlertTriangle className="h-3 w-3" /> Threat Detected
          </span>
        )}
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Intent string */}
        <div className={cn(
          "rounded-lg border px-4 py-3",
          hasIntent
            ? "border-amber-500/30 bg-amber-500/8"
            : "border-emerald-500/30 bg-emerald-500/8",
        )}>
          <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">
            Predicted Intent
          </div>
          <p className={cn(
            "text-sm font-mono leading-relaxed",
            hasIntent ? "text-amber-200" : "text-emerald-300",
          )}>
            {intent.attacker_intent}
          </p>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <InfoCell k="Hour Risk"    v={`${(intent.hour_risk * 100).toFixed(3)}%`}
            highlight={intent.hour_risk > 0.03 ? "danger" : undefined} />
          <InfoCell k="Peak Hour"   v={`${wm.peak_fraud_hour}:00`} />
          <InfoCell k="Campaigns"   v={String(wm.active_campaigns)}
            highlight={wm.active_campaigns > 0 ? "danger" : undefined} />
          <InfoCell k="Patterns"    v={String(wm.known_patterns)} />
        </div>

        {/* Top causal features */}
        {wm.top_causal_features.length > 0 && (
          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1.5">
              Top Exploited Features (World Model)
            </div>
            <div className="flex flex-wrap gap-1.5">
              {wm.top_causal_features.map((feat, i) => (
                <span key={feat}
                  className={cn(
                    "rounded border px-2 py-0.5 text-[10px] font-mono",
                    i === 0
                      ? "border-red-500/40 bg-red-500/10 text-red-300"
                      : "border-border/40 bg-background/30 text-muted-foreground",
                  )}>
                  {feat}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Fraud rate */}
        <div className="flex items-center justify-between rounded-lg border border-border/40 bg-background/30 px-3 py-2.5">
          <div className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground">
            <Swords className="h-3.5 w-3.5 text-primary" />
            World fraud rate: <span className="text-foreground font-semibold ml-1">
              {(wm.fraud_rate * 100).toFixed(2)}%
            </span>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground">
            <Clock className="h-3.5 w-3.5 text-primary" />
            {wm.total_seen.toLocaleString()} transactions seen
          </div>
        </div>
      </div>
    </motion.div>
  )
}

// ── Predictive Action Panel ───────────────────────────────────────────────────

function PredictiveActionPanel({ result }: { result: PredictResponse }) {
  const [expanded, setExpanded] = useState(false)
  const ag = result.agentic
  if (!ag) return null

  const intensityColor =
    ag.action_intensity === "high"   ? "text-red-300 border-red-500/40 bg-red-500/10"     :
    ag.action_intensity === "medium" ? "text-amber-300 border-amber-500/40 bg-amber-500/10":
    ag.action_intensity === "low"    ? "text-blue-300 border-blue-500/40 bg-blue-500/10"   :
    "text-muted-foreground border-border/40 bg-background/30"

  const actionIcon =
    ag.preemptive_action === "escalate_now"  ? <AlertTriangle className="h-4 w-4" /> :
    ag.preemptive_action === "monitor_close" ? <Shield        className="h-4 w-4" /> :
    ag.preemptive_action === "soft_flag"     ? <TrendingUp    className="h-4 w-4" /> :
    <Sparkles className="h-4 w-4" />

  const detScore = ag.deterioration_score ?? 0

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="rounded-xl glass overflow-hidden"
    >
      <button type="button" onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-white/[0.02] transition">
        <div className="flex items-center gap-3">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-primary/60 to-accent/60">
            <Brain className="h-4 w-4 text-primary-foreground" />
          </div>
          <div className="text-left">
            <div className="text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">
              Predictive Action Layer · Agent ReAct
            </div>
            <div className="text-sm font-semibold">
              {ag.preemptive_action === "none"         ? "No pre-emptive action needed" :
               ag.preemptive_action === "soft_flag"     ? "Soft flag — monitor this case" :
               ag.preemptive_action === "monitor_close" ? "Close monitoring — risk rising" :
               "⚠ Escalate now — deterioration detected"}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className={cn(
            "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-mono uppercase",
            intensityColor,
          )}>
            {actionIcon} {ag.action_intensity}
          </span>
          {expanded
            ? <ChevronUp className="h-4 w-4 text-muted-foreground" />
            : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-1 space-y-4 border-t border-border/30">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
                    Deterioration Score
                  </span>
                  <span className={cn("font-mono text-sm font-semibold",
                    detScore > 0.7 ? "text-red-300" :
                    detScore > 0.4 ? "text-amber-300" : "text-emerald-300")}>
                    {(detScore * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-2 w-full rounded-full bg-white/5 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${detScore * 100}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={cn("h-full rounded-full",
                      detScore > 0.7 ? "bg-red-500" :
                      detScore > 0.4 ? "bg-amber-500" : "bg-emerald-500")}
                  />
                </div>
                <p className="mt-1.5 text-[10px] font-mono text-muted-foreground">
                  {ag.action_justification}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <InfoCell k="Action"      v={ag.preemptive_action.replace(/_/g, " ")} />
                <InfoCell k="Timing"      v={ag.action_timing.replace(/_/g, " ")} />
                <InfoCell k="Dyn. Weight" v={ag.dynamic_weight?.toFixed(2) ?? "—"} />
                <InfoCell k="Reflection"  v={ag.reflection_quality}
                  highlight={
                    ag.reflection_quality === "good" ? "good" :
                    ag.reflection_quality === "risky" ? "danger" : "warn"
                  } />
              </div>

              {ag.reasoning_chain && ag.reasoning_chain.length > 0 && (
                <div>
                  <div className="mb-1.5 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
                    Chain-of-Thought Reasoning
                  </div>
                  <ol className="space-y-1">
                    {ag.reasoning_chain.map((step, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs font-mono">
                        <span className="mt-0.5 shrink-0 h-4 w-4 rounded-sm border border-primary/30 bg-primary/10 text-primary grid place-items-center text-[9px]">
                          {i + 1}
                        </span>
                        <span className="text-muted-foreground">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              )}

              {ag.weight_justification && (
                <div className="rounded-lg border border-border/50 bg-background/30 px-3 py-2.5">
                  <div className="mb-1 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                    Dynamic Weight Audit Trail
                  </div>
                  <p className="text-[11px] font-mono text-primary/70 leading-relaxed">
                    {ag.weight_justification}
                  </p>
                </div>
              )}

              {ag.six_agentic_properties && (
                <div>
                  <div className="mb-1.5 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
                    6 Agentic Properties · This Decision
                  </div>
                  <div className="grid grid-cols-3 gap-1.5">
                    {Object.entries(ag.six_agentic_properties).map(([k, v]) => (
                      <div key={k} className={cn(
                        "rounded border px-2 py-1.5 text-[9px] font-mono text-center",
                        v ? "border-emerald-500/30 bg-emerald-500/8 text-emerald-300"
                          : "border-border/30 bg-background/20 text-muted-foreground/50",
                      )}>
                        {k.replace(/^\d_/, "").replace(/_/g, " ")}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between text-[10px] font-mono text-muted-foreground/60">
                <span>ReAct loop: {ag.react_loop}</span>
                <span>Agent latency: {ag.agent_latency_ms?.toFixed(1) ?? "—"}ms</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

function InfoCell({ k, v, highlight }: { k: string; v: string; highlight?: "good" | "danger" | "warn" }) {
  const color =
    highlight === "good"   ? "text-emerald-300" :
    highlight === "danger" ? "text-red-300"     :
    highlight === "warn"   ? "text-amber-300"   : ""
  return (
    <div className="rounded-lg border border-border/50 bg-background/30 px-2.5 py-2 text-center">
      <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className={cn("mt-0.5 font-mono text-xs font-semibold capitalize", color)}>{v || "—"}</div>
    </div>
  )
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ════════════════════════════════════════════════════════════════════════════

export default function PredictPage() {
  const [text,          setText]         = useState("")
  const [loading,       setLoading]      = useState(false)
  const [result,        setResult]       = useState<PredictResponse | null>(null)
  const [attackerIntent,setAttackerIntent]= useState<AttackerIntentResponse | null>(null)
  const [intentLoading, setIntentLoading]= useState(false)
  const [err,           setErr]          = useState<string | null>(null)
  const [mfaToken,      setMfaToken]     = useState<string | null>(null)
  const [mfaSentTo,     setMfaSentTo]    = useState("")
  const [mfaExpiresIn,  setMfaExpiresIn] = useState(300)

  const persist = (r: PredictResponse) => {
    try {
      sessionStorage.setItem(
        "fraudguard:last_prediction",
        JSON.stringify({
          decision        : r.decision,
          total_risk      : r.total_risk,
          explanation     : r.explanation,
          row_id          : r.row_id ?? r.structured?.amount?.toString() ?? "predict",
          probability     : r.probability,
          shap_score      : r.shap_score,
          forecast_risk   : r.forecast_risk,
          confidence_band : r.confidence_band,
          path            : r.path,
          layers_used     : r.layers_used,
          top_drivers     : r.top_drivers,
          risk_components : r.risk_components,
          timestamp       : r.timestamp,
          amount          : r.structured?.amount ?? null,
          hour            : r.structured?.hour   ?? null,
          location        : r.structured?.location ?? null,
        }),
      )
    } catch { /* ignore */ }
  }

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault()
    if (!text.trim() || loading) return
    setLoading(true)
    setErr(null)
    setAttackerIntent(null)
    try {
      const r = await api.textPredict(text.trim())
      setResult(r)
      persist(r)
      toast.success(`Decision: ${r.decision}`)

      // ── MFA triggered ──
      if (r.mfa_required && r.mfa?.token) {
        setMfaToken(r.mfa.token)
        setMfaSentTo(r.mfa.otp_sent_to ?? "")
        setMfaExpiresIn(r.mfa.expires_in ?? 300)
      }
      // ★ Fire attacker intent in parallel (non-blocking)
      if (r.structured?.amount !== null && r.structured?.amount !== undefined) {
        setIntentLoading(true)
        api.agentAttackerIntent({
          amount: r.structured.amount,
          time  : (r.structured.hour ?? 0) * 3600,
        })
          .then((intent) => setAttackerIntent(intent))
          .catch(() => {/* silent */})
          .finally(() => setIntentLoading(false))
      }
    } catch (e) {
      const msg = (e as Error).message
      setErr(msg)
      toast.error(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <PageShell
      title="Single Prediction"
      subtitle="Describe a transaction in natural language. The model returns a decision, SHAP drivers, ReAct reasoning, and World Model attacker intent."
      badge="Predict"
      actions={
        result && (
          <Link href="/chat"
            className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-3 py-2 text-xs font-medium text-primary hover:bg-primary/20 transition">
            <MessageSquare className="h-4 w-4" /> Ask Assistant
          </Link>
        )
      }
    >
      {/* MFA Modal */}
      <AnimatePresence>
        {mfaToken && (
          <MfaModal
            token={mfaToken}
            sentTo={mfaSentTo}
            expiresIn={mfaExpiresIn}
            onVerified={(decision) => {
              setMfaToken(null)
              setResult((prev) => prev ? { ...prev, decision } : prev)
            }}
            onCancel={() => setMfaToken(null)}
          />
        )}
      </AnimatePresence>
      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <motion.form onSubmit={submit}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl glass p-5">
          <label htmlFor="tx" className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
            Transaction Description
          </label>
          <textarea id="tx" value={text} onChange={(e) => setText(e.target.value)}
            rows={5} disabled={loading}
            placeholder="Describe the transaction… e.g., 'Card-not-present $2,400 at midnight from new device.'"
            className="mt-2 w-full resize-none rounded-lg border border-border/60 bg-background/40 px-4 py-3 text-sm font-mono outline-none transition focus:border-primary/60 focus:shadow-[0_0_0_4px_oklch(0.62_0.24_295/0.15)]" />
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-1.5">
              {SAMPLES.map((s, i) => (
                <button key={i} type="button" onClick={() => setText(s)}
                  className="rounded-full border border-border/60 bg-card/50 px-2.5 py-1 text-[11px] text-muted-foreground hover:text-foreground hover:border-primary/40 transition">
                  Sample {i + 1}
                </button>
              ))}
              <button type="button"
                onClick={() => { setText(""); setResult(null); setErr(null); setAttackerIntent(null) }}
                className="inline-flex items-center gap-1 rounded-full border border-border/60 bg-card/50 px-2.5 py-1 text-[11px] text-muted-foreground hover:text-foreground transition">
                <RotateCcw className="h-3 w-3" /> Clear
              </button>
            </div>
            <button type="submit" disabled={loading || !text.trim()}
              className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-br from-primary to-accent px-4 py-2 text-sm font-medium text-primary-foreground shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.6)] transition hover:shadow-[0_0_36px_-2px_oklch(0.62_0.24_295/0.9)] disabled:opacity-50">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              Analyze
            </button>
          </div>
          {err && (
            <div className="mt-3 rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-xs text-red-300">
              {err}
            </div>
          )}
        </motion.form>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="rounded-xl glass p-5 flex flex-col items-center justify-center">
          <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-1">
            Live Risk
          </div>
          <RiskGauge value={result ? result.total_risk : 0} label="Total Risk" size={200} />
          {result && (
            <div className="mt-3 grid grid-cols-2 gap-2 w-full">
              <Mini k="Model"    v={result.risk_components.model.toFixed(3)} />
              <Mini k="SHAP"     v={result.risk_components.shap.toFixed(3)} />
              <Mini k="Forecast" v={result.risk_components.forecast.toFixed(3)} />
              <Mini k="LLM"      v={result.risk_components.llm_score.toFixed(3)} />
            </div>
          )}
          {result?.agentic && (
            <div className="mt-3 w-full rounded-lg border border-primary/20 bg-primary/5 px-3 py-2">
              <div className="flex items-center justify-between text-[10px] font-mono">
                <span className="text-muted-foreground uppercase tracking-wider">Deterioration</span>
                <span className={cn("font-semibold",
                  (result.agentic.deterioration_score ?? 0) > 0.6 ? "text-red-300" :
                  (result.agentic.deterioration_score ?? 0) > 0.3 ? "text-amber-300" : "text-emerald-300")}>
                  {((result.agentic.deterioration_score ?? 0) * 100).toFixed(1)}%
                </span>
              </div>
              <div className="mt-1 h-1 w-full rounded-full bg-white/5 overflow-hidden">
                <div className={cn("h-full rounded-full transition-all",
                  (result.agentic.deterioration_score ?? 0) > 0.6 ? "bg-red-500" :
                  (result.agentic.deterioration_score ?? 0) > 0.3 ? "bg-amber-500" : "bg-emerald-500")}
                  style={{ width: `${(result.agentic.deterioration_score ?? 0) * 100}%` }} />
              </div>
              <div className="mt-1 text-[9px] font-mono text-primary/60">
                {result.agentic.preemptive_action.replace(/_/g, " ")}
              </div>
            </div>
          )}
        </motion.div>
      </div>

      <AnimatePresence>
        {result && (
          <motion.div key="result" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }} className="mt-5 space-y-4">

            <div className="grid gap-4 lg:grid-cols-2">
              <DecisionCard result={result} />
              <ShapChart drivers={result.top_drivers} explanation={result.explanation} />
            </div>

            <PredictiveActionPanel result={result} />

            {/* ★ NEW: Attacker Intent Panel */}
            {intentLoading && (
              <div className="rounded-xl glass p-4 flex items-center gap-3 text-xs font-mono text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
                World model analyzing attacker intent…
              </div>
            )}
            {attackerIntent && !intentLoading && (
              <AttackerIntentPanel intent={attackerIntent} />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {!result && !loading && (
        <div className="mt-6 rounded-xl border border-dashed border-border/60 p-10 text-center">
          <Sparkles className="mx-auto h-8 w-8 text-primary/60" />
          <p className="mt-3 text-sm text-muted-foreground">
            Submit a description to see decision, SHAP drivers, ReAct reasoning, and attacker intent.
          </p>
        </div>
      )}
    </PageShell>
  )
}

function Mini({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-md border border-border/60 bg-background/40 p-2 text-center">
      <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className="font-mono text-sm tabular-nums">{v}</div>
    </div>
  )
}