"use client"

import { useRef, useState, useEffect, useCallback, useRef as _useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  UploadCloud, FileSpreadsheet, Mail, Loader2,
  AlertTriangle, Trash2, MessageSquare, ThumbsUp, ThumbsDown, X,
  Brain, TrendingUp, Clock, MapPin, ShieldCheck,
} from "lucide-react"
import { api } from "@/lib/api"
import type { BatchResponse, UserMemoryProfile, FcmResponse } from "@/lib/types"
import { PageShell }    from "@/components/page-shell"
import { decisionTone } from "@/lib/constants"
import { cn }           from "@/lib/utils"
import { toast }        from "sonner"
import { useRouter }    from "next/navigation"
import {
  ScatterChart, Scatter, XAxis, YAxis, ZAxis,
  Tooltip as RTooltip, ResponsiveContainer, Cell,
} from "recharts"

// ── Human Feedback Modal ─────────────────────────────────────────────────────

interface FeedbackModalProps {
  cardId   : string
  decision : string
  onClose  : () => void
}

function FeedbackModal({ cardId, decision, onClose }: FeedbackModalProps) {
  const [submitting, setSubmitting] = useState(false)
  const [notes,      setNotes]      = useState("")

  const submit = async (wasFraud: boolean) => {
    setSubmitting(true)
    try {
      const r = await api.agentFeedback(cardId, wasFraud, notes || undefined)
      toast.success(
        `Agent learned · precision: ${(r.updated_precision * 100).toFixed(1)}%` +
        (r.adaptation_triggered ? " · adaptation triggered" : ""),
      )
      onClose()
    } catch {
      toast.error("Feedback failed — backend unreachable")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-2xl border border-border/60 bg-card/95 backdrop-blur p-6 shadow-2xl mx-4"
      >
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="font-semibold">Human-in-the-Loop Feedback</h3>
            <p className="mt-0.5 text-xs text-muted-foreground font-mono">
              card: {cardId} · decision: {decision.replace(/[🚫✅⚠️🔐]/g, "").trim()}
            </p>
          </div>
          <button onClick={onClose}
            className="grid h-7 w-7 place-items-center rounded-md border border-border/50 text-muted-foreground hover:text-foreground transition">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
        <p className="mb-4 rounded-lg border border-border/50 bg-background/40 p-3 text-xs leading-relaxed text-muted-foreground">
          Was this transaction <strong className="text-foreground">actually fraudulent</strong>?
          The agent will update its memory and adjust future decisions.
        </p>
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)}
          placeholder="Optional notes (e.g. 'customer confirmed it was them')"
          rows={2}
          className="mb-4 w-full resize-none rounded-lg border border-border/60 bg-background/40 px-3 py-2 text-xs font-mono outline-none transition focus:border-primary/60" />
        <div className="grid grid-cols-2 gap-3">
          <button type="button" disabled={submitting} onClick={() => submit(true)}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-2.5 text-sm font-medium text-red-300 hover:bg-red-500/20 transition disabled:opacity-50">
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <ThumbsDown className="h-4 w-4" />}
            Yes, Fraud
          </button>
          <button type="button" disabled={submitting} onClick={() => submit(false)}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-sm font-medium text-emerald-300 hover:bg-emerald-500/20 transition disabled:opacity-50">
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <ThumbsUp className="h-4 w-4" />}
            Legitimate
          </button>
        </div>
        <p className="mt-3 text-center text-[10px] font-mono text-muted-foreground/50">
          Agent will update episodic memory + recalculate precision
        </p>
      </motion.div>
    </motion.div>
  )
}

// ── User Memory Modal ─────────────────────────────────────────────────────────

interface MemoryModalProps {
  cardId  : string
  onClose : () => void
}

function MemoryModal({ cardId, onClose }: MemoryModalProps) {
  const [loading, setLoading] = useState(true)
  const [memory,  setMemory]  = useState<UserMemoryProfile | null>(null)
  const [error,   setError]   = useState<string | null>(null)

  useEffect(() => {
    api.agentUserMemory(cardId)
      .then((r) => setMemory(r.agent_memory))
      .catch((e) => {
        const err = e as { status?: number }
        if (err.status === 404) {
          setError("No memory yet — this card hasn't been seen before. Make a prediction first.")
        } else {
          setError((e as Error).message)
        }
      })
      .finally(() => setLoading(false))
  }, [cardId])

  const topHour  = memory
    ? Object.entries(memory.usual_hours).sort((a, b) => b[1] - a[1])[0]?.[0]
    : null
  const riskTrend = memory?.risk_trend ?? []
  const trendUp   = riskTrend.length >= 2
    ? riskTrend[riskTrend.length - 1] > riskTrend[riskTrend.length - 2]
    : false

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl border border-border/60 bg-card/95 backdrop-blur p-6 shadow-2xl mx-4"
      >
        <div className="flex items-start justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-primary/60 to-accent/60">
              <Brain className="h-4 w-4 text-white" />
            </div>
            <div>
              <h3 className="font-semibold">Agent Memory Profile</h3>
              <p className="text-xs text-muted-foreground font-mono">{cardId}</p>
            </div>
          </div>
          <button onClick={onClose}
            className="grid h-7 w-7 place-items-center rounded-md border border-border/50 text-muted-foreground hover:text-foreground transition">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>

        {loading && (
          <div className="flex h-32 items-center justify-center gap-2 text-sm text-muted-foreground font-mono">
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
            Loading memory…
          </div>
        )}

        {error && (
          <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-xs text-red-300 font-mono">
            {error}
          </div>
        )}

        {memory && !loading && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              <MemStat k="Total Txns"   v={String(memory.total_txns)} />
              <MemStat k="Fraud Count"  v={String(memory.fraud_count)} danger={memory.fraud_count > 0} />
              <MemStat k="MFA Triggers" v={String(memory.mfa_count)} />
            </div>

            <div className="rounded-lg border border-border/50 bg-background/40 px-4 py-3">
              <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">
                Average Transaction Amount
              </div>
              <div className="font-mono text-xl font-semibold">
                ${memory.avg_amount.toLocaleString(undefined, {
                  minimumFractionDigits: 2, maximumFractionDigits: 2,
                })}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-border/50 bg-background/40 px-3 py-2.5">
                <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">
                  <Clock className="h-3 w-3" /> Peak Hour
                </div>
                <div className="font-mono text-sm font-semibold">
                  {topHour !== null ? `${topHour}:00` : "—"}
                </div>
              </div>
              <div className="rounded-lg border border-border/50 bg-background/40 px-3 py-2.5">
                <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">
                  <MapPin className="h-3 w-3" /> Usual Locations
                </div>
                <div className="text-[11px] font-mono text-muted-foreground">
                  {memory.usual_locations.slice(0, 2).join(", ") || "—"}
                </div>
              </div>
            </div>

            {riskTrend.length > 1 && (
              <div className="rounded-lg border border-border/50 bg-background/40 px-4 py-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                    Risk Trend (last {riskTrend.length} transactions)
                  </div>
                  <span className={cn(
                    "text-[10px] font-mono font-semibold flex items-center gap-1",
                    trendUp ? "text-red-300" : "text-emerald-300",
                  )}>
                    <TrendingUp className={cn("h-3 w-3", !trendUp && "rotate-180")} />
                    {trendUp ? "Rising" : "Declining"}
                  </span>
                </div>
                <div className="flex items-end gap-0.5 h-10">
                  {riskTrend.map((v, i) => (
                    <div key={i} className="flex-1 rounded-sm"
                      style={{
                        height: `${Math.max(4, v * 100)}%`,
                        background: v > 0.6
                          ? "oklch(0.62 0.24 22 / 0.8)"
                          : v > 0.3
                          ? "oklch(0.78 0.16 75 / 0.8)"
                          : "oklch(0.70 0.18 150 / 0.8)",
                      }}
                    />
                  ))}
                </div>
              </div>
            )}

            {memory.last_seen && (
              <p className="text-[10px] font-mono text-muted-foreground/60 text-center">
                Last seen: {new Date(memory.last_seen).toLocaleString()}
              </p>
            )}
          </div>
        )}
      </motion.div>
    </motion.div>
  )
}

function MemStat({ k, v, danger }: { k: string; v: string; danger?: boolean }) {
  return (
    <div className={cn(
      "rounded-lg border px-2.5 py-2 text-center",
      danger ? "border-red-500/40 bg-red-500/10" : "border-border/50 bg-background/40",
    )}>
      <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className={cn("mt-0.5 font-mono text-sm font-semibold", danger && "text-red-300")}>{v}</div>
    </div>
  )
}

// ── FCM Cluster Colors ───────────────────────────────────────────────────────
const FCM_COLORS  = ["#7c3aed", "#ef4444", "#22c55e"] as const
const FCM_LABELS  = ["Cluster A", "Cluster B", "Cluster C"] as const

// ════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ════════════════════════════════════════════════════════════════════════════

export default function BatchPage() {
  const [file,       setFile]       = useState<File | null>(null)
  const [drag,       setDrag]       = useState(false)
  const [loading,    setLoading]    = useState(false)
  const [result,     setResult]     = useState<BatchResponse | null>(null)
  const [err,        setErr]        = useState<string | null>(null)
  const [emailing,   setEmailing]   = useState(false)
  const [email,      setEmail]      = useState("")
  const [fcm,        setFcm]        = useState<FcmResponse | null>(null)
  const [fcmLoading, setFcmLoading] = useState(false)

  const [feedbackTarget, setFeedbackTarget] = useState<{ cardId: string; decision: string } | null>(null)
  const [memoryTarget,   setMemoryTarget]   = useState<string | null>(null)
  // ── MFA state ─────────────────────────────────────────────────────────────
  const [mfaState, setMfaState] = useState<{
    token     : string
    cardId    : string
    rowId     : number
    sentTo    : string
    expiresIn : number
  } | null>(null)
  const [mfaOtp,     setMfaOtp]     = useState("")
  const [mfaBusy,    setMfaBusy]    = useState(false)
  const [mfaErr,     setMfaErr]     = useState<string | null>(null)
  const [mfaSuccess, setMfaSuccess] = useState(false)
  const [mfaTimeLeft, setMfaTimeLeft] = useState(300)

  const router   = useRouter()
  const inputRef = useRef<HTMLInputElement>(null)


  // ── MFA countdown ──────────────────────────────────────────────────────────
  useEffect(() => {
    if (!mfaState || mfaSuccess) return
    setMfaTimeLeft(mfaState.expiresIn)
    const id = setInterval(() => setMfaTimeLeft((t) => Math.max(0, t - 1)), 1000)
    return () => clearInterval(id)
  }, [mfaState, mfaSuccess])

  // ── Restore session ────────────────────────────────────────────────────────
  useEffect(() => {
    try {
      const saved = sessionStorage.getItem("fraudguard:batch_results")
      if (saved) {
        const parsed = JSON.parse(saved) as BatchResponse
        setResult(parsed)
        runFcm(parsed.results)
      }
    } catch {}
  }, [])

  // ── Open chat for a row ────────────────────────────────────────────────────
  const openChat = (row: any) => {
    sessionStorage.setItem(
      "fraudguard:last_prediction",
      JSON.stringify({
        decision        : row.decision,
        total_risk      : row.total_risk,
        explanation     : row.explanation ?? "",
        row_id          : row.row_id,
        probability     : row.probability,
        shap_score      : row.shap_score,
        forecast_risk   : row.forecast_risk ?? 0,
        confidence_band : row.confidence_band,
        path            : row.path ?? "BATCH",
        layers_used     : row.layers_used ?? [],
        top_drivers     : row.top_drivers ?? [],
        risk_components : row.risk_components ?? {},
        timestamp       : row.timestamp ?? "",
        source          : "batch",
      }),
    )
    router.push(`/chat?row=${row.row_id}`)
  }

  // ── Run FCM clustering via API ─────────────────────────────────────────────
  const runFcm = useCallback(async (results: any[]) => {
    if (!results.length) return
    setFcmLoading(true)
    try {
      const r = await api.clusteringFcm(results, 2)
      setFcm(r)
    } catch { /* silent */ }
    finally { setFcmLoading(false) }
  }, [])

  // ── File helpers ───────────────────────────────────────────────────────────
  const accept = (f?: File | null) => {
    if (!f) return
    if (!/\.csv$/i.test(f.name)) { toast.error("Only .csv files supported"); return }
    setFile(f); setResult(null); setErr(null)
  }

  const upload = async () => {
    if (!file || loading) return
    setLoading(true); setErr(null); setFcm(null)
    try {
      const r = await api.batch(file)
      setResult(r)
      try { sessionStorage.setItem("fraudguard:batch_results", JSON.stringify(r)) } catch {}
      toast.success(`Processed ${r.total_rows} rows · ${r.fraud_found} flagged`)
      runFcm(r.results)

      // ── Check if any row triggered MFA ──────────────────────────────────
      const mfaRow = r.results.find(
        (row: any) => row.mfa_required && row.mfa?.token
      )
      if (mfaRow?.mfa?.token) {
        setMfaState({
          token    : mfaRow.mfa.token,
          cardId   : mfaRow.card_id ?? `row_${mfaRow.row_id}`,
          rowId    : mfaRow.row_id,
          sentTo   : mfaRow.mfa.otp_sent_to ?? "",
          expiresIn: mfaRow.mfa.expires_in ?? 300,
        })
      }
    } catch (e) {
      const msg = (e as Error).message
      setErr(msg); toast.error(msg)
    } finally { setLoading(false) }
  }

  const sendEmail = async () => {
    if (!result || !email.trim()) { toast.error("Enter customer email first"); return }
    setEmailing(true)
    try {
      const r = await api.emailBatchAlert(result.results, email.trim(), true)
      toast.success(`Email ${r.status} · ${r.fraud_count} fraud cases`)
    } catch (e) {
      toast.error((e as Error).message)
    } finally { setEmailing(false) }
  }

  // ──────────────────────────────────────────────────────────────────────────
  return (
    <PageShell
      title="Batch Analysis"
      subtitle="Upload a CSV with V1–V28, amount and time columns. We auto-engineer features and return a fraud-ranked report."
      badge="Batch"
    >
      {/* Feedback Modal */}
      <AnimatePresence>
        {feedbackTarget && (
          <FeedbackModal
            cardId={feedbackTarget.cardId}
            decision={feedbackTarget.decision}
            onClose={() => setFeedbackTarget(null)}
          />
        )}
      </AnimatePresence>
      {/* MFA Modal */}
      <AnimatePresence>
        {mfaState && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm rounded-2xl border border-primary/30 bg-card/98 backdrop-blur p-6 shadow-2xl mx-4"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-primary/60 to-accent/60 text-xl">
                    🔐
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">Identity Verification</h3>
                    <p className="text-[10px] font-mono text-muted-foreground">
                      Row #{mfaState.rowId} · card {mfaState.cardId}
                    </p>
                  </div>
                </div>
                <button
                  onClick={async () => {
                    try { await api.mfaCancel(mfaState.token) } catch {}
                    setMfaState(null); setMfaOtp(""); setMfaErr(null); setMfaSuccess(false)
                  }}
                  className="grid h-7 w-7 place-items-center rounded-md border border-border/50 text-muted-foreground hover:text-foreground transition">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {mfaSuccess ? (
                <div className="py-6 text-center space-y-3">
                  <ShieldCheck className="mx-auto h-12 w-12 text-emerald-400" />
                  <p className="font-semibold text-emerald-300">Transaction Approved!</p>
                  <p className="text-xs font-mono text-muted-foreground">
                    Row #{mfaState.rowId} has been verified
                  </p>
                </div>
              ) : (
                <>
                  {/* Timer */}
                  <div className={cn(
                    "mb-4 rounded-lg border px-3 py-2 text-center font-mono",
                    mfaTimeLeft === 0     ? "border-red-500/40 bg-red-500/10 text-red-300" :
                    mfaTimeLeft < 60 ? "border-amber-500/40 bg-amber-500/10 text-amber-300" :
                                          "border-border/50 bg-background/40 text-muted-foreground",
                  )}>
                    <div className="text-[9px] uppercase tracking-wider mb-0.5">
                      {mfaTimeLeft === 0 ? "Code expired — resend to continue" : "OTP expires in"}
                    </div>
                    {mfaTimeLeft > 0 && (
                      <div className="font-semibold text-lg tabular-nums">
                        {String(Math.floor(mfaTimeLeft / 60)).padStart(2, "0")}:
                        {String(mfaTimeLeft % 60).padStart(2, "0")}
                      </div>
                    )}
                    {mfaState.sentTo && mfaState.sentTo !== "none" && (
                      <div className="text-[9px] mt-0.5 opacity-60">
                        Sent to {mfaState.sentTo}
                      </div>
                    )}
                  </div>

                  {/* OTP input */}
                  <div className="mb-4">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                      Enter 6-Digit Code
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={mfaOtp}
                      onChange={(e) => {
                        setMfaOtp(e.target.value.replace(/\D/g, "").slice(0, 6))
                        setMfaErr(null)
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && mfaOtp.length === 6 && !mfaBusy) {
                          (async () => {
                            setMfaBusy(true); setMfaErr(null)
                            try {
                              const r = await api.mfaVerify(mfaState.token, mfaOtp)
                              if (["verified","SUCCESS","ALREADY_VERIFIED"].some(
                                (s) => r.status === s || r.code === s)) {
                                setMfaSuccess(true)
                                toast.success("Identity verified — transaction approved!")
                                setResult((prev) => {
                                  if (!prev) return prev
                                  return {
                                    ...prev,
                                    results: prev.results.map((row) =>
                                      row.row_id === mfaState.rowId
                                        ? { ...row, decision: r.original_decision ?? "ALLOW ✅" }
                                        : row
                                    ),
                                  }
                                })
                                setTimeout(() => { setMfaState(null); setMfaOtp(""); setMfaSuccess(false) }, 2500)
                              } else {
                                const msg = typeof r.detail === "object"
                                  ? (r.detail as any)?.detail ?? "Verification failed"
                                  : r.message ?? "Verification failed"
                                setMfaErr(msg)
                              }
                            } catch (e: any) {
                              setMfaErr(e?.detail?.detail ?? (e as Error).message)
                            } finally { setMfaBusy(false) }
                          })()
                        }
                      }}
                      placeholder="_ _ _ _ _ _"
                      disabled={mfaTimeLeft === 0 || mfaBusy}
                      className="mt-1.5 w-full rounded-lg border border-border/60 bg-background/40 px-3 py-3 text-center font-mono text-2xl tracking-[0.6em] outline-none transition focus:border-primary/60 focus:shadow-[0_0_0_4px_oklch(0.62_0.24_295/0.15)] disabled:opacity-50"
                    />
                  </div>

                  {mfaErr && (
                    <div className="mb-4 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs font-mono text-red-300">
                      {mfaErr}
                    </div>
                  )}

                  <button
                    type="button"
                    disabled={mfaOtp.length !== 6 || mfaBusy || mfaTimeLeft === 0}
                    onClick={async () => {
                      setMfaBusy(true); setMfaErr(null)
                      try {
                        const r = await api.mfaVerify(mfaState.token, mfaOtp)
                        if (["verified","SUCCESS","ALREADY_VERIFIED"].some(
                          (s) => r.status === s || r.code === s)) {
                          setMfaSuccess(true)
                          toast.success("Identity verified — transaction approved!")
                          setResult((prev) => {
                            if (!prev) return prev
                            return {
                              ...prev,
                              results: prev.results.map((row) =>
                                row.row_id === mfaState.rowId
                                  ? { ...row, decision: r.original_decision ?? "ALLOW ✅" }
                                  : row
                              ),
                            }
                          })
                          setTimeout(() => { setMfaState(null); setMfaOtp(""); setMfaSuccess(false) }, 2500)
                        } else {
                          const msg = typeof r.detail === "object"
                            ? (r.detail as any)?.detail ?? "Verification failed"
                            : r.message ?? "Verification failed"
                          setMfaErr(msg)
                        }
                      } catch (e: any) {
                        setMfaErr(e?.detail?.detail ?? (e as Error).message)
                      } finally { setMfaBusy(false) }
                    }}
                    className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-gradient-to-br from-primary to-accent px-4 py-2.5 text-sm font-medium text-primary-foreground transition disabled:opacity-50"
                  >
                    {mfaBusy && <Loader2 className="h-4 w-4 animate-spin" />}
                    {mfaBusy ? "Verifying…" : "Verify Identity"}
                  </button>

                  <div className="mt-3 flex items-center justify-between">
                    <button
                      type="button"
                      disabled={mfaBusy}
                      onClick={async () => {
                        try {
                          const r = await api.mfaResend(mfaState.token)
                          setMfaTimeLeft(r.expires_in ?? 300)
                          setMfaOtp(""); setMfaErr(null)
                          toast.success(`New OTP sent to ${r.otp_sent_to}`)
                        } catch (e) {
                          toast.error("Resend failed — " + (e as Error).message)
                        }
                      }}
                      className="text-[11px] font-mono text-primary/70 hover:text-primary transition disabled:opacity-50"
                    >
                      Resend OTP
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        try { await api.mfaCancel(mfaState.token) } catch {}
                        setMfaState(null); setMfaOtp(""); setMfaErr(null); setMfaSuccess(false)
                      }}
                      className="text-[11px] font-mono text-muted-foreground hover:text-foreground transition"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Memory Modal */}
      <AnimatePresence>
        {memoryTarget && (
          <MemoryModal
            cardId={memoryTarget}
            onClose={() => setMemoryTarget(null)}
          />
        )}
      </AnimatePresence>

      {/* ── Upload + Email row ─────────────────────────────────────────────── */}
      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        {/* Upload zone */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          className="rounded-xl glass p-6">
          <div
            onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); accept(e.dataTransfer.files?.[0]) }}
            onClick={() => inputRef.current?.click()}
            className={cn(
              "relative cursor-pointer rounded-xl border-2 border-dashed p-10 text-center transition",
              drag
                ? "border-primary/80 bg-primary/10"
                : "border-border/60 hover:border-primary/50 hover:bg-primary/5",
            )}
          >
            <input ref={inputRef} type="file" accept=".csv,text/csv" className="hidden"
              onChange={(e) => accept(e.target.files?.[0])} />
            <UploadCloud className="mx-auto h-10 w-10 text-primary" />
            <p className="mt-3 text-sm font-medium">{file ? "Replace CSV" : "Drag & drop CSV here"}</p>
            <p className="mt-1 text-xs text-muted-foreground">or click to browse · max ~10 MB</p>
            <p className="mt-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
              Required: V1…V28 + amount + time · NO Class column
            </p>
          </div>

          {file && (
            <div className="mt-4 flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
              <div className="flex items-center gap-3 min-w-0">
                <FileSpreadsheet className="h-5 w-5 text-primary shrink-0" />
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{file.name}</div>
                  <div className="text-[11px] font-mono text-muted-foreground">
                    {(file.size / 1024).toFixed(1)} KB
                  </div>
                </div>
              </div>
              <button type="button" onClick={() => { setFile(null); setResult(null) }}
                className="grid h-8 w-8 place-items-center rounded-md border border-border/60 text-muted-foreground hover:text-red-300 hover:border-red-500/40 transition">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          )}

          <div className="mt-4 flex items-center justify-end">
            <button type="button" onClick={upload} disabled={!file || loading}
              className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-br from-primary to-accent px-4 py-2 text-sm font-medium text-primary-foreground shadow-[0_0_24px_-4px_oklch(0.62_0.24_295/0.6)] transition hover:shadow-[0_0_36px_-2px_oklch(0.62_0.24_295/0.9)] disabled:opacity-50">
              {loading
                ? <Loader2 className="h-4 w-4 animate-spin" />
                : <UploadCloud className="h-4 w-4" />}
              Run Batch Analysis
            </button>
          </div>

          {err && (
            <div className="mt-4 rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm text-red-300">
              {err}
            </div>
          )}
        </motion.div>

        {/* Email card */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }} className="rounded-xl glass p-6">
          <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
            <Mail className="h-4 w-4 text-primary" /> Email Alert
          </div>
          <h3 className="mt-2 text-lg font-semibold">Notify on fraud cases</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            After running a batch, send a fraud alert email with the report attached.
          </p>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
            placeholder="customer@example.com"
            className="mt-4 w-full rounded-lg border border-border/60 bg-background/40 px-3 py-2 text-sm outline-none transition focus:border-primary/60 focus:shadow-[0_0_0_4px_oklch(0.62_0.24_295/0.15)]" />
          <button type="button" onClick={sendEmail} disabled={!result || emailing || !email}
            className="mt-3 w-full inline-flex items-center justify-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-4 py-2 text-sm font-medium text-primary hover:bg-primary/20 transition disabled:opacity-50">
            {emailing
              ? <Loader2 className="h-4 w-4 animate-spin" />
              : <Mail className="h-4 w-4" />}
            Send Fraud Alert
          </button>

          <div className="mt-4 rounded-lg border border-primary/20 bg-primary/5 p-3">
            <div className="text-[10px] font-mono uppercase tracking-wider text-primary/70 mb-1">
              Human-in-the-Loop
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Use the <span className="font-mono text-primary">✓/✗</span> buttons per row to
              tell the agent whether its decision was correct. Click{" "}
              <span className="font-mono text-primary">🧠</span> to view the agent&apos;s memory for that card.
            </p>
          </div>
        </motion.div>
      </div>

      {/* ── Results section ────────────────────────────────────────────────── */}
      {result && (
        <motion.section initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }} className="mt-6">

          {/* Summary stats */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Total Rows"  value={result.total_rows.toLocaleString()} />
            <Stat label="Clean Rows"  value={result.validation.clean_rows.toLocaleString()} />
            <Stat label="Fraud Found" value={result.fraud_found.toLocaleString()} tone="danger"
              sub={`${(result.fraud_rate * 100).toFixed(2)}% rate`} />
            <Stat label="Drift" value={result.drift.severity}
              tone={result.drift.drift_detected ? "warning" : "success"} />
          </div>

          {/* Validation issues */}
          {result.validation.issues.length > 0 && (
            <div className="mt-4 rounded-lg border border-amber-500/40 bg-amber-500/10 p-4">
              <div className="flex items-center gap-2 text-amber-300 text-sm font-medium">
                <AlertTriangle className="h-4 w-4" /> Validation issues
              </div>
              <ul className="mt-2 list-disc pl-5 text-xs text-amber-200/80 space-y-1 font-mono">
                {result.validation.issues.map((issue, idx) => (
                  <li key={idx}>{issue}</li>
                ))}
              </ul>
            </div>
          )}

          {/* ── Results table ────────────────────────────────────────────── */}
          <div className="mt-5 overflow-hidden rounded-xl glass">
            <div className="flex items-center justify-between border-b border-border/50 px-5 py-3">
              <h3 className="text-base font-semibold">Results · {result.results.length} rows</h3>
              <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
                Sorted by row id
              </span>
            </div>
            <div className="max-h-[520px] overflow-auto no-scrollbar">
              <table className="w-full text-sm">
                <thead className="sticky top-0 z-10 bg-card/80 backdrop-blur">
                  <tr className="text-left text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
                    <th className="px-4 py-3 font-normal">Row</th>
                    <th className="px-4 py-3 font-normal">Decision</th>
                    <th className="px-4 py-3 font-normal text-right">Probability</th>
                    <th className="px-4 py-3 font-normal text-right">SHAP</th>
                    <th className="px-4 py-3 font-normal text-right">Total Risk</th>
                    <th className="px-4 py-3 font-normal">Confidence</th>
                    <th className="px-4 py-3 font-normal text-center">Ask AI</th>
                    <th className="px-4 py-3 font-normal text-center">Feedback</th>
                    <th className="px-4 py-3 font-normal text-center">Memory</th>
                  </tr>
                </thead>
                <tbody>
                  {result.results.map((r) => {
                    const tone    = decisionTone(r.decision)
                    const cardId  = r.card_id ?? `row_${r.row_id}`
                    const isFraud = r.decision.includes("BLOCK") || r.decision.includes("REVIEW")

                    return (
                      <tr key={r.row_id}
                        className="border-t border-border/30 hover:bg-primary/5 transition">
                        <td className="px-4 py-2.5 font-mono text-muted-foreground">#{r.row_id}</td>
                        <td className="px-4 py-2.5">
                          <span className={cn(
                            "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-mono uppercase tracking-wider",
                            tone.bg, tone.border, tone.color,
                          )}>
                            {tone.label}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 font-mono tabular-nums text-right">
                          {(r.probability * 100).toFixed(2)}%
                        </td>
                        <td className="px-4 py-2.5 font-mono tabular-nums text-right text-muted-foreground">
                          {r.shap_score.toFixed(3)}
                        </td>
                        <td className="px-4 py-2.5 font-mono tabular-nums text-right">
                          {(r.total_risk * 100).toFixed(2)}%
                        </td>
                        <td className="px-4 py-2.5 text-xs text-muted-foreground">
                          {r.confidence_band}
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <button type="button" onClick={() => openChat(r)}
                            className="inline-flex items-center gap-1 rounded-md border border-primary/30 bg-primary/10 px-2 py-1 text-[10px] font-mono text-primary hover:bg-primary/20 transition">
                            <MessageSquare className="h-3 w-3" /> Ask
                          </button>
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <div className="inline-flex items-center gap-1">
                            <button type="button"
                              title="Mark as fraud — agent will learn"
                              onClick={() => setFeedbackTarget({ cardId, decision: r.decision })}
                              className={cn(
                                "grid h-7 w-7 place-items-center rounded border text-[10px] transition",
                                isFraud
                                  ? "border-red-500/40 bg-red-500/10 text-red-400 hover:bg-red-500/20"
                                  : "border-border/50 bg-background/30 text-muted-foreground hover:border-primary/40 hover:text-primary",
                              )}>
                              <ThumbsDown className="h-3 w-3" />
                            </button>
                            <button type="button"
                              title="Mark as legitimate — agent will learn"
                              onClick={() =>
                                api.agentFeedback(cardId, false)
                                  .then((res) => toast.success(`Learned · precision: ${(res.updated_precision * 100).toFixed(1)}%`))
                                  .catch(() => toast.error("Feedback failed"))
                              }
                              className="grid h-7 w-7 place-items-center rounded border border-emerald-500/30 bg-emerald-500/8 text-emerald-400 hover:bg-emerald-500/15 transition">
                              <ThumbsUp className="h-3 w-3" />
                            </button>
                          </div>
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <button type="button"
                            title="View agent memory for this card"
                            onClick={() => setMemoryTarget(cardId)}
                            className="grid h-7 w-7 place-items-center rounded border border-primary/30 bg-primary/8 text-primary/70 hover:bg-primary/15 hover:text-primary transition">
                            <Brain className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* ── FCM Cluster Visualization ──────────────────────────────────── */}
          {(fcmLoading || fcm) && (
            <motion.div
              initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="mt-5 overflow-hidden rounded-xl glass"
            >
              {/* Header */}
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-border/50 px-5 py-3">
                <div>
                  <h3 className="text-base font-semibold">FCM Cluster Visualization</h3>
                  <p className="text-[11px] font-mono text-muted-foreground mt-0.5">
                    Fuzzy C-Means · zone-aware opacity · PCA 2D projection · size = total risk
                  </p>
                </div>

                {/* Cluster fraud-rate cards */}
                {fcm && (
                  <div className="flex flex-wrap gap-2">
                    {([0, 1, 2] as const).map((c) => {
                      const rate = fcm.cluster_fraud_rates?.[c] ?? fcm.cluster_fraud_rates?.[String(c)]
                      if (rate === undefined) return null
                      const size = fcm.cluster_sizes?.[c] ?? fcm.cluster_sizes?.[String(c)]
                      return (
                        <div key={c}
                          className="rounded-lg border px-3 py-1.5 text-center"
                          style={{ borderColor: `${FCM_COLORS[c]}44`, background: `${FCM_COLORS[c]}10` }}
                        >
                          <div className="text-[10px] font-mono uppercase tracking-wider"
                            style={{ color: FCM_COLORS[c] }}>
                            {FCM_LABELS[c]}
                          </div>
                          <div className="font-mono text-sm font-semibold text-white">
                            {(rate * 100).toFixed(0)}%
                          </div>
                          <div className="text-[9px] text-muted-foreground">
                            fraud risk{size !== undefined ? ` · ${size} pts` : ""}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>

              <div className="p-5">
                {/* Zone legend */}
                {fcm && (() => {
                  const zs = fcm.zone_summary ?? {
                    core     : fcm.data.filter((p) => p.zone === "core").length,
                    border   : fcm.data.filter((p) => p.zone === "border").length,
                    uncertain: fcm.data.filter((p) => p.zone === "uncertain").length,
                  }
                  return (
                    <div className="mb-4 flex flex-wrap items-center gap-3">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                        Zones:
                      </span>
                      {([
                        { label: "Core",      key: "core"      as const, color: "#22c55e", sym: "●" },
                        { label: "Border",    key: "border"    as const, color: "#f59e0b", sym: "◐" },
                        { label: "Uncertain", key: "uncertain" as const, color: "#ef4444", sym: "○" },
                      ]).map(({ label, key, color, sym }) => (
                        <div key={key}
                          className="flex items-center gap-1.5 rounded-md border border-border/40 bg-background/30 px-2.5 py-1">
                          <span style={{ color }} className="text-sm leading-none">{sym}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">{label}</span>
                          <span className="font-mono text-[11px] font-semibold text-foreground">
                            {zs[key] ?? 0}
                          </span>
                        </div>
                      ))}
                      <span className="ml-auto text-[10px] font-mono text-muted-foreground/40">
                        opacity = membership certainty
                      </span>
                    </div>
                  )
                })()}

                {/* Loading */}
                {fcmLoading && (
                  <div className="flex h-64 items-center justify-center gap-3 text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <span className="text-sm font-mono">Running FCM clustering…</span>
                  </div>
                )}

                {/* Scatter plot */}
                {fcm && !fcmLoading && (() => {
                  const byCluster = ([0, 1, 2] as const).map((c) =>
                    fcm.data.filter((p) => p.fcm_cluster === c),
                  )

                  return (
                    <ResponsiveContainer width="100%" height={340}>
                      <ScatterChart margin={{ top: 10, right: 12, bottom: 16, left: 12 }}>
                        <XAxis
                          type="number" dataKey="pca_x" name="PC1"
                          tick={{ fill: "#ffffff30", fontSize: 10, fontFamily: "monospace" }}
                          axisLine={{ stroke: "#ffffff10" }} tickLine={false}
                          label={{ value: "PC 1", position: "insideBottomRight",
                            fill: "#ffffff30", fontSize: 10, dy: 12 }}
                        />
                        <YAxis
                          type="number" dataKey="pca_y" name="PC2"
                          tick={{ fill: "#ffffff30", fontSize: 10, fontFamily: "monospace" }}
                          axisLine={{ stroke: "#ffffff10" }} tickLine={false}
                          label={{ value: "PC 2", angle: -90, position: "insideLeft",
                            fill: "#ffffff30", fontSize: 10, dx: -4 }}
                        />
                        <ZAxis type="number" dataKey="total_risk" range={[80, 220]} name="Risk" />

                        <RTooltip
                          cursor={{ strokeDasharray: "3 3", stroke: "#ffffff15" }}
                          content={({ active, payload }) => {
                            if (!active || !payload?.length) return null
                            const d = payload[0]?.payload as any
                            if (!d) return null
                            const zone      = d.zone ?? "border"
                            const zoneColor = zone === "core"
                              ? "#22c55e" : zone === "border" ? "#f59e0b" : "#ef4444"
                            const memberships: Record<string, number> = d.memberships ?? {}

                            return (
                              <div className="rounded-lg border border-white/10 bg-[#0f0f1a]/95 p-3 text-xs font-mono shadow-2xl min-w-[175px]">
                                {/* Row + zone */}
                                <div className="mb-2 flex items-center justify-between gap-3">
                                  <span className="font-semibold text-white">Row #{d.row_id}</span>
                                  <span
                                    className="rounded px-1.5 py-0.5 text-[9px] uppercase tracking-wider font-bold"
                                    style={{ color: zoneColor, background: `${zoneColor}20` }}
                                  >
                                    {zone}
                                  </span>
                                </div>

                                {/* Core metrics */}
                                <div className="space-y-0.5 text-white/55">
                                  <div>Decision <span className="float-right text-white">
                                    {d.decision?.replace(/[🚫✅⚠️🔐]/g, "").trim()}
                                  </span></div>
                                  <div>Risk <span className="float-right text-white">
                                    {(d.total_risk * 100).toFixed(1)}%
                                  </span></div>
                                  <div>Prob <span className="float-right text-white">
                                    {(d.probability * 100).toFixed(1)}%
                                  </span></div>
                                  <div>Cluster <span className="float-right font-bold"
                                    style={{ color: FCM_COLORS[d.fcm_cluster as 0 | 1 | 2] }}>
                                    {FCM_LABELS[d.fcm_cluster as 0 | 1 | 2] ?? d.fcm_cluster}
                                  </span></div>
                                  <div>Cluster fraud <span className="float-right text-white">
                                    {(d.cluster_fraud_risk * 100).toFixed(1)}%
                                  </span></div>
                                  {d.uncertainty !== undefined && (
                                    <div>
                                      Uncertainty gap{" "}
                                      <span className="float-right text-white">
                                        {(d.uncertainty as number).toFixed(3)}
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {/* Memberships breakdown */}
                                {Object.keys(memberships).length > 0 && (
                                  <div className="mt-2 border-t border-white/10 pt-2">
                                    <div className="mb-1.5 text-[9px] uppercase tracking-wider text-white/30">
                                      Memberships
                                    </div>
                                    {Object.entries(memberships)
                                      .sort(([, a], [, b]) => (b as number) - (a as number))
                                      .map(([k, v]) => {
                                        const ci  = Number(k) as 0 | 1 | 2
                                        const pct = Math.round((v as number) * 100)
                                        return (
                                          <div key={k} className="flex items-center gap-1.5 mb-1">
                                            <span style={{ color: FCM_COLORS[ci] }} className="text-[10px]">
                                              ●
                                            </span>
                                            <span className="text-white/40 w-4">
                                              {["A","B","C"][ci]}
                                            </span>
                                            <div className="flex-1 h-1 rounded-full bg-white/10 overflow-hidden">
                                              <div className="h-full rounded-full"
                                                style={{ width: `${pct}%`, background: FCM_COLORS[ci] }} />
                                            </div>
                                            <span className="text-white w-7 text-right">{pct}%</span>
                                          </div>
                                        )
                                      })}
                                  </div>
                                )}
                              </div>
                            )
                          }}
                        />

                        {byCluster.map((pts, ci) => (
                          <Scatter key={ci} name={FCM_LABELS[ci as 0|1|2]} data={pts}>
                            {pts.map((pt, pi) => {
                              const zone   = pt.zone ?? "border"
                              const fillOp = zone === "core" ? 0.70 : zone === "border" ? 0.45 : 0.20
                              const strOp  = zone === "core" ? 0.25 : zone === "border" ? 0.55 : 0.90
                              const strW   = zone === "uncertain" ? 1.5 : 0.8
                              return (
                                <Cell
                                  key={pi}
                                  fill={FCM_COLORS[ci as 0|1|2]}
                                  fillOpacity={fillOp}
                                  stroke={FCM_COLORS[ci as 0|1|2]}
                                  strokeOpacity={strOp}
                                  strokeWidth={strW}
                                />
                              )
                            })}
                          </Scatter>
                        ))}
                      </ScatterChart>
                    </ResponsiveContainer>
                  )
                })()}

                {/* Footer: variance + count */}
                {fcm && !fcmLoading && (
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-[10px] font-mono text-muted-foreground">
                    {fcm.explained_variance?.map((v, i) => (
                      <span key={i}>
                        PC{i + 1} ={" "}
                        <span className="text-primary/70">{(v * 100).toFixed(1)}%</span>{" "}
                        variance
                      </span>
                    ))}
                    <span className="ml-auto">
                      {fcm.n_points} pts · {fcm.n_clusters_fcm} clusters · FCM m=2
                    </span>
                  </div>
                )}
              </div>
            </motion.div>
          )}

        </motion.section>
      )}
    </PageShell>
  )
}

// ── Stat card ─────────────────────────────────────────────────────────────────
function Stat({
  label, value, sub, tone = "primary",
}: {
  label: string; value: string; sub?: string; tone?: "primary" | "danger" | "success" | "warning"
}) {
  const map = {
    primary: "text-foreground",
    danger : "text-red-300",
    success: "text-emerald-300",
    warning: "text-amber-300",
  }
  return (
    <div className="rounded-xl glass p-4">
      <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
        {label}
      </div>
      <div className={cn("mt-1.5 font-mono text-2xl font-semibold tabular-nums", map[tone])}>
        {value}
      </div>
      {sub && <div className="mt-0.5 text-xs text-muted-foreground">{sub}</div>}
    </div>
  )
}