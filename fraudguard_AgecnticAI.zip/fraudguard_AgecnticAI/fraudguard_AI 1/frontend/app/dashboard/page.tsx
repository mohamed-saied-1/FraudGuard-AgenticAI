"use client"

import { useEffect, useState, useCallback } from "react"
import { motion } from "framer-motion"
import {
  Activity, ShieldAlert, ShieldCheck, ShieldQuestion,
  Cpu, Network, AlertTriangle, Gauge, Timer, Sparkles,
  Brain, TrendingUp, TrendingDown, Minus, Zap,
  CheckCircle2, XCircle, RefreshCw, Globe, Swords,
  Wrench, HeartPulse, Target, ChevronRight,
} from "lucide-react"
import { api, API_BASE } from "@/lib/api"
import type {
  MetricsResponse, DriftStatus,
  ForecastTimeseriesResponse, AgentStatusResponse, AgentSelfEvaluationResponse,
  WorldModelResponse, AgentConflictsResponse, AgentHealthResponse, AgentToolsResponse,
} from "@/lib/types"
import { PageShell }    from "@/components/page-shell"
import { MetricCard }   from "@/components/metric-card"
import { RiskGauge }    from "@/components/risk-gauge"
import { KafkaControls} from "@/components/kafka-controls"
import { Skeleton }     from "@/components/ui/skeleton"
import {
  Pie, PieChart, Cell, ResponsiveContainer, Tooltip,
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Area, AreaChart, ReferenceLine,
} from "recharts"
import { cn } from "@/lib/utils"

function fmtUptime(seconds: number) {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}

// ── SARIMA Chart ──────────────────────────────────────────────────────────────

function SarimaChart({ data }: { data: ForecastTimeseriesResponse | null }) {
  if (!data || data.status !== "ok") {
    return (
      <div className="flex h-48 items-center justify-center text-xs font-mono text-muted-foreground">
        {data === null ? "Loading SARIMA forecast…" : "No forecast data yet — make some predictions first"}
      </div>
    )
  }

  const histSlice = data.historical.slice(-48)
  const combined  = [
    ...histSlice.map((p, i) => ({
      idx        : i,
      label      : `H-${histSlice.length - i}`,
      hist_rate  : +(p.rolling_rate * 10000).toFixed(2),
      fore_rate  : undefined as number | undefined,
      ci_lower   : undefined as number | undefined,
      ci_upper   : undefined as number | undefined,
      is_spike   : p.is_spike,
      type       : "hist" as const,
    })),
    ...data.forecast.slice(0, 24).map((p, i) => ({
      idx        : histSlice.length + i,
      label      : `+${p.horizon_h}h`,
      hist_rate  : undefined as number | undefined,
      fore_rate  : +(p.predicted_rate * 10000).toFixed(2),
      ci_lower   : +(p.ci_lower * 10000).toFixed(2),
      ci_upper   : +(p.ci_upper * 10000).toFixed(2),
      is_spike   : false,
      type       : "fore" as const,
    })),
  ]

  const trendColor =
    data.trend_direction === "rising"   ? "oklch(0.62 0.24 22)"  :
    data.trend_direction === "declining"? "oklch(0.70 0.18 150)" :
    "oklch(0.62 0.24 295)"

  const TrendIcon =
    data.trend_direction === "rising"   ? TrendingUp   :
    data.trend_direction === "declining"? TrendingDown  : Minus

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <TrendIcon className="h-4 w-4" style={{ color: trendColor }} />
          <span className="font-mono text-xs" style={{ color: trendColor }}>
            {data.trend_direction.toUpperCase()}
          </span>
          <span className="text-[10px] font-mono text-muted-foreground">
            base={+(data.base_rate * 10000).toFixed(2)}/10k
          </span>
        </div>
        <div className="flex items-center gap-3 text-[10px] font-mono">
          <span className="flex items-center gap-1">
            <span className="inline-block h-1.5 w-4 rounded-full bg-[oklch(0.62_0.24_295)]" />
            Historical
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block h-1.5 w-4 rounded-full border border-dashed border-[oklch(0.78_0.16_75)]" />
            Forecast ±CI
          </span>
          {data.live.anomaly_active && (
            <span className="inline-flex items-center gap-1 rounded-full border border-red-500/40 bg-red-500/10 px-2 py-0.5 text-red-300">
              <AlertTriangle className="h-2.5 w-2.5" /> ANOMALY
            </span>
          )}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={combined} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor="oklch(0.62 0.24 295)" stopOpacity={0.25} />
              <stop offset="95%" stopColor="oklch(0.62 0.24 295)" stopOpacity={0}    />
            </linearGradient>
            <linearGradient id="foreGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor="oklch(0.78 0.16 75)" stopOpacity={0.2} />
              <stop offset="95%" stopColor="oklch(0.78 0.16 75)" stopOpacity={0}   />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="oklch(0.22 0.03 285 / 0.3)" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="label"
            tick={{ fill: "oklch(0.55 0.02 280)", fontSize: 9, fontFamily: "monospace" }}
            axisLine={false} tickLine={false}
            interval={Math.floor(combined.length / 8)} />
          <YAxis
            tick={{ fill: "oklch(0.55 0.02 280)", fontSize: 9, fontFamily: "monospace" }}
            axisLine={false} tickLine={false}
            tickFormatter={(v) => `${v}`} width={28} />
          <Tooltip
            contentStyle={{
              background: "oklch(0.08 0.02 280 / 0.96)",
              border: "1px solid oklch(0.62 0.24 295 / 0.4)",
              borderRadius: 8, fontFamily: "monospace", fontSize: 11,
            }}
            formatter={(val: number, name: string) => {
              if (name === "hist_rate") return [`${val}/10k`, "Historical rate"]
              if (name === "fore_rate") return [`${val}/10k`, "Forecast rate"]
              if (name === "ci_upper")  return [`${val}/10k`, "CI upper"]
              if (name === "ci_lower")  return [`${val}/10k`, "CI lower"]
              return [val, name]
            }}
          />
          <ReferenceLine
            x={histSlice.length > 0 ? combined[histSlice.length - 1]?.label : undefined}
            stroke="oklch(0.62 0.24 295 / 0.5)" strokeDasharray="4 2"
            label={{ value: "now", position: "insideTop", fill: "oklch(0.62 0.24 295)", fontSize: 9 }}
          />
          <Area type="monotone" dataKey="hist_rate"
            stroke="oklch(0.62 0.24 295)" strokeWidth={2} fill="url(#histGrad)"
            dot={false} isAnimationActive={false} connectNulls={false} />
          <Area type="monotone" dataKey="fore_rate"
            stroke="oklch(0.78 0.16 75)" strokeWidth={2} strokeDasharray="5 3"
            fill="url(#foreGrad)" dot={false} isAnimationActive={false} connectNulls={false} />
          <Line type="monotone" dataKey="ci_upper"
            stroke="oklch(0.78 0.16 75 / 0.35)" strokeWidth={1} strokeDasharray="2 4"
            dot={false} isAnimationActive={false} connectNulls={false} />
          <Line type="monotone" dataKey="ci_lower"
            stroke="oklch(0.78 0.16 75 / 0.35)" strokeWidth={1} strokeDasharray="2 4"
            dot={false} isAnimationActive={false} connectNulls={false} />
        </AreaChart>
      </ResponsiveContainer>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded-lg border border-border/40 bg-background/30 p-2">
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">Mode</div>
          <div className={cn("mt-0.5 font-mono text-xs font-semibold",
            data.live.anomaly_active ? "text-red-300" : "text-emerald-300")}>
            {data.live.adaptive_mode}
          </div>
        </div>
        <div className="rounded-lg border border-border/40 bg-background/30 p-2">
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">Rolling</div>
          <div className="mt-0.5 font-mono text-xs font-semibold">
            {+(data.live.rolling_fraud_rate * 10000).toFixed(1)}/10k
          </div>
        </div>
        <div className="rounded-lg border border-border/40 bg-background/30 p-2">
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">Horizon</div>
          <div className="mt-0.5 font-mono text-xs font-semibold">{data.horizon_hours}h</div>
        </div>
      </div>
    </div>
  )
}

// ── Agent Brain Panel ──────────────────────────────────────────────────────────

function AgentBrainPanel({
  status, evaluation,
}: {
  status     : AgentStatusResponse | null
  evaluation : AgentSelfEvaluationResponse | null
}) {
  const health = evaluation?.system_health ?? "healthy"
  const healthColor =
    health === "healthy"   ? "text-emerald-300 border-emerald-500/40 bg-emerald-500/10" :
    health === "degrading" ? "text-amber-300 border-amber-500/40 bg-amber-500/10"       :
    "text-red-300 border-red-500/40 bg-red-500/10"

  const props = evaluation?.six_properties_active ?? {}

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className={cn(
          "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider",
          healthColor,
        )}>
          <span className={cn("h-1.5 w-1.5 rounded-full",
            health === "healthy" ? "bg-emerald-400 animate-pulse" :
            health === "degrading"? "bg-amber-400" : "bg-red-400")} />
          {health}
        </span>
        {status && (
          <span className="text-[10px] font-mono text-muted-foreground">
            {status.memory_episodes} episodes · {status.memory_users} users
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono">
        {[
          { key: "observes_continuously",  label: "1. Observes"     },
          { key: "reasons_before_acting",  label: "2. Reasons"      },
          { key: "acts_with_explanation",  label: "3. Explains"     },
          { key: "adapts_to_outcomes",     label: "4. Adapts"       },
          { key: "detects_own_degradation",label: "5. Self-Diagnose" },
          { key: "retrains_autonomously",  label: "6. Self-Retrain"  },
        ].map(({ key, label }) => {
          const active = props[key] ?? false
          return (
            <div key={key}
              className={cn(
                "flex items-center gap-1.5 rounded border px-2 py-1.5 transition",
                active
                  ? "border-emerald-500/30 bg-emerald-500/8 text-emerald-300"
                  : "border-border/40 bg-background/30 text-muted-foreground",
              )}
            >
              {active
                ? <CheckCircle2 className="h-3 w-3 text-emerald-400 shrink-0" />
                : <XCircle     className="h-3 w-3 text-muted-foreground/50 shrink-0" />}
              {label}
            </div>
          )
        })}
      </div>

      {evaluation && (
        <div className="grid grid-cols-3 gap-2 text-center">
          <Micro k="Precision"  v={`${(evaluation.precision_estimate * 100).toFixed(1)}%`} />
          <Micro k="Quality ✓"  v={`${(evaluation.quality_rate * 100).toFixed(0)}%`} />
          <Micro k="Retraining" v={evaluation.retraining_recommended ? "⚠ NEEDED" : "OK"} />
        </div>
      )}
    </div>
  )
}

// ── ★ NEW: World Model Panel ──────────────────────────────────────────────────

function WorldModelPanel({ data }: { data: WorldModelResponse | null }) {
  if (!data) {
    return (
      <div className="flex h-32 items-center justify-center text-[10px] font-mono text-muted-foreground/50">
        Loading world model…
      </div>
    )
  }

  const wm = data.world_model
  const topCausal = data.top_causal_features.slice(0, 4)

  // Hour risk heatmap (0-23)
  const hours = Array.from({ length: 24 }, (_, h) => ({
    h,
    risk: data.hour_risk_profile[String(h)] ?? 0,
  }))
  const maxRisk = Math.max(...hours.map((x) => x.risk), 0.001)

  return (
    <div className="space-y-3">
      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded-lg border border-border/40 bg-background/30 p-2">
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">Seen</div>
          <div className="mt-0.5 font-mono text-xs font-semibold">{wm.total_seen.toLocaleString()}</div>
        </div>
        <div className={cn("rounded-lg border p-2 text-center",
          wm.active_campaigns > 0 ? "border-red-500/40 bg-red-500/10" : "border-border/40 bg-background/30")}>
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">Campaigns</div>
          <div className={cn("mt-0.5 font-mono text-xs font-semibold",
            wm.active_campaigns > 0 ? "text-red-300" : "")}>
            {wm.active_campaigns}
          </div>
        </div>
        <div className="rounded-lg border border-border/40 bg-background/30 p-2">
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">Patterns</div>
          <div className="mt-0.5 font-mono text-xs font-semibold">{wm.known_patterns}</div>
        </div>
      </div>

      {/* Active campaigns */}
      {data.active_campaigns.length > 0 && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/8 p-2.5">
          <div className="text-[9px] font-mono uppercase tracking-wider text-red-400 mb-1.5 flex items-center gap-1">
            <Swords className="h-3 w-3" /> Active Campaigns
          </div>
          {data.active_campaigns.slice(-2).map((c, i) => (
            <div key={i} className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-red-300/70 truncate">{c.id.replace("campaign_", "CAM-")}</span>
              <span className="text-red-300 font-semibold">
                {(c.high_risk_rate * 100).toFixed(0)}% high-risk
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Hour risk heatmap */}
      <div>
        <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground mb-1.5">
          Hour Risk Profile (peak: {wm.peak_fraud_hour}:00)
        </div>
        <div className="flex gap-0.5">
          {hours.map(({ h, risk }) => {
            const intensity = risk / maxRisk
            return (
              <div key={h} title={`${h}:00 — ${(risk * 100).toFixed(3)}%`}
                className="flex-1 rounded-sm"
                style={{
                  height: 20,
                  background: `oklch(${0.4 + intensity * 0.25} ${0.05 + intensity * 0.2} ${intensity > 0.5 ? 22 : 295} / ${0.2 + intensity * 0.8})`,
                }}
              />
            )
          })}
        </div>
        <div className="mt-0.5 flex justify-between text-[8px] font-mono text-muted-foreground/50">
          <span>0h</span><span>12h</span><span>23h</span>
        </div>
      </div>

      {/* Top causal features */}
      {topCausal.length > 0 && (
        <div>
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground mb-1.5">
            Top Causal Features
          </div>
          <div className="space-y-1">
            {topCausal.map(([feat, weight], i) => {
              const pct = Math.min(100, (weight / (topCausal[0][1] + 1e-8)) * 100)
              return (
                <div key={feat} className="flex items-center gap-2">
                  <span className="w-3 text-[9px] font-mono text-muted-foreground/50">{i + 1}</span>
                  <span className="w-12 truncate text-[10px] font-mono text-primary/70">{feat}</span>
                  <div className="flex-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-primary/60 to-accent/60"
                      style={{ width: `${pct}%` }} />
                  </div>
                  <span className="text-[9px] font-mono text-muted-foreground/60 w-8 text-right">
                    {weight.toFixed(3)}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

// ── ★ NEW: Inter-Agent Conflicts Panel ───────────────────────────────────────

function ConflictsPanel({ data }: { data: AgentConflictsResponse | null }) {
  if (!data) {
    return (
      <div className="flex h-24 items-center justify-center text-[10px] font-mono text-muted-foreground/50">
        Loading conflicts…
      </div>
    )
  }

  if (data.recent_conflicts.length === 0) {
    return (
      <div className="flex h-24 items-center justify-center gap-2 text-[10px] font-mono text-emerald-400/60">
        <CheckCircle2 className="h-3.5 w-3.5" />
        No conflicts — all agents in agreement
      </div>
    )
  }

  const severityStyle = (s: string) =>
    s === "high"   ? "border-red-500/40 bg-red-500/10 text-red-300"     :
    s === "medium" ? "border-amber-500/40 bg-amber-500/10 text-amber-300" :
    "border-border/40 bg-background/30 text-muted-foreground"

  return (
    <div className="space-y-2">
      <div className="text-[10px] font-mono text-muted-foreground">
        {data.total_messages} total messages · {data.recent_conflicts.length} conflicts
      </div>
      {data.recent_conflicts.slice(0, 4).map((c, i) => (
        <div key={i} className={cn(
          "rounded-lg border p-2.5 space-y-1",
          severityStyle(c.severity),
        )}>
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-wider">
              {c.type.replace(/_/g, " ")}
            </span>
            <span className="text-[9px] font-mono opacity-60">
              {new Date(c.ts).toLocaleTimeString()}
            </span>
          </div>
          <p className="text-[10px] font-mono opacity-80 leading-relaxed">{c.message}</p>
          <div className="flex items-center gap-1 text-[9px] font-mono opacity-60">
            <ChevronRight className="h-2.5 w-2.5" />
            {c.resolution.replace(/_/g, " ")}
          </div>
        </div>
      ))}
    </div>
  )
}

// ── ★ NEW: System Health Panel ───────────────────────────────────────────────

function SystemHealthPanel({ data }: { data: AgentHealthResponse | null }) {
  if (!data) {
    return (
      <div className="flex h-24 items-center justify-center text-[10px] font-mono text-muted-foreground/50">
        Loading health data…
      </div>
    )
  }

  const components = [
    { key: "shap",      label: "SHAP",      ok: data.shap_ok  },
    { key: "kafka",     label: "Kafka",     ok: data.kafka_ok },
    { key: "llm",       label: "LLM",       ok: data.llm_ok   },
    { key: "rag_index", label: "RAG Index", ok: data.rag_ok   },
  ]

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        {components.map(({ key, label, ok }) => {
          const sub = data.subsystems[key]
          return (
            <div key={key} className={cn(
              "rounded-lg border p-2.5 space-y-1",
              ok ? "border-emerald-500/30 bg-emerald-500/8"
                 : "border-red-500/30 bg-red-500/8",
            )}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-semibold">{label}</span>
                <span className={cn(
                  "inline-flex items-center gap-1 text-[9px] font-mono uppercase",
                  ok ? "text-emerald-400" : "text-red-400",
                )}>
                  <span className={cn("h-1.5 w-1.5 rounded-full",
                    ok ? "bg-emerald-400" : "bg-red-400 animate-pulse")} />
                  {ok ? "OK" : "FAIL"}
                </span>
              </div>
              {sub && !ok && (
                <div className="text-[9px] font-mono text-muted-foreground">
                  fallback: <span className="text-amber-400/80">{sub.fallback.replace(/_/g, " ")}</span>
                </div>
              )}
              {sub && (
                <div className="text-[9px] font-mono text-muted-foreground/50">
                  failures: {sub.failures}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Recent alerts */}
      {data.alerts.length > 0 && (
        <div className="space-y-1.5">
          <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">
            Recent Alerts
          </div>
          {data.alerts.slice(0, 3).map((a, i) => (
            <div key={i} className="flex items-start gap-2 rounded border border-red-500/20 bg-red-500/5 px-2.5 py-1.5">
              <AlertTriangle className="h-3 w-3 text-red-400 shrink-0 mt-0.5" />
              <div>
                <div className="text-[10px] font-mono text-red-300">
                  {a.component} → {a.fallback.replace(/_/g, " ")}
                </div>
                {a.error && (
                  <div className="text-[9px] font-mono text-muted-foreground/60 truncate max-w-[200px]">
                    {a.error}
                  </div>
                )}
              </div>
              <span className="ml-auto text-[9px] font-mono text-muted-foreground/40 shrink-0">
                {new Date(a.ts).toLocaleTimeString()}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ── ★ NEW: Tool Registry Panel ───────────────────────────────────────────────

function ToolRegistryPanel({ data }: { data: AgentToolsResponse | null }) {
  if (!data) {
    return (
      <div className="flex h-24 items-center justify-center text-[10px] font-mono text-muted-foreground/50">
        Loading tool registry…
      </div>
    )
  }

  const tools = Object.entries(data.tools).slice(0, 8)

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-[10px] font-mono text-muted-foreground">
        <span>{data.total_tools} tools registered</span>
        <span>
          selected for [core,ml]: <span className="text-primary/70">
            {data.situation_example.slice(0, 3).join(", ")}
          </span>
        </span>
      </div>
      <div className="space-y-1">
        {tools.map(([name, meta]) => {
          const reliability = 1 - meta.error_rate
          return (
            <div key={name} className="flex items-center gap-2 rounded border border-border/30 bg-background/20 px-2.5 py-1.5">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono text-primary/80 truncate">{name}</span>
                  <div className="flex gap-0.5 flex-wrap">
                    {meta.tags.slice(0, 2).map((t) => (
                      <span key={t} className="rounded border border-primary/20 bg-primary/8 px-1 text-[8px] font-mono text-primary/60">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 text-[9px] font-mono shrink-0">
                <span className="text-muted-foreground/60">{meta.calls}x</span>
                <span className="text-muted-foreground/60">{meta.avg_ms.toFixed(0)}ms</span>
                <span className={cn(
                  reliability > 0.9 ? "text-emerald-400" :
                  reliability > 0.7 ? "text-amber-400" : "text-red-400",
                )}>
                  {(reliability * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── ReAct Log Feed ────────────────────────────────────────────────────────────

function ReactLogFeed({ entries }: { entries: any[] }) {
  if (!entries || entries.length === 0) {
    return (
      <div className="p-6 text-center text-xs font-mono text-muted-foreground/60">
        No ReAct traces yet — make a prediction to see the agent&apos;s reasoning.
      </div>
    )
  }

  return (
    <ul className="max-h-[280px] overflow-auto no-scrollbar divide-y divide-border/20">
      {entries.slice(0, 15).map((e, i) => {
        const isBlock  = String(e.decision ?? "").includes("BLOCK")
        const isReview = String(e.decision ?? "").includes("REVIEW")
        const qColor =
          e.quality === "good"      ? "text-emerald-400" :
          e.quality === "uncertain" ? "text-amber-400"   :
          e.quality === "risky"     ? "text-red-400"     : "text-muted-foreground"

        return (
          <motion.li key={i}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.03 }}
            className="px-4 py-2.5 hover:bg-white/[0.02] transition"
          >
            <div className="flex items-center gap-2 font-mono text-[10px]">
              <span className={cn(
                "rounded px-1.5 py-0.5 font-bold uppercase",
                isBlock  ? "bg-red-500/15 text-red-400 border border-red-500/30" :
                isReview ? "bg-amber-500/15 text-amber-400 border border-amber-500/30" :
                           "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30",
              )}>
                {String(e.decision ?? "").replace(/[🚫✅⚠️🔐]/g, "").trim() || "—"}
              </span>
              <span className="text-muted-foreground/60 truncate flex-1">
                {e.routing_path ?? "—"}
              </span>
              <span className={cn("shrink-0 font-semibold", qColor)}>
                {e.quality ?? "—"}
              </span>
              <span className="shrink-0 text-muted-foreground/40">
                {e.latency_ms?.toFixed(0)}ms
              </span>
            </div>
            {e.reasoning_chain && e.reasoning_chain.length > 0 && (
              <div className="mt-1 flex flex-wrap gap-1">
                {e.reasoning_chain.slice(0, 3).map((r: string, ri: number) => (
                  <span key={ri}
                    className="rounded-sm border border-border/40 bg-background/30 px-1.5 py-0.5 text-[9px] font-mono text-primary/60">
                    {r}
                  </span>
                ))}
              </div>
            )}
          </motion.li>
        )
      })}
    </ul>
  )
}

function Micro({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded border border-border/40 bg-background/30 p-1.5">
      <div className="text-[9px] font-mono uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className="mt-0.5 font-mono text-xs font-semibold">{v}</div>
    </div>
  )
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ════════════════════════════════════════════════════════════════════════════

export default function DashboardPage() {
  const [metrics,     setMetrics]     = useState<MetricsResponse | null>(null)
  const [drift,       setDrift]       = useState<DriftStatus | null>(null)
  const [sarima,      setSarima]      = useState<ForecastTimeseriesResponse | null>(null)
  const [agentStatus, setAgentStatus] = useState<AgentStatusResponse | null>(null)
  const [agentEval,   setAgentEval]   = useState<AgentSelfEvaluationResponse | null>(null)
  // ★ NEW states
  const [worldModel,   setWorldModel]   = useState<WorldModelResponse | null>(null)
  const [conflicts,    setConflicts]    = useState<AgentConflictsResponse | null>(null)
  const [agentHealthData, setAgentHealthData] = useState<AgentHealthResponse | null>(null)
  const [agentTools,   setAgentTools]   = useState<AgentToolsResponse | null>(null)

  const [error,       setError]       = useState<string | null>(null)
  const [loading,     setLoading]     = useState(true)
  const [kafkaLog,    setKafkaLog]    = useState<any[]>([])

  const loadCore = useCallback(async () => {
    try {
      const [m, d] = await Promise.all([api.metrics(), api.driftStatus()])
      setMetrics(m)
      setDrift(d)
      setError(null)
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setLoading(false)
    }
  }, [])

  const loadAgent = useCallback(async () => {
    try {
      const [ts, st, ev, wm, cf, ah, at] = await Promise.all([
        api.forecastTimeseries(24),
        api.agentStatus(),
        api.agentSelfEvaluation(),
        api.agentWorldModel(),    // ★ NEW
        api.agentConflicts(),     // ★ NEW
        api.agentHealth(),        // ★ NEW
        api.agentTools(),         // ★ NEW
      ])
      setSarima(ts)
      setAgentStatus(st)
      setAgentEval(ev)
      setWorldModel(wm)
      setConflicts(cf)
      setAgentHealthData(ah)
      setAgentTools(at)
    } catch {
      // agent endpoints are best-effort
    }
  }, [])

  // ★ FIXED: uses api.kafkaConsumerLog instead of direct fetch
  const fetchKafkaLog = useCallback(async () => {
    try {
      const d = await api.kafkaConsumerLog(5)
      setKafkaLog(d.entries ?? [])
    } catch {}
  }, [])

  useEffect(() => {
    let mounted = true
    const tick = () => { if (mounted) { loadCore(); fetchKafkaLog() } }
    tick()
    loadAgent()
    const coreId  = setInterval(tick, 5000)
    const agentId = setInterval(() => { if (mounted) loadAgent() }, 15000)
    return () => { mounted = false; clearInterval(coreId); clearInterval(agentId) }
  }, [loadCore, loadAgent, fetchKafkaLog])

  const distData = metrics
    ? [
        { name: "Allows",  value: metrics.allows,  color: "oklch(0.70 0.18 150)" },
        { name: "Reviews", value: metrics.reviews, color: "oklch(0.78 0.16 75)"  },
        { name: "Blocks",  value: metrics.blocks,  color: "oklch(0.62 0.24 22)"  },
      ]
    : []

  const reactEntries = agentStatus?.react_log ?? []

  return (
    <PageShell
      title="Mission Control"
      subtitle="Live telemetry, SARIMA forecast, decision distribution, Agentic AI — World Model, Conflicts, Health, Tools."
      badge="Dashboard"
    >
      {error && (
        <div className="mb-6 rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-300">
          <strong>Backend offline:</strong> {error}. Make sure FastAPI is running on{" "}
          <code className="font-mono">http://127.0.0.1:8000</code>.
        </div>
      )}

      {/* ── Row 1: Kafka + 4 Metrics ── */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <div className="md:col-span-2 xl:col-span-4">
          <KafkaControls />
        </div>
        {loading && !metrics ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-[124px] rounded-xl" />)
        ) : metrics ? (
          <>
            <MetricCard label="Total Decisions" value={metrics.total.toLocaleString()}
              sub={`Uptime ${fmtUptime(metrics.uptime_seconds)}`} Icon={Activity} tone="primary" delay={0} />
            <MetricCard label="Blocks" value={metrics.blocks.toLocaleString()}
              sub={`${metrics.velocity_blocks} velocity-based`} Icon={ShieldAlert} tone="danger" delay={0.05} />
            <MetricCard label="Reviews" value={metrics.reviews.toLocaleString()}
              sub="Manual queue" Icon={ShieldQuestion} tone="warning" delay={0.1} />
            <MetricCard label="Allows" value={metrics.allows.toLocaleString()}
              sub={`Fraud rate ${metrics.fraud_rate_pct.toFixed(2)}%`} Icon={ShieldCheck} tone="success" delay={0.15} />
          </>
        ) : null}
      </div>

      {/* ── Row 2: Gauge + Distribution + System Health ── */}
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="rounded-xl glass p-6 flex flex-col items-center justify-center">
          <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground mb-2">
            Forecast · Rolling Fraud Rate
          </div>
          <RiskGauge value={metrics ? Math.min(metrics.forecast.rolling_rate * 50, 1) : 0} label="Anomaly Index" />
          <div className="mt-2 flex items-center gap-2 text-xs">
            {metrics?.forecast.anomaly_detected ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-red-500/40 bg-red-500/10 px-2 py-1 text-red-300 font-mono">
                <AlertTriangle className="h-3 w-3" /> Anomaly detected
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-2 py-1 text-emerald-300 font-mono">
                <ShieldCheck className="h-3 w-3" /> Stable
              </span>
            )}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">Distribution</div>
              <h3 className="text-base font-semibold">Decision Mix</h3>
            </div>
            <Gauge className="h-5 w-5 text-primary" />
          </div>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={distData} cx="50%" cy="50%" innerRadius={48} outerRadius={70}
                  paddingAngle={3} dataKey="value">
                  {distData.map((d, i) => (
                    <Cell key={i} fill={d.color} stroke="oklch(0.10 0.02 280)" strokeWidth={2} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{
                  background: "oklch(0.10 0.02 280 / 0.95)",
                  border: "1px solid oklch(0.62 0.24 295 / 0.4)",
                  borderRadius: 8, fontFamily: "var(--font-mono)", fontSize: 12,
                }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {distData.map((d) => (
              <div key={d.name} className="rounded-md border border-border/60 bg-background/40 p-2">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-sm" style={{ background: d.color }} />
                  <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">{d.name}</span>
                </div>
                <div className="mt-1 font-mono text-sm tabular-nums">{d.value}</div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">System Health</div>
              <h3 className="text-base font-semibold">Subsystems</h3>
            </div>
            <Cpu className="h-5 w-5 text-primary" />
          </div>
          <ul className="space-y-2.5 text-sm">
            <Health row="Model"         ok={metrics?.model_loaded} />
            <Health row="SHAP Explainer"ok={metrics?.shap_ready}   />
            <Health row="LLM Override"  ok={metrics?.llm_ready}    />
            <Health row="Agent Brain"   ok={agentStatus !== null}   />
            <li className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
              <div className="flex items-center gap-2">
                <Network className="h-4 w-4 text-primary" />
                <span>Drift Monitor</span>
              </div>
              <span className="font-mono text-xs text-muted-foreground">
                {drift?.monitor_features?.length ?? metrics?.drift.monitor_features?.length ?? 0} features
              </span>
            </li>
            <li className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
              <div className="flex items-center gap-2">
                <Timer className="h-4 w-4 text-primary" />
                <span>Last Retrain</span>
              </div>
              <span className="font-mono text-xs text-muted-foreground">
                {metrics?.drift.last_retrain
                  ? new Date(metrics.drift.last_retrain * 1000).toLocaleString()
                  : "—"}
              </span>
            </li>
            <li className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                <span>LLM Overrides</span>
              </div>
              <span className="font-mono text-xs">{metrics?.llm_overrides ?? 0}</span>
            </li>
          </ul>
        </motion.div>
      </div>

      {/* ── Row 3: SARIMA + Agent Brain ── */}
      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_380px]">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.25 }} className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                Time-Series · Live Data
              </div>
              <h3 className="text-base font-semibold flex items-center gap-2">
                SARIMA Fraud Forecast
                <span className="rounded border border-primary/30 bg-primary/10 px-1.5 py-0.5 font-mono text-[9px] text-primary/70">
                  {sarima?.model_info?.type ?? "SARIMA(1,1,1)(1,1,1,24)"}
                </span>
              </h3>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                Built from live prediction logs · rates per 10k transactions
              </p>
            </div>
            <TrendingUp className="h-5 w-5 text-primary" />
          </div>
          <SarimaChart data={sarima} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }} className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">Agentic AI</div>
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Brain className="h-4 w-4 text-primary" /> Agent Brain
              </h3>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                {agentStatus?.agents_active?.length ?? 8} agents · Observe→Reason→Act→Reflect→Learn
              </p>
            </div>
            <Zap className="h-5 w-5 text-primary" />
          </div>
          <AgentBrainPanel status={agentStatus} evaluation={agentEval} />
        </motion.div>
      </div>

      {/* ★ NEW Row 4: World Model + Inter-Agent Conflicts ── */}
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.32 }} className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                Agentic Feature 2
              </div>
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Globe className="h-4 w-4 text-primary" /> World Model
              </h3>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                Attacker patterns · campaign detection · causal features
              </p>
            </div>
            <button onClick={loadAgent}
              className="text-[10px] font-mono text-muted-foreground hover:text-foreground transition">
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </div>
          <WorldModelPanel data={worldModel} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.35 }} className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                Agentic Feature 3
              </div>
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Swords className="h-4 w-4 text-primary" /> Inter-Agent Conflicts
              </h3>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                Detection vs Security vs Forecast agent disagreements
              </p>
            </div>
            <button onClick={loadAgent}
              className="text-[10px] font-mono text-muted-foreground hover:text-foreground transition">
              <RefreshCw className="h-3.5 w-3.5" />
            </button>
          </div>
          <ConflictsPanel data={conflicts} />
        </motion.div>
      </div>

      {/* ★ NEW Row 5: Self-Healing Health + Tool Registry ── */}
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.38 }} className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                Agentic Feature 7
              </div>
              <h3 className="text-base font-semibold flex items-center gap-2">
                <HeartPulse className="h-4 w-4 text-primary" /> Self-Healing Infrastructure
              </h3>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                SHAP/Kafka/LLM/RAG health · automatic fallbacks
              </p>
            </div>
          </div>
          <SystemHealthPanel data={agentHealthData} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.41 }} className="rounded-xl glass p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">
                Agentic Feature 5
              </div>
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Wrench className="h-4 w-4 text-primary" /> Autonomous Tool Registry
              </h3>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                Dynamic tool selection · performance tracking · budget-aware
              </p>
            </div>
          </div>
          <ToolRegistryPanel data={agentTools} />
        </motion.div>
      </div>

      {/* ── Row 6: ReAct Log ── */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.44 }}
        className="mt-4 rounded-xl glass overflow-hidden">
        <div className="flex items-center justify-between border-b border-border/50 px-5 py-3 bg-white/[0.02]">
          <div>
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Zap className="h-4 w-4 text-primary" /> ReAct Reasoning Log
            </h3>
            <p className="text-[10px] font-mono text-muted-foreground mt-0.5">
              Agent&apos;s chain-of-thought per transaction · last {reactEntries.length} decisions
            </p>
          </div>
          <div className="flex items-center gap-3">
            {agentStatus && (
              <span className="text-[10px] font-mono text-muted-foreground">
                {agentStatus.react_log_size} total decisions
              </span>
            )}
            <button onClick={loadAgent}
              className="inline-flex items-center gap-1 rounded border border-border/50 bg-background/30 px-2 py-1 text-[10px] font-mono text-muted-foreground hover:text-foreground transition">
              <RefreshCw className="h-3 w-3" /> Refresh
            </button>
          </div>
        </div>
        <ReactLogFeed entries={reactEntries} />
      </motion.div>

      {/* ── Row 7: Recent Kafka Decisions ── */}
      {kafkaLog.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.47 }}
          className="mt-4 rounded-xl glass overflow-hidden shadow-xl">
          <div className="flex items-center justify-between border-b border-border/50 px-5 py-3 bg-white/[0.02]">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" /> Recent Consumer Activity
            </h3>
            <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
              Live Feed · {kafkaLog.length} Items
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border/30 text-[10px] uppercase tracking-wider text-muted-foreground bg-black/20">
                  <th className="px-5 py-2.5 text-left font-normal">User ID</th>
                  <th className="px-5 py-2.5 text-left font-normal">Amount</th>
                  <th className="px-5 py-2.5 text-left font-normal">Location</th>
                  <th className="px-5 py-2.5 text-left font-normal">Decision</th>
                  <th className="px-5 py-2.5 text-right font-normal">Risk Index</th>
                </tr>
              </thead>
              <tbody>
                {kafkaLog.map((e, i) => {
                  const isBlock  = String(e.decision ?? "").includes("BLOCK")
                  const isReview = String(e.decision ?? "").includes("REVIEW")
                  const colorClass = isBlock ? "text-red-400" : isReview ? "text-amber-400" : "text-emerald-400"
                  return (
                    <tr key={i} className="border-b border-border/10 hover:bg-white/[0.02] transition-colors group">
                      <td className="px-5 py-3 text-white/50 group-hover:text-white/80 transition-colors">{e.user_id ?? "—"}</td>
                      <td className="px-5 py-3 font-semibold text-white/90">
                        ${Number(e.amount ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-5 py-3 text-white/40 italic">{e.location ?? "Unknown"}</td>
                      <td className="px-5 py-3">
                        <span className={cn("inline-flex items-center gap-1 font-bold", colorClass)}>
                          {String(e.decision ?? "").replace(/[🚫✅⚠️]/g, "").trim()}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="w-12 h-1 bg-white/10 rounded-full overflow-hidden hidden sm:block">
                            <div className={cn("h-full", isBlock ? "bg-red-500" : isReview ? "bg-amber-500" : "bg-emerald-500")}
                              style={{ width: `${(e.risk ?? 0) * 100}%` }} />
                          </div>
                          <span className={cn("tabular-nums", isBlock ? "text-red-300 font-bold" : "text-muted-foreground")}>
                            {((e.risk ?? 0) * 100).toFixed(1)}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}
    </PageShell>
  )
}

function Health({ row, ok }: { row: string; ok?: boolean }) {
  return (
    <li className="flex items-center justify-between rounded-lg border border-border/60 bg-background/40 p-3">
      <span>{row}</span>
      <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${
        ok ? "border border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
           : "border border-red-500/40 bg-red-500/10 text-red-300"
      }`}>
        <span className={`h-1.5 w-1.5 rounded-full ${ok ? "bg-emerald-400" : "bg-red-400"}`} />
        {ok ? "ready" : "offline"}
      </span>
    </li>
  )
}