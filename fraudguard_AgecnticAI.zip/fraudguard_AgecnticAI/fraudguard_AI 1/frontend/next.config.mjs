/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Allow v0 preview / Vercel sandbox hosts to access dev resources (HMR, etc.)
  allowedDevOrigins: ["*.vusercontent.net", "*.v0.app", "*.vercel.app"],
}

export default nextConfig
