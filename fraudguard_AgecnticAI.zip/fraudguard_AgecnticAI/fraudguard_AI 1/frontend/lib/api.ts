// Centralized API client — FraudGuard AI backend
// Backend: http://127.0.0.1:8000

import type {
  HealthResponse,
  MetricsResponse,
  PredictResponse,
  BatchResponse,
  BatchRow,
  ChatResponse,
  DecisionContext,
  KafkaStatus,
  ForecastResponse,
  ForecastTimeseriesResponse,
  DriftStatus,
  ReportSummary,
  FcmResponse,
  AgentStatusResponse,
  AgentSelfEvaluationResponse,
  AgentFeedbackResponse,
  ReactLogEntry,
  RagStatusResponse,
  // ★ NEW imports
  WorldModelResponse,
  AgentConflictsResponse,
  AgentToolsResponse,
  AgentHealthResponse,
  AgentRagKnowledgeResponse,
  AttackerIntentResponse,
  KafkaTransaction,
  KafkaProduceResponse,
  KafkaConsumerLogResponse,
  AgentGoalsResponse,
  UserMemoryResponse,
  MfaStatusResponse,
  MfaVerifyResponse,
} from "./types"
export const API_BASE =
  (typeof process !== "undefined" && process.env.NEXT_PUBLIC_API_URL) ||
  "http://127.0.0.1:8000"

export const WS_BASE =
  (typeof process !== "undefined" && process.env.NEXT_PUBLIC_WS_URL) ||
  API_BASE.replace(/^http/, "ws")

class ApiError extends Error {
  status: number
  detail: unknown
  constructor(message: string, status: number, detail?: unknown) {
    super(message)
    this.status = status
    this.detail = detail
  }
}

async function request<T>(
  path: string,
  init: RequestInit = {},
  opts: { retries?: number; timeoutMs?: number } = {},
): Promise<T> {
  const { retries = 0, timeoutMs = 60_000 } = opts
  const url = `${API_BASE}${path}`
  const headers = new Headers(init.headers)
  if (init.body && !(init.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json")
  }

  let lastErr: unknown
  for (let attempt = 0; attempt <= retries; attempt++) {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), timeoutMs)
    try {
      const res = await fetch(url, {
        ...init,
        headers,
        cache: "no-store",
        signal: init.signal ?? ctrl.signal,
      })
      clearTimeout(timer)
      if (!res.ok) {
        const text = await res.text().catch(() => "")
        let detail: unknown = text
        try { detail = JSON.parse(text) } catch { /* keep raw */ }
        throw new ApiError(`API ${res.status}: ${res.statusText}`, res.status, detail)
      }
      return (await res.json()) as T
    } catch (e) {
      clearTimeout(timer)
      lastErr = e
      if ((e as Error)?.name === "AbortError") break
      if (attempt === retries) break
      await new Promise((r) => setTimeout(r, 250 * (attempt + 1)))
    }
  }
  throw lastErr
}

export const api = {
  // ── Core ─────────────────────────────────────────────
  health  : () => request<HealthResponse>("/health", {}, { timeoutMs: 4_000 }),
  metrics : () => request<MetricsResponse>("/metrics", {}, { timeoutMs: 6_000 }),

  textPredict: (text: string) =>
    request<PredictResponse>("/text-predict", {
      method: "POST",
      body: JSON.stringify({ text }),
    }),

  batch: async (file: File): Promise<BatchResponse> => {
    const fd = new FormData()
    fd.append("file", file)
    return request<BatchResponse>("/batch", { method: "POST", body: fd })
  },

  // ── Chat ─────────────────────────────────────────────
  chat: (message: string, decisionContext: DecisionContext, transactionId?: string) =>
    request<ChatResponse>("/chat", {
      method: "POST",
      body: JSON.stringify({
        message,
        decision_context: decisionContext,
        transaction_id  : transactionId ?? null,
      }),
    }),

  chatReset: () =>
    request<{ status: string }>("/chat/reset", {
      method: "POST",
      body: JSON.stringify({}),
    }),

  // ── Kafka ─────────────────────────────────────────────
  kafkaStart : () => request<{ status: string }>("/kafka/consumer/start",  { method: "POST" }),
  kafkaStop  : () => request<{ status: string }>("/kafka/consumer/stop",   { method: "POST" }),
  kafkaStatus: () => request<KafkaStatus>("/kafka/consumer/status", {}, { timeoutMs: 4_000 }),

  /** ★ Replaces direct fetch() calls in dashboard and stream pages */
  kafkaConsumerLog: (limit = 50) =>
    request<KafkaConsumerLogResponse>(
      `/kafka/consumer/log?limit=${limit}`,
      {},
      { timeoutMs: 4_000 },
    ),

  /** ★ Push transactions to Kafka topic */
  kafkaProduce: (transactions: KafkaTransaction[]) =>
    request<KafkaProduceResponse>("/kafka/produce", {
      method: "POST",
      body: JSON.stringify(transactions),
    }),

  // ── Forecast ─────────────────────────────────────────
  forecast: (transactionTime = 0) =>
    request<ForecastResponse>(`/forecast?transaction_time=${transactionTime}`),

  forecastTimeseries: (horizonHours = 24) =>
    request<ForecastTimeseriesResponse>(
      `/forecast/timeseries?horizon_hours=${horizonHours}`,
      {},
      { timeoutMs: 8_000 },
    ),

  // ── Drift ─────────────────────────────────────────────
  driftStatus: () => request<DriftStatus>("/drift/status"),
  autoLearn  : () =>
    request<{ status: string; total_records: number; high_confidence: number; fraud_in_logs: number }>(
      "/auto-learn",
    ),

  // ── Email ─────────────────────────────────────────────
  emailFraudAlert: (customer_email: string, result: unknown, report_text: string) =>
    request<{ status: string }>("/email/fraud-alert", {
      method: "POST",
      body: JSON.stringify({ customer_email, result, report_text }),
    }),

  emailBatchAlert: (results: unknown[], customer_email: string, send_internal = true) =>
    request<{ status: string; fraud_count: number; sent_internal: boolean }>(
      "/email/batch-alert",
      { method: "POST", body: JSON.stringify({ results, customer_email, send_internal }) },
    ),

  /** ★ Send notification directly to customer */
  emailCustomerAlert: (customer_email: string, result: unknown, report_text = "") =>
    request<{ status: string; to: string }>("/email/customer-alert", {
      method: "POST",
      body: JSON.stringify({ customer_email, result, report_text }),
    }),

  // ── Reports ───────────────────────────────────────────
  reportsSummary: () => request<ReportSummary>("/reports/summary"),

  /** ★ Generate LLM report for a specific transaction result */
  generateReport: (result: unknown) =>
    request<{ report: string }>("/report", {
      method: "POST",
      body: JSON.stringify(result),
    }),

  // ── Clustering ────────────────────────────────────────
  clusteringFcm: (results: BatchRow[], n_components = 2) =>
    request<FcmResponse>("/clustering/fcm", {
      method: "POST",
      body: JSON.stringify({ results, n_components }),
    }),

  // ════════════════════════════════════════════════════
  // Agent / Agentic AI endpoints
  // ════════════════════════════════════════════════════

  agentStatus: () =>
    request<AgentStatusResponse>("/agent/status", {}, { timeoutMs: 6_000 }),

  agentReactLog: (n = 20) =>
    request<{ react_log: ReactLogEntry[]; total_decisions: number }>(
      `/agent/react-log?n=${n}`,
      {},
      { timeoutMs: 6_000 },
    ),

  agentSelfEvaluation: () =>
    request<AgentSelfEvaluationResponse>("/agent/self-evaluation", {}, { timeoutMs: 6_000 }),

  agentFeedback: (card_id: string, was_fraud: boolean, notes?: string) =>
    request<AgentFeedbackResponse>("/agent/feedback", {
      method: "POST",
      body: JSON.stringify({ card_id, was_fraud, notes }),
    }),

  /** POST /agent/goals — update goal weights */
  agentSetGoals: (goals: Record<string, number>) =>
    request<{ status: string; current_goals: Record<string, number> }>("/agent/goals", {
      method: "POST",
      body: JSON.stringify({ goals }),
    }),

  /** GET /agent/goals — read all active + done + strategic goals */
  agentGetGoals: () =>
    request<AgentGoalsResponse>("/agent/goals", {}, { timeoutMs: 4_000 }),

  agentUserMemory: (card_id: string) =>
    request<UserMemoryResponse>(`/agent/user-memory/${card_id}`, {}, { timeoutMs: 4_000 }),

  agentRagStatus: () =>
    request<RagStatusResponse>("/agent/rag-status", {}, { timeoutMs: 4_000 }),

  /** ★ POST /agent/predict — full agentic prediction (explicit agent endpoint) */
  agentPredict: (tx: Record<string, unknown>) =>
    request<PredictResponse>("/agent/predict", {
      method: "POST",
      body: JSON.stringify(tx),
    }),

  // ════════════════════════════════════════════════════
  // ★ NEW — 8 Agentic System Endpoints
  // ════════════════════════════════════════════════════

  /** World Model: attacker patterns, campaigns, causal features, hour risk */
  agentWorldModel: () =>
    request<WorldModelResponse>("/agent/world-model", {}, { timeoutMs: 6_000 }),

  /** Inter-Agent Conflicts: DetectionAgent vs SecurityAgent vs ForecastAgent */
  agentConflicts: () =>
    request<AgentConflictsResponse>("/agent/conflicts", {}, { timeoutMs: 4_000 }),

  /** Autonomous Tool Discovery: all registered tools + performance metrics */
  agentTools: () =>
    request<AgentToolsResponse>("/agent/tools", {}, { timeoutMs: 4_000 }),

  /** Self-Healing Health: SHAP/Kafka/LLM/RAG health + active fallbacks */
  agentHealth: () =>
    request<AgentHealthResponse>("/agent/health", {}, { timeoutMs: 4_000 }),

  /** RAG Intelligence: fraud knowledge base + LLM cache stats */
  agentRagKnowledge: () =>
    request<AgentRagKnowledgeResponse>("/agent/rag-knowledge", {}, { timeoutMs: 4_000 }),

  /** World Model Attacker Intent: what is this attacker trying to do? */
  agentAttackerIntent: (tx: { amount: number; time?: number }) =>
    request<AttackerIntentResponse>("/agent/attacker-intent", {
      method: "POST",
      body: JSON.stringify({ amount: tx.amount, time: tx.time ?? 0 }),
    }),

  // ── MFA ──────────────────────────────────────────────────────
  mfaVerify: (token: string, otp: string, ip = "") =>
    request<MfaVerifyResponse>("/mfa/verify", {
      method: "POST",
      body: JSON.stringify({ token, otp, ip }),
    }),

  mfaStatus: (token: string) =>
    request<MfaStatusResponse>(`/mfa/status/${token}`, {}, { timeoutMs: 4_000 }),

  mfaResend: (token: string) =>
    request<{ status: string; expires_in: number; otp_sent_to: string }>(
      `/mfa/resend/${token}`, { method: "POST" },
    ),

  mfaCancel: (token: string) =>
    request<{ status: string; token: string }>(
      `/mfa/cancel/${token}`, { method: "DELETE" },
    ),

  mfaStats: () =>
    request<{ service_stats: Record<string, number>; recent_audit: any[] }>(
      "/mfa/stats", {}, { timeoutMs: 4_000 },
    ),

  emailStatus: () =>
    request<{ stats: Record<string, number>; history: any[] }>(
      "/email/status", {}, { timeoutMs: 4_000 },
    ),
}

// Keep old agentGoals as alias for backwards compat
export const agentGoals = api.agentSetGoals

export { ApiError }