// Centralized types — FraudGuard AI
// Backend: http://127.0.0.1:8000

export type Decision = "BLOCK 🚫" | "REVIEW ⚠️" | "ALLOW ✅" | "MFA_REQUIRED 🔐" | string

export interface HealthResponse {
  status: string
  model: boolean
  timestamp: string
}

export interface MetricsResponse {
  total: number
  blocks: number
  reviews: number
  allows: number
  fraud_rate_pct: number
  llm_overrides: number
  velocity_blocks: number
  uptime_seconds: number
  model_loaded: boolean
  shap_ready: boolean
  llm_ready: boolean
  forecast: { anomaly_detected: boolean; rolling_rate: number }
  drift: { last_retrain: number; monitor_features: string[] }
  agent?: {
    react_loop         : string
    memory_episodes    : number
    memory_users       : number
    six_properties     : number
    orchestrator_ready : boolean
    system_precision   : number
    both_signals_firing: boolean
  }
}

export interface ShapDriver {
  feature    : string
  shap_value : number
  readable   : string
}

export interface AgenticMetadata {
  reasoning_chain          : string[]
  react_loop               : string
  agent_latency_ms         : number
  deterioration_score      : number
  preemptive_action        : string
  action_intensity         : string
  action_timing            : string
  action_justification     : string
  dynamic_weight           : number
  weight_justification     : string
  reflection_quality       : string
  reflection_notes         : string[]
  six_agentic_properties   : Record<string, boolean>
  both_drift_signals_firing: boolean
}

export interface PredictResponse {
  decision       : Decision
  probability    : number
  shap_score     : number
  forecast_risk  : number
  total_risk     : number
  uncertainty    : number
  confidence_band: string
  explanation    : string
  top_drivers    : ShapDriver[]
  path           : string
  layers_used    : string[]
  llm_override   : boolean
  mfa_required?  : boolean          // ← أضف
  risk_components: {
    model    : number
    shap     : number
    forecast : number
    llm_score: number
  }
  timestamp : string
  latency_ms: number
  row_id?   : string | number | null
  structured?: {
    amount    : number | null
    hour      : number | null
    location  : string | null
    risk_flags?: Record<string, boolean>
  }
  agentic?: AgenticMetadata
  mfa?: {
    mfa_required : boolean
    token?       : string
    expires_in?  : number
    otp_sent_to? : string
    message?     : string
  }
}
export interface BatchRow {
  row_id         : number
  decision       : Decision
  probability    : number
  shap_score     : number
  total_risk     : number
  confidence_band: string
  card_id?       : string
  explanation?   : string
  forecast_risk? : number
  path?          : string
  layers_used?   : string[]
  top_drivers?   : ShapDriver[]
  risk_components?: Record<string, number>
  timestamp?     : string
  mfa_required?  : boolean
  mfa?: {
    mfa_required : boolean
    token?       : string
    expires_in?  : number
    otp_sent_to? : string
    message?     : string
  }
}
export interface BatchResponse {
  total_rows: number
  fraud_found: number
  fraud_rate: number
  drift      : { drift_detected: boolean; severity: string }
  validation : { original_rows: number; clean_rows: number; issues: string[] }
  results    : BatchRow[]
}

export interface ChatResponse {
  reply             : string
  language_detected : "en" | "ar" | "egy" | string
}

export interface DecisionContext {
  decision        : string
  total_risk      : number
  explanation     : string
  row_id          : string | number | null
  probability?    : number
  shap_score?     : number
  forecast_risk?  : number
  confidence_band?: string
  path?           : string
  layers_used?    : string[]
  top_drivers?    : ShapDriver[]
  risk_components?: Record<string, number>
  timestamp?      : string
  amount?         : number | null
  hour?           : number | null
  location?       : string | null
}

export interface StreamMessage {
  type               : "prediction"
  decision           : string
  risk               : number
  probability        : number
  path               : string
  band               : string
  ts                 : string
  deterioration?     : number
  preemptive_action? : string
  react_path?        : string
  agent_latency_ms?  : number
  shap_score?        : number
  mfa?               : boolean
  explanation?       : string
}

export interface KafkaStatus {
  active      : boolean
  thread_alive: boolean
  topic       : string
}

export interface ForecastResponse {
  forecast_risk   : number
  anomaly_detected: boolean
  hour            : number
  adaptive_mode   : string
}

export interface DriftStatus {
  model_version   : number
  threshold       : number
  retrain_cooldown: number
  anomaly_detected: boolean
  monitor_features: string[]
}

export interface ReportSummary {
  total           : number
  fraud_rate_pct  : number
  confidence_dist : Record<string, number>
  recent_count    : number
  uptime_hours    : number
}

export interface FcmPoint {
  row_id            : number
  fcm_cluster       : number
  probability       : number
  total_risk        : number
  shap_score?       : number
  forecast_risk?    : number
  decision          : string
  confidence_band   : string
  cluster_fraud_risk: number
  is_fraud          : number
  pca_x             : number
  pca_y             : number
  uncertainty?      : number
  zone?             : "core" | "border" | "uncertain"
  memberships?      : Record<string, number>
}

export interface FcmResponse {
  status             : string
  n_points           : number
  n_clusters_fcm     : number
  cluster_fraud_rates: Record<string, number>
  cluster_sizes?     : Record<string, number>
  explained_variance : number[]
  zone_summary?      : { core: number; border: number; uncertain: number }
  data               : FcmPoint[]
}

// ════════════════════════════════════════════════════════
// SARIMA / Forecast Timeseries
// ════════════════════════════════════════════════════════

export interface ForecastHistoricalPoint {
  time        : string
  fraud_count : number
  fraud_rate  : number
  rolling_rate: number
  is_spike    : boolean
}

export interface ForecastFuturePoint {
  horizon_h     : number
  predicted_rate: number
  ci_lower      : number
  ci_upper      : number
  risk_level    : "low" | "medium" | "high"
}

export interface ForecastTimeseriesResponse {
  status          : string
  historical      : ForecastHistoricalPoint[]
  forecast        : ForecastFuturePoint[]
  horizon_hours   : number
  base_rate       : number
  trend           : number
  trend_direction : "rising" | "declining" | "stable"
  anomaly_windows : { time: string; type: string }[]
  total_historical: number
  total_forecast  : number
  live: {
    current_hour      : number
    rolling_fraud_rate: number
    global_mean_rate  : number
    anomaly_active    : boolean
    adaptive_mode     : string
  }
  model_info: {
    type         : string
    update_source: string
    connected_to : string
    last_updated : string
  }
}

// ════════════════════════════════════════════════════════
// Agent Status & ReAct
// ════════════════════════════════════════════════════════

export interface ReactLogEntry {
  ts             : string
  card_id        : string | null
  decision       : string
  routing_path   : string
  reasoning_chain: string[]
  quality        : string
  latency_ms     : number
}

export interface AgentStatusResponse {
  agents_active   : string[]
  memory_episodes : number
  memory_patterns : number
  memory_users    : number
  system_precision: number
  learning_signals: number
  goals           : Record<string, number>
  react_log_size  : number
  react_log       : ReactLogEntry[]
  system_goals    : Record<string, number>
  explicit_rag?: {
    size         : number
    ready        : boolean
    min_docs     : number
    k_neighbors  : number
    borderline_lo: number
    borderline_hi: number
  }
  sarima_live?: {
    rolling_fraud_rate: number
    global_mean_rate  : number
    anomaly_active    : boolean
    forecast_ts_rows  : number
  }
}

export interface AgentSelfEvaluationResponse {
  system_health         : "healthy" | "degrading" | "critical"
  precision_estimate    : number
  decision_quality      : Record<string, number>
  quality_rate          : number
  gap_decline_signal    : number
  both_signals_firing   : boolean
  retraining_recommended: boolean
  memory_size           : { episodic: number; semantic: number; users: number }
  six_properties_active : Record<string, boolean>
}

export interface AgentFeedbackResponse {
  status              : string
  episodes_updated    : number
  updated_precision   : number
  card_id             : string
  was_fraud           : boolean
  adaptation_triggered: boolean
  rag_size?           : number
}

export interface RagStatusResponse {
  explicit_rag_size: number
  ready            : boolean
  min_docs_needed  : number
  k_neighbors      : number
  borderline_range : [number, number]
  implicit_rag     : string
  seven_paths      : string[]
}

// ════════════════════════════════════════════════════════
// ★ NEW — World Model
// ════════════════════════════════════════════════════════

export interface WorldModelSummary {
  total_seen          : number
  fraud_rate          : number
  peak_fraud_hour     : number
  active_campaigns    : number
  top_causal_features : string[]
  known_patterns      : number
}

export interface WorldModelResponse {
  world_model         : WorldModelSummary
  active_campaigns    : { id: string; detected: string; high_risk_rate: number }[]
  hour_risk_profile   : Record<string, number>
  top_causal_features : [string, number][]
}

// ════════════════════════════════════════════════════════
// ★ NEW — Inter-Agent Conflicts
// ════════════════════════════════════════════════════════

export interface AgentConflict {
  type      : string
  message   : string
  severity  : "medium" | "high"
  resolution: string
  ts        : string
}

export interface AgentConflictsResponse {
  recent_conflicts: AgentConflict[]
  total_messages  : number
}

// ════════════════════════════════════════════════════════
// ★ NEW — Autonomous Tool Registry
// ════════════════════════════════════════════════════════

export interface ToolMeta {
  description: string
  calls      : number
  error_rate : number
  avg_ms     : number
  tags       : string[]
}

export interface AgentToolsResponse {
  tools            : Record<string, ToolMeta>
  total_tools      : number
  situation_example: string[]
}

// ════════════════════════════════════════════════════════
// ★ NEW — Self-Healing Health Monitor
// ════════════════════════════════════════════════════════

export interface SubsystemStatus {
  healthy : boolean
  failures: number
  fallback: string
}

export interface HealthAlert {
  ts        : string
  component : string
  status    : string
  fallback  : string
  error     : string
}

export interface AgentHealthResponse {
  subsystems: Record<string, SubsystemStatus>
  alerts    : HealthAlert[]
  shap_ok   : boolean
  kafka_ok  : boolean
  llm_ok    : boolean
  rag_ok    : boolean
}

// ════════════════════════════════════════════════════════
// ★ NEW — RAG Knowledge Base
// ════════════════════════════════════════════════════════

export interface KnowledgeEntry {
  id  : string
  type: "policy" | "playbook"
  text: string
  tags: string[]
}

export interface AgentRagKnowledgeResponse {
  knowledge_base   : KnowledgeEntry[]
  explicit_rag_size: number
  llm_cache_size   : number
  rag_ready        : boolean
}

// ════════════════════════════════════════════════════════
// ★ NEW — Attacker Intent
// ════════════════════════════════════════════════════════

export interface AttackerIntentResponse {
  attacker_intent: string
  world_model    : WorldModelSummary
  hour_risk      : number
}

// ════════════════════════════════════════════════════════
// ★ NEW — Kafka Produce / Transaction
// ════════════════════════════════════════════════════════

export interface KafkaTransaction {
  transaction_id?: string
  user_id        : string
  amount         : number
  timestamp?     : string
  location?      : string
  v14?           : number
  is_fraud?      : number
}

export interface KafkaProduceResponse {
  status : string
  sent   : number
  topic? : string
  results?: { transaction_id?: string; decision: string; risk: number; path: string }[]
}

// ════════════════════════════════════════════════════════
// ★ NEW — Kafka Consumer Log
// ════════════════════════════════════════════════════════

export interface KafkaLogEntry {
  user_id    : string | null
  amount     : number | null
  location   : string | null
  v14        : number | null
  is_fraud   : number | null
  decision   : string
  risk       : number
  probability: number
  ts         : string
}

export interface KafkaConsumerLogResponse {
  entries  : KafkaLogEntry[]
  total    : number
  fraud    : number
  accuracy : number
}

// ════════════════════════════════════════════════════════
// ★ NEW — Agent Goals (GET)
// ════════════════════════════════════════════════════════

export interface AgentGoalsResponse {
  active   : { name: string; type: string; priority: number; trigger: string; action: string; created_at: string; status: string }[]
  done     : { name: string; type: string; status: string }[]
  strategic: Record<string, number>
}

// ════════════════════════════════════════════════════════
// ★ NEW — User Memory Profile
// ════════════════════════════════════════════════════════

export interface UserMemoryProfile {
  total_txns      : number
  fraud_count     : number
  avg_amount      : number
  usual_hours     : Record<string, number>
  usual_locations : string[]
  last_seen       : string | null
  risk_trend      : number[]
  mfa_count       : number
}

export interface UserMemoryResponse {
  card_id     : string
  agent_memory: UserMemoryProfile
}

// ════════════════════════════════════════════════════════
// MFA Service Types
// ════════════════════════════════════════════════════════

export interface MfaStatusResponse {
  token             : string
  card_id           : string
  verified          : boolean
  expired           : boolean
  locked            : boolean
  locked_until      : number
  expires_in        : number
  attempts          : number
  attempts_remaining: number
  otp_sent_to       : string
}

export interface MfaVerifyResponse {
  status             : string
  code               : string
  message?           : string
  original_decision? : string
  card_id?           : string
  attempts_remaining?: number
  detail?            : string | Record<string, unknown>
}