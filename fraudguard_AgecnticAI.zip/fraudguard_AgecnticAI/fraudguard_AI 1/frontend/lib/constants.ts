export const NAV_ITEMS = [
  { href: "/dashboard", label: "Dashboard", icon: "LayoutDashboard" },
  { href: "/predict", label: "Predict", icon: "Brain" },
  { href: "/batch", label: "Batch", icon: "FileSpreadsheet" },
  { href: "/stream", label: "Stream", icon: "Radio" },
  { href: "/chat", label: "Assistant", icon: "MessageSquare" },
  { href: "/reports", label: "Reports", icon: "BarChart3" },
] as const

export function decisionTone(decision: string): {
  label: string
  color: string
  bg: string
  border: string
  glow: string
} {
  if (decision.startsWith("BLOCK")) {
    return {
      label: "BLOCK",
      color: "text-red-400",
      bg: "bg-red-500/10",
      border: "border-red-500/40",
      glow: "shadow-[0_0_32px_-4px_oklch(0.62_0.24_22/0.6)]",
    }
  }
  if (decision.startsWith("REVIEW")) {
    return {
      label: "REVIEW",
      color: "text-amber-400",
      bg: "bg-amber-500/10",
      border: "border-amber-500/40",
      glow: "shadow-[0_0_32px_-4px_oklch(0.78_0.16_75/0.5)]",
    }
  }
  if (decision.startsWith("ALLOW")) {
    return {
      label: "ALLOW",
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
      border: "border-emerald-500/40",
      glow: "shadow-[0_0_32px_-4px_oklch(0.70_0.18_150/0.5)]",
    }
  }
  if (decision.startsWith("MFA")) {
    return {
      label: "MFA",
      color: "text-violet-300",
      bg: "bg-violet-500/10",
      border: "border-violet-500/40",
      glow: "shadow-[0_0_32px_-4px_oklch(0.62_0.24_295/0.5)]",
    }
  }
  return {
    label: decision,
    color: "text-foreground",
    bg: "bg-muted/40",
    border: "border-border",
    glow: "",
  }
}
